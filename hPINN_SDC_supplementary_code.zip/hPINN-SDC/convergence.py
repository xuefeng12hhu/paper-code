"""
convergence.py
==============
收敛性诊断（P2.5）：分别扫描同伦段数 K、残差配置点数 N_res、
网络宽度、数据上限 N_data_max，观察 rel-L2 的收敛行为。

用法：
    python convergence.py --study K          --recipe lite
    python convergence.py --study Nres       --recipe lite
    python convergence.py --study capacity   --recipe lite
    python convergence.py --study data       --recipe lite

输出：results/convergence/<study><tag>.json + <study><tag>.png

预算一致性
----------
--recipe 选择与主表（Table 1/2）**完全相同**的冻结预算，因此本节的四点
扫描与消融实验可直接对比。历史遗留的 h1 配方保留用于复现早期数字。

K=1 语义
--------
TrainConfig 中 K=1 时 lam_k=1.0（早期版本写作 k/max(K-1,1)，K=1 会退化为
lam=0，即纯热方程），因此本节的 K=1 点是真正的"直接训练 at lam=1"，
与 no-homotopy 消融含义一致。
"""
import sys, os, json, time, argparse
sys.path.insert(0, '.')
import torch
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.homotopy_nn import TrainConfig, train_homotopy_nn, evaluate_grid
from src.reference_solver import ETD2RK, make_initial_condition
from src.evaluation import rel_l2_error

OUT = os.path.join("results", "convergence")
os.makedirs(OUT, exist_ok=True)

L, N_REF, T, M_REF = 10.0, 48, 5.0, 40
IC = dict(eps=0.8, sigma=1.5)

# 冻结配方。lite 与主表统一预算一致（200 / 4x100 / 100 / 200，N_data_max=4000）。
RECIPES = {
    "h1": dict(N_grid=32, N_ic=400, ic_pretrain_epochs=300,
               correct_epochs=300, final_correct_epochs=900,
               final_extra_data=True, N_data_max=20000,
               stage_epochs=300, total_stage=1200, total_corr=1200),
    "lite": dict(N_grid=32, N_ic=400, ic_pretrain_epochs=200,
                 correct_epochs=100, final_correct_epochs=200,
                 final_extra_data=True, N_data_max=4000,
                 stage_epochs=100, total_stage=400, total_corr=500),
}

STUDIES = {
    "K": dict(param="K", values=[1, 2, 4, 8]),
    "Nres": dict(param="N_res", values=[250, 500, 1000, 2000, 4000]),
    "capacity": dict(param="hidden", values=[64, 128, 256]),
    "data": dict(param="N_data_max", values=[2000, 5000, 20000, 60000]),
}


def budget_split(total_stage, K, total_corr):
    e_k = total_stage // max(K, 1)
    n_nonfinal = max(K - 1, 0)
    # 校正预算：前 K-1 段均分 (与 K 无关的总预算思路：总校正量守恒)
    each = total_corr // max(K, 1)
    final = total_corr - each * n_nonfinal if K > 1 else total_corr
    return [e_k]*K, each, final


def run_point(study, val, recipe, seed):
    R = RECIPES[recipe]
    st = STUDIES[study]
    kw = dict(N_grid=R["N_grid"], N_ic=R["N_ic"],
              ic_pretrain_epochs=R["ic_pretrain_epochs"],
              correct_schedule="always",
              correct_epochs=R["correct_epochs"],
              final_correct_epochs=R["final_correct_epochs"],
              final_extra_data=R["final_extra_data"],
              N_data_max=R["N_data_max"])
    torch.manual_seed(seed)
    if study == "K":
        K = int(val)
        e_k, each, final = budget_split(R["total_stage"], K, R["total_corr"])
        kw.update(K=K, E_k=e_k, correct_epochs=each,
                  final_correct_epochs=final, final_extra_data=False)
    else:
        kw.update(K=4, E_k=[R["stage_epochs"]] * 4)
        kw[st["param"]] = int(val)

    psi0 = make_initial_condition("gaussian", N_REF, L, **IC)
    ref = ETD2RK(lam=1.0, L_box=L, N=N_REF).integrate(
        psi0, dt=T/(M_REF-1), n_steps=M_REF-1)
    cfg = TrainConfig(L=L, T=T, ic_kind="gaussian", ic_params=IC,
                      seed=seed, **kw)
    t0 = time.time()
    net, hist = train_homotopy_nn(cfg, verbose=False)
    out = evaluate_grid(net, cfg, lam=1.0, M=M_REF, N=N_REF)
    e2 = rel_l2_error(torch.tensor(out["snaps"]), ref).numpy()
    return dict(study=study, value=val, recipe=recipe, seed=seed,
                e2_mean=float(e2.mean()),
                e2_final=float(e2[-1]), e2_ic=float(e2[0]),
                t_train=time.time() - t0)


def plot(study, recs, path, param):
    recs = sorted(recs, key=lambda r: r["value"])
    xs = [r["value"] for r in recs]
    ys = [r["e2_mean"] for r in recs]
    fig, ax = plt.subplots(figsize=(5.5, 4))
    ax.loglog(xs, ys, "o-", label="e2 mean")
    ax.set_xlabel(param); ax.set_ylabel("rel-L2 (mean)")
    ax.set_title(f"Convergence: {study}")
    ax.grid(alpha=0.3, which="both"); ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--study", required=True, choices=list(STUDIES.keys()))
    ap.add_argument("--recipe", default="h1", choices=list(RECIPES.keys()))
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--values", default=None,
                    help="逗号分隔的扫描点子集，便于并行分片（如 1,2）")
    ap.add_argument("--tag", default="", help="输出文件名后缀，便于分片落地")
    args = ap.parse_args()

    st = STUDIES[args.study]
    values = ([v.strip() for v in args.values.split(",")] if args.values
              else st["values"])

    recs = []
    for v in values:
        r = run_point(args.study, v, args.recipe, args.seed)
        recs.append(r)
        print(f"  {st['param']}={v}: e2_mean={r['e2_mean']:.3f} "
              f"(e2[t=0]={r['e2_ic']:.3f}, {r['t_train']:.0f}s)", flush=True)

    base = os.path.join(OUT, f"{args.study}{args.tag}")
    with open(base + ".json", "w", encoding="utf-8") as f:
        json.dump(recs, f, indent=1)

    # 仅在单进程完成全部扫描点时出图，避免分片互相覆盖
    if len(values) == len(st["values"]):
        plot(args.study, recs, base + ".png", st["param"])
    print("[done]", args.study, args.tag, flush=True)


if __name__ == "__main__":
    main()
