"""
ablation.py
===========
阶段 2 消融实验（方法立足点）：证明同伦延拓、learn-then-correct 数据校正、
Fourier 特征三个组件的独立贡献，并给出多种子统计。

变体：
  full        完整方法（同伦 + IC 预训练 + 调度式数据校正 + Fourier 特征）
  no-homotopy 直接训练 λ=1（K=1，总 epoch 预算与 full 对齐）
  no-correct  去掉数据校正（纯 PINN 残差 + IC 监督，保留同伦与 IC 预训练）
  no-ff       去掉 Fourier 特征（原始 (x,y,t,λ) 输入，保留其余）
  vanilla     无同伦 + 无校正（标准 PINN 基线）

公平性约定：
  - 各变体总训练 epoch 预算对齐（见 budget 函数），差异只在"组件有无"。
  - 每个变体 × N 个随机种子，报告 mean ± std。

输出：results/ablation/<variant>_seed<s>.json + summary.md + ablation.png
"""
import sys, os, json, time, argparse
sys.path.insert(0, '.')
import torch
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.homotopy_nn import TrainConfig, train_homotopy_nn, evaluate_grid
from src.reference_solver import ETD2RK, make_initial_condition
from src.evaluation import rel_l2_error, linf_error, free_energy

OUT = os.path.join("results", "ablation")
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------------------
# 实验规模（消融用 lite 预算：相对比较为准，绝对值不是卖点）
# ---------------------------------------------------------------------------
L = 10.0
N_REF = 48          # 参考解 / 评估网格
T = 5.0
M_REF = 40
IC_KIND = "gaussian"
IC_PARAMS = dict(eps=0.8, sigma=1.5)

# full 变体的基准预算（对齐冻结的 H1 配方但缩 K=4 E_k=100 / final=200 以便多变体可负担）
FULL = dict(
    ic_pretrain_epochs=200, ic_pretrain_tol=0.0,
    K=4, E_k=[100]*4,
    correct_schedule="always", correct_epochs=100,
    final_correct_epochs=200, final_extra_data=True,
    N_data_max=20000, batch_data=0,
    N_grid=32, N_ic=400,
)

# 总 epoch 预算（用于给 no-homotopy 变体配平）
TOTAL_STAGE = 4 * FULL["E_k"][0]
TOTAL_CORR = FULL["correct_epochs"] * (FULL["K"] - 1) + FULL["final_correct_epochs"]


def variant_configs(seed):
    """返回 {variant_name: TrainConfig}，所有变体预算对齐。"""
    base = dict(L=L, T=T, ic_kind=IC_KIND, ic_params=IC_PARAMS)
    pre = dict(ic_pretrain_epochs=FULL["ic_pretrain_epochs"],
               ic_pretrain_tol=FULL["ic_pretrain_tol"],
               ic_pretrain_max=FULL.get("ic_pretrain_max", 4000))
    data = dict(N_data_max=FULL["N_data_max"], batch_data=FULL["batch_data"],
                N_grid=FULL["N_grid"], N_ic=FULL["N_ic"])
    torch.manual_seed(seed)

    full = TrainConfig(**base, **pre, **data,
                       K=FULL["K"], E_k=FULL["E_k"],
                       correct_schedule=FULL["correct_schedule"],
                       correct_epochs=FULL["correct_epochs"],
                       final_correct_epochs=FULL["final_correct_epochs"],
                       final_extra_data=FULL["final_extra_data"])

    # 直接训练 λ=1：单段但 epoch 预算 = 同伦各段之和；校正预算合并到末段
    no_homotopy = TrainConfig(**base, **pre, **data,
                              K=1, E_k=[TOTAL_STAGE],
                              correct_schedule="always",
                              correct_epochs=0,
                              final_correct_epochs=TOTAL_CORR,
                              final_extra_data=FULL["final_extra_data"])

    # 纯 PINN：同伦 + IC 预训练，但无数据校正
    no_correct = TrainConfig(**base, **pre, **data,
                             K=FULL["K"], E_k=FULL["E_k"],
                             correct_schedule="always",
                             correct_epochs=0, final_correct_epochs=0,
                             final_extra_data=False)

    # 无 Fourier 特征（原始坐标输入；去掉特征同时保留其余组件）
    no_ff = TrainConfig(**base, **pre, **data,
                        K=FULL["K"], E_k=FULL["E_k"],
                        correct_schedule=FULL["correct_schedule"],
                        correct_epochs=FULL["correct_epochs"],
                        final_correct_epochs=FULL["final_correct_epochs"],
                        final_extra_data=FULL["final_extra_data"],
                        num_freqs=0)

    # vanilla：无同伦 + 无校正 + 无 FF
    vanilla = TrainConfig(**base, **pre, **data,
                          K=1, E_k=[TOTAL_STAGE],
                          correct_schedule="always",
                          correct_epochs=0, final_correct_epochs=0,
                          final_extra_data=False, num_freqs=0)
    return dict(full=full, no_homotopy=no_homotopy, no_correct=no_correct,
                no_ff=no_ff, vanilla=vanilla)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--cases", default="heal,pair,quench")
    args = ap.parse_args()

    cases = {
        "heal": dict(kind="gaussian", params=dict(eps=0.8, sigma=1.5), T=5.0),
        "pair": dict(kind="pair", params=dict(sep=5.0, xi=0.5), T=6.0),
        "quench": dict(kind="quench", params=dict(ell=1.5, rms=0.4, seed=2), T=4.0),
    }
    sel = [c.strip() for c in args.cases.split(",") if c.strip()]

    rows = []
    for cname in sel:
        cs = cases[cname]
        psi0 = make_initial_condition(cs["kind"], N_REF, L, **cs["params"])
        ref = ETD2RK(lam=1.0, L_box=L, N=N_REF).integrate(
            psi0, dt=cs["T"]/(M_REF-1), n_steps=M_REF-1)

        for vname in ("full", "no_homotopy", "no_correct", "no_ff", "vanilla"):
            means, finals, stds, ttrs = [], [], [], []
            for s in range(args.seeds):
                # 断点续跑：已有结果直接读入
                fjson = os.path.join(OUT, f"{cname}_{vname}_s{s}.json")
                if os.path.exists(fjson):
                    try:
                        with open(fjson, encoding="utf-8") as f:
                            rec_old = json.load(f)
                        means.append(rec_old["e2_mean"])
                        finals.append(rec_old["e2_final"])
                        ttrs.append(rec_old["t_train"])
                        print(f"  [{cname}/{vname}/seed{s}] cached "
                              f"e2_mean={rec_old['e2_mean']:.3f}", flush=True)
                        continue
                    except Exception:
                        pass  # 损坏则重跑
                cfgs = variant_configs(s)
                cfg = cfgs[vname]
                cfg.L, cfg.T = L, cs["T"]
                cfg.ic_kind, cfg.ic_params = cs["kind"], cs["params"]
                t0 = time.time()
                net, hist = train_homotopy_nn(cfg, verbose=False)
                t_tr = time.time() - t0
                out = evaluate_grid(net, cfg, lam=1.0, M=M_REF, N=N_REF)
                snaps = torch.tensor(out["snaps"])
                e2 = rel_l2_error(snaps, ref).numpy()
                ei = linf_error(snaps, ref).numpy()
                means.append(float(e2.mean()))
                finals.append(float(e2[-1]))
                ttrs.append(t_tr)
                rec = dict(case=cname, variant=vname, seed=s,
                           e2_mean=float(e2.mean()), e2_final=float(e2[-1]),
                           linff=float(ei[-1]), t_train=t_tr,
                           correction_stages=sum(1 for h in hist
                                                 if h.get("corrected")))
                with open(fjson, "w", encoding="utf-8") as f:
                    json.dump(rec, f, indent=1)
                print(f"  [{cname}/{vname}/seed{s}] e2_mean={e2.mean():.3f} "
                      f"e2[T]={e2[-1]:.3f} ({t_tr:.0f}s)", flush=True)
            means = np.array(means); finals = np.array(finals)
            rows.append(dict(case=cname, variant=vname,
                             mean=float(means.mean()),
                             std=float(means.std(ddof=1)) if len(means) > 1 else 0.0,
                             final_mean=float(finals.mean()),
                             t_train=float(np.mean(ttrs))))
            print(f">> {cname:7s} {vname:12s} e2_mean = "
                  f"{means.mean():.3f} ± "
                  f"{(means.std(ddof=1) if len(means) > 1 else 0.0):.3f}",
                  flush=True)

    # ---------------- 汇总（从 OUT 目录全部 JSON 重建，跨运行合并）----------------
    all_recs = []
    for fn in sorted(os.listdir(OUT)):
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(OUT, fn), encoding="utf-8") as f:
                all_recs.append(json.load(f))
        except Exception:
            pass
    rows = []
    for cname in ("heal", "pair", "quench"):
        for vname in ("full", "no_homotopy", "no_correct", "no_ff", "vanilla"):
            ms = [r["e2_mean"] for r in all_recs
                  if r.get("case") == cname and r.get("variant") == vname]
            fs = [r["e2_final"] for r in all_recs
                  if r.get("case") == cname and r.get("variant") == vname]
            ts = [r["t_train"] for r in all_recs
                  if r.get("case") == cname and r.get("variant") == vname]
            if not ms:
                continue
            rows.append(dict(case=cname, variant=vname,
                             mean=float(np.mean(ms)),
                             std=float(np.std(ms, ddof=1)) if len(ms) > 1 else 0.0,
                             final_mean=float(np.mean(fs)),
                             n_seeds=len(ms), t_train=float(np.mean(ts))))

    # 条形图
    with open(os.path.join(OUT, "summary.md"), "w", encoding="utf-8") as f:
        f.write("# 阶段 2 消融汇总（多种子，从全部 JSON 重建）\n\n")
        f.write("| 算例 | 变体 | rel-L2 均值 | 种子间 std | rel-L2 末帧 | 种子数 |\n")
        f.write("|---|---|---|---|---|---|\n")
        for r in rows:
            f.write(f"| {r['case']} | {r['variant']} | {r['mean']:.3f} | "
                    f"{r['std']:.3f} | {r['final_mean']:.3f} | {r['n_seeds']} |\n")

    cases_in_rows = [c for c in ("heal", "pair", "quench")
                     if any(r["case"] == c for r in rows)]
    variants = ["full", "no_homotopy", "no_correct", "no_ff", "vanilla"]
    fig, ax = plt.subplots(figsize=(9, 4.5))
    width = 0.8 / max(len(cases_in_rows), 1)
    for i, cname in enumerate(cases_in_rows):
        vals = [next((r["mean"] for r in rows
                      if r["case"] == cname and r["variant"] == v), np.nan)
                for v in variants]
        errs = [next((r["std"] for r in rows
                      if r["case"] == cname and r["variant"] == v), 0.0)
                for v in variants]
        ax.bar(np.arange(len(variants)) + i*width, vals, width,
               yerr=errs, capsize=3, label=cname)
    ax.set_xticks(np.arange(len(variants)) + 0.4 - width/2)
    ax.set_xticklabels(variants, rotation=15)
    ax.set_ylabel("rel-L2 (mean)")
    ax.set_title("Ablation: component contributions")
    ax.legend(); ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "ablation.png"), dpi=130)
    plt.close(fig)
    print("[done] ablation saved to", OUT)


if __name__ == "__main__":
    main()
