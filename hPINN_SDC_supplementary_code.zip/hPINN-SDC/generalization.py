"""
generalization.py
=================
泛化性实验（论文阶段 3 的内容），补齐**可复现脚本**。

背景（见 docs/paper_gap_analysis.md 阶段 9）
-------------------------------------------
1. `results/stage3/{transfer,unseen_ic,long_time_extrap,abrikosov}.json` 在论文中
   完全没有被引用，仓库里也**没有任何生成它们的脚本**（只有绘图脚本读取
   这些 JSON），违反附录"所有实验可由发布代码复现"的声明。本脚本重新生成它们。
2. 这些实验恰恰是"网络学到的是 GL 算子而非记忆初值"的最直接证据，应当写入正文。

实验
----
unseen_ic   跨初值零样本迁移：在 heal 上训练，直接在 pair 初值上评估（反之亦然）
transfer    微调加速：用 heal 预训练网络初始化，在 pair 上按完整配方微调，
            与同预算从头训练对比
long_time   长时间外推：T=5 训练，评估到 T=20，报告 e₂(t) 的增长
abrikosov   磁场算例的可信度诊断：质量、max|ψ|、涡旋数，两个 dt 验证稳定性

用法
----
    python generalization.py                       # 全部
    python generalization.py --experiments abrikosov
    python generalization.py --recipe lite --threads 6

输出
----
    results/stage3/*.json   （覆盖旧文件）
    results/generalization.md
"""
import sys, os, json, time, argparse, dataclasses
sys.path.insert(0, '.')
import numpy as np
import torch

from src.homotopy_nn import (TrainConfig, train_homotopy_nn, evaluate_grid,
                             HomotopyNet)
from src.reference_solver import (ETD2RK, make_initial_condition,
                                  initial_condition_abrikosov, vortex_map,
                                  total_mass)
from src.evaluation import rel_l2_error, linf_error, free_energy

OUT = os.path.join("results", "stage3")
NETS = os.path.join(OUT, "nets")
L = 10.0
N_REF = 48
M_REF = 40

CASES = {
    "heal":   dict(kind="gaussian", params=dict(eps=0.8, sigma=1.5), T=5.0),
    "pair":   dict(kind="pair",     params=dict(sep=5.0, xi=0.5),   T=6.0),
    "quench": dict(kind="quench",   params=dict(ell=1.5, rms=0.4, seed=2), T=4.0),
}

RECIPES = {
    "h1": dict(ic_pretrain_epochs=300, K=4, stage_epochs=300,
               correct_epochs=300, final_correct_epochs=900,
               N_data_max=20000),
    "lite": dict(ic_pretrain_epochs=200, K=4, stage_epochs=100,
                 correct_epochs=100, final_correct_epochs=200,
                 N_data_max=4000),
}


def make_cfg(recipe, case, seed, **over):
    R = RECIPES[recipe]
    kw = dict(L=L, T=case["T"], ic_kind=case["kind"], ic_params=case["params"],
              seed=seed, ic_pretrain_epochs=R["ic_pretrain_epochs"],
              K=R["K"], E_k=[R["stage_epochs"]] * R["K"],
              correct_schedule="always", correct_epochs=R["correct_epochs"],
              final_correct_epochs=R["final_correct_epochs"],
              final_extra_data=True, N_data_max=R["N_data_max"],
              N_grid=32, N_ic=400)
    kw.update(over)
    return TrainConfig(**kw)


def reference(case, T=None, M=M_REF, N=N_REF, lam=1.0):
    T = case["T"] if T is None else T
    psi0 = make_initial_condition(case["kind"], N, L, **case["params"])
    return ETD2RK(lam=lam, L_box=L, N=N).integrate(
        psi0, dt=T / (M - 1), n_steps=M - 1, snapshot_every=1)


def get_net(cname, recipe, seed, cfg=None, verbose=True):
    """训练（或从磁盘载入）某算例的完整方法网络，便于跨实验复用。"""
    os.makedirs(NETS, exist_ok=True)
    key = f"{cname}_{recipe}_s{seed}"
    fp = os.path.join(NETS, key + ".pt")
    cfg = cfg or make_cfg(recipe, CASES[cname], seed)
    if os.path.exists(fp):
        # 旧版此处先跑一次完整训练再覆盖权重（纯浪费）。直接构建同架构网络。
        net = HomotopyNet(hidden=cfg.hidden, num_blocks=cfg.num_blocks,
                          num_freqs=cfg.num_freqs, sigma=cfg.ff_sigma,
                          in_dim=4, out_dim=2, L=cfg.L, seed=cfg.seed
                          ).to(cfg.device)
        net.load_state_dict(torch.load(fp, map_location=cfg.device))
        if verbose:
            print(f"  [net {key}] loaded", flush=True)
        return net, cfg
    t0 = time.time()
    net, _ = train_homotopy_nn(cfg, verbose=False)
    torch.save(net.state_dict(), fp)
    if verbose:
        print(f"  [net {key}] trained in {time.time()-t0:.0f}s", flush=True)
    return net, cfg


def e2_against(net, cfg, ref, M=None):
    M = M or ref.shape[0]
    out = evaluate_grid(net, cfg, lam=1.0, M=M, N=ref.shape[-1])
    snaps = torch.tensor(out["snaps"])
    e2 = rel_l2_error(snaps, ref).numpy()
    vc = (vortex_map(snaps).abs() > 0.5).sum(dim=(-1, -2)).numpy()
    return dict(e2_mean=float(e2.mean()), e2_final=float(e2[-1]),
                e2_series=[float(v) for v in e2],
                nn_vortex_at_T=int(vc[-1]), nn_peak_vortex=int(vc.max()))


# ---------------------------------------------------------------------------
def exp_unseen_ic(recipe, seed):
    """零样本跨初值：训练算例 A，直接在算例 B 的初值/时长上评估。"""
    rows = []
    for train_c, test_c in (("heal", "pair"), ("pair", "heal")):
        net, cfg_tr = get_net(train_c, recipe, seed)
        cfg_te = make_cfg(recipe, CASES[test_c], seed)
        ref = reference(CASES[test_c])
        ind = e2_against(net, cfg_tr, reference(CASES[train_c]))
        ood = e2_against(net, cfg_te, ref)
        rows.append(dict(train_on=train_c, test_on=test_c,
                         e2_in_dist=ind["e2_mean"], e2_unseen=ood["e2_mean"],
                         e2_unseen_final=ood["e2_final"],
                         ref_vortex_at_T=int((vortex_map(ref).abs() > 0.5)
                                             .sum(dim=(-1, -2))[-1].item()),
                         nn_vortex_at_T=ood["nn_vortex_at_T"]))
        print(f"  unseen_ic: {train_c} -> {test_c}: "
              f"in-dist {ind['e2_mean']:.3f}, unseen {ood['e2_mean']:.3f}",
              flush=True)
    json.dump(rows, open(os.path.join(OUT, "unseen_ic.json"), "w",
                         encoding="utf-8"), indent=1)
    return rows


def exp_transfer(recipe, seed):
    """微调：heal 预训练 -> pair 微调 vs pair 同预算从头训练。"""
    net_h, _ = get_net("heal", recipe, seed)
    cfg_p = make_cfg(recipe, CASES["pair"], seed)
    ref_p = reference(CASES["pair"])

    t0 = time.time()
    net_scratch, _ = train_homotopy_nn(cfg_p, verbose=False)
    t_scratch = time.time() - t0
    scratch = e2_against(net_scratch, cfg_p, ref_p)

    t0 = time.time()
    net_ft, _ = train_homotopy_nn(cfg_p, verbose=False, net=net_h)
    t_ft = time.time() - t0
    ft = e2_against(net_ft, cfg_p, ref_p)

    rec = dict(pre_train="heal", target="pair", recipe=recipe, seed=seed,
               e2_scratch=scratch["e2_mean"], e2_finetune=ft["e2_mean"],
               improvement=float(scratch["e2_mean"] / max(ft["e2_mean"], 1e-12)),
               e2_scratch_final=scratch["e2_final"],
               e2_finetune_final=ft["e2_final"],
               t_scratch=t_scratch, t_finetune=t_ft,
               vort_scratch=scratch["nn_vortex_at_T"],
               vort_finetune=ft["nn_vortex_at_T"])
    print(f"  transfer: scratch {rec['e2_scratch']:.3f} -> finetune "
          f"{rec['e2_finetune']:.3f} ({rec['improvement']:.2f}x)", flush=True)
    json.dump(rec, open(os.path.join(OUT, "transfer.json"), "w",
                        encoding="utf-8"), indent=1)
    return rec


def exp_long_time(recipe, seed):
    """训练时长 T=5，评估到 T=20 的外推误差。"""
    case = CASES["heal"]
    net, cfg = get_net("heal", recipe, seed)
    T_long, M_long = 20.0, 80
    psi0 = make_initial_condition(case["kind"], N_REF, L, **case["params"])
    ref = ETD2RK(lam=1.0, L_box=L, N=N_REF).integrate(
        psi0, dt=T_long / (M_long - 1), n_steps=M_long - 1, snapshot_every=1)
    cfg_long = dataclasses.replace(cfg, T=T_long)
    ood = e2_against(net, cfg_long, ref, M=M_long)
    ts = np.linspace(0, T_long, M_long).tolist()
    rec = dict(recipe=recipe, seed=seed, T_train=case["T"], T_eval=T_long,
               t=ts, e2_series=ood["e2_series"],
               e2_at_T_train=float(ood["e2_series"][int((case["T"] / T_long)
                                                        * (M_long - 1))]),
               e2_at_T_eval=ood["e2_final"])
    print(f"  long_time: e2(T=5)={rec['e2_at_T_train']:.3f} -> "
          f"e2(T=20)={rec['e2_at_T_eval']:.3f}", flush=True)
    json.dump(rec, open(os.path.join(OUT, "long_time_extrap.json"), "w",
                        encoding="utf-8"), indent=1)
    return rec


def exp_abrikosov(L_box=20.0, N=64, T=8.0):
    """磁场算例诊断：质量是否守恒、|ψ| 是否越界、两个 dt 是否一致。"""
    rows = []
    psi0 = initial_condition_abrikosov(N, L_box, n_v=4, xi=0.7, spacing=3.0,
                                       orientation="hex")
    for B in (0.0, 0.05, 0.10):
        # total_mass 对单个 (N,N) 场返回 0 维张量（旧版误加 [0] 索引会抛
        # IndexError，导致本实验从未成功产出结果）。
        entry = dict(B=B, N=N, L=L_box, T=T,
                     mass_init=float(total_mass(psi0).item()), dt=[])
        for dt in (0.2, 0.05):
            etd = ETD2RK(lam=1.0, L_box=L_box, N=N, B_field=B,
                         gauge="symmetric")
            s = etd.integrate(psi0, dt=dt, n_steps=int(T / dt),
                              snapshot_every=int(T / dt))
            m = total_mass(s).numpy()
            vc = (vortex_map(s).abs() > 0.5).sum(dim=(-1, -2)).numpy()
            entry["dt"].append(dict(
                dt=dt, mass_final=float(m[-1]), mass_ratio=float(m[-1] / (N * N)),
                max_psi_final=float(s[-1].abs().max().item()),
                vortex_init=int(vc[0]), vortex_final=int(vc[-1]),
                # free_energy 对单帧输入返回 0 维张量，不能再取 [0]。
                F0=float(free_energy(s[0], L_box, lam=1.0, B_field=B)),
                FT=float(free_energy(s[-1], L_box, lam=1.0, B_field=B))))
            print(f"  abrikosov B={B} dt={dt}: "
                  f"mass {m[-1]:.0f} (N^2={N*N}, ratio {m[-1]/(N*N):.2f}), "
                  f"max|psi|={s[-1].abs().max().item():.3f}, "
                  f"vortex {vc[0]}->{vc[-1]}", flush=True)
        # dt 一致性：两个 dt 的解是否一致（说明不是时间步失稳）
        rows.append(entry)
    json.dump(rows, open(os.path.join(OUT, "abrikosov.json"), "w",
                         encoding="utf-8"), indent=1)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--experiments",
                    default="abrikosov,unseen_ic,transfer,long_time")
    ap.add_argument("--recipe", default="lite", choices=list(RECIPES.keys()))
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--threads", type=int, default=6)
    args = ap.parse_args()
    torch.set_num_threads(args.threads)
    os.makedirs(OUT, exist_ok=True)
    exps = [e.strip() for e in args.experiments.split(",") if e.strip()]
    res = {}
    if "abrikosov" in exps:
        print("== abrikosov ==", flush=True); res["abrikosov"] = exp_abrikosov()
    if "unseen_ic" in exps:
        print("== unseen_ic ==", flush=True); res["unseen_ic"] = exp_unseen_ic(args.recipe, args.seed)
    if "transfer" in exps:
        print("== transfer ==", flush=True); res["transfer"] = exp_transfer(args.recipe, args.seed)
    if "long_time" in exps:
        print("== long_time ==", flush=True); res["long_time"] = exp_long_time(args.recipe, args.seed)
    json.dump(res, open(os.path.join("results", "generalization.json"), "w",
                        encoding="utf-8"), indent=1, default=str)
    print("[done] results/generalization.json")


if __name__ == "__main__":
    main()
