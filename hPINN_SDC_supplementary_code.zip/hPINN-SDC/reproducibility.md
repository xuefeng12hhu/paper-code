# 论文可复现性清单

> 本文档是论文 **"Reproducibility"** 一节的完整素材。
> 目标：审稿人或第三方无需联系作者即可在标准硬件上复现全部定量结果。
> 风格遵循 NeurIPS / JCP 共同惯例：**代码 + 依赖 + 命令 + 种子 + 硬件 + 时间预算** 全部列出。
>
> **v0.3.0（P2.6 复核版）**：全部定量结果已按统一 lite 预算、3 种子重跑，
> 并修正了两处基准设计缺陷（见 §R7）。本文档中的数字与论文表 1/表 2、
> 表 3–8 严格一致（表格由 `scripts/emit_tables.py`、`scripts/emit_extra_tables.py`
> 直接从 `results/` 下的结果文件生成，防止正文与表格漂移）。

---

## R1. 代码与依赖

### R1.1 代码发布

- 仓库：占位（`https://github.com/<author>/homotopy-tdgl`，论文接收后上传）
- 版本：v0.3.0（与 `src/__init__.py` 一致）
- 许可：MIT

### R1.2 依赖清单

`requirements.txt`：

```
numpy>=1.26,<3.0
torch>=2.0
matplotlib>=3.7
```

**基线版本**（开发机实测）：

| 包 | 版本 |
|---|---|
| Python | 3.14.3 |
| PyTorch | 2.14.0+cpu（CPU-only 即可；CUDA 兼容） |
| NumPy | 2.5.3 |
| Matplotlib | 3.11.2 |

**为什么不需要更多**：本工程只用了 PyTorch 的 autograd / nn / linear 模块、
NumPy 的 linalg / random、Matplotlib 的 Agg backend。无 scikit-learn /
scipy / pandas 等额外依赖——这是为了**最小依赖原则**。

### R1.3 硬件

**开发机配置**（论文 Method 节 "Implementation" 报告）：

- CPU：x86_64 8 逻辑核（笔记本 CPU，Intel/AMD 等价）
- RAM：16 GB
- 无 GPU 必需
- 操作系统：Windows 11 / Linux x86_64

**注意**：所有计时均在 **CPU** 下测得。多种子主表用 8 分片 × 2 线程并行，
单进程耗时受同机负载影响（同一配置的墙钟时间在 100–2000 s 之间波动）；
论文只报告精度统计，**不**主张任何墙钟时间的可比性。加速比实验
（`results/stage3/speedup.json`）在 **单线程** 下测得，用于表 8。

---

## R2. 随机种子

**全部实验显式固定整数种子**，种子决定：网络初始化、Fourier 特征基、
残差配置点采样、数据锚子采样；**参考解 ETDRK2 快照与初值均与种子无关**
（quench 随机场的模态集固定，见 §R7.1）。

| 实验 | 脚本 | 种子 | 说明 |
|---|---|---|---|
| 三算例 × 六变体主表 | `benchmarks_multiseed.py --recipe lite --seeds 3 --seeds-mode uniform` | 0,1,2 | 54 次训练（表 1/表 2） |
| 激活模式对照（论文 §5.4，`tab:trigger`） | `benchmarks_multiseed.py --recipe lite --seeds 3 --seeds-mode uniform --variants trigger` | 0,1,2 | 9 次训练（a-posteriori 残差阈值触发模式） |
| 诊断图 | `scripts/redraw_diag.py` | 0 | 直接评估 `results/stage3/nets/*_lite_s0.pt`，不重训练 |
| 消融柱状图 | `scripts/plot_ablation_ms.py` | — | 从 `results/benchmarks_ms/summary.json` 重绘 |
| K/Nres/capacity/data 扫描 | `convergence.py --study {K,Nres,capacity,data} --recipe lite --tag _lite` | 0 | 与主表同一冻结预算 |
| λ 参数扫描 | `lambda_scan.py --recipe lite` | 0 | 复用 stage3 网络缓存，不重训练 |
| 泛化性（未见 IC / 迁移 / 长时间） | `generalization.py --recipe lite` | 0 | 见 `results/generalization.json` |
| 网格收敛（空间/时间） | `grid_convergence.py --cases heal,pair,quench` | — | 逐算例缓存断点续跑 |
| 磁场（Abrikosov） | `generalization.py --experiments abrikosov` | 0 | `results/stage3/abrikosov.json` |
| 加速比基准 | `results/stage3/speedup.json` | 0 | 单线程计时（表 8） |

**重要说明**：Fourier feature 矩阵生成器使用独立的 PyTorch Generator
（`torch.Generator().manual_seed(seed)`）以保证 Fourier 特征权重在不同运行间一致。

---

## R3. 命令清单（一键复现）

```bash
# 准备
pip install -r requirements.txt

# === 主表（论文表 1/表 2）===
# 54 次训练：3 算例 × 6 变体 × 3 种子，8 分片并行（~4-6 h @ 8 核 CPU）
python benchmarks_multiseed.py --recipe lite --threads 2 --seeds-mode uniform --seeds 3 \
       --cases heal,pair,quench --variants full,no_homotopy,no_correct,no_ff,vanilla,causal \
       --shard 0/8        # 分片 0..7；全部完成后脚本自动重建 summary.json/md
python scripts/emit_tables.py            # -> 基准表 / 消融表 / 激活模式表 的 LaTeX 行

# === 激活模式对照（论文 §5.4，a-posteriori 残差阈值触发）===
# 9 次训练：3 算例 × trigger 变体 × 3 种子，3 分片并行（~20 min @ 8 核 CPU）
python benchmarks_multiseed.py --recipe lite --threads 2 --seeds-mode uniform --seeds 3 \
       --cases heal,pair,quench --variants trigger --shard 0/3

# === 诊断图与消融图（用缓存网络，秒级）===
python scripts/redraw_diag.py            # results/benchmarks/{case}_diag.png + npz
python scripts/plot_ablation_ms.py       # results/ablation/ablation.png

# === 收敛诊断（论文图 3，表 6）===
python convergence.py --study K        --recipe lite --tag _lite
python convergence.py --study Nres     --recipe lite --tag _lite
python convergence.py --study capacity --recipe lite --tag _lite
python convergence.py --study data     --recipe lite --tag _lite

# === 参考解离散化收敛（论文表 7）===
python grid_convergence.py --cases heal,pair,quench --threads 3
# 产物：results/convergence/grid_{case}.json + grid.json/md

# === λ 参数扫描（论文表 5）===
python lambda_scan.py --cases heal,pair,quench --variants full,no_homotopy \
       --recipe lite --threads 2
# 产物：results/lambda_scan/*.json + summary.md/png

# === 泛化性（论文表 4）===
python generalization.py --recipe lite --experiments unseen_ic,transfer,long_time
# 产物：results/generalization.json

# === 磁场扩展（论文附录 C）===
python generalization.py --experiments abrikosov
# 产物：results/stage3/abrikosov.json

# === 扩展表格 ===
python scripts/emit_extra_tables.py      # Table 3-8 的 LaTeX 行
```

**注意**：`convergence.py` 的 `--tag _lite` 会把结果写到
`results/convergence/<study>_lite.{json,png}`，与历史 h1 配方结果并存，
论文图 3 引用的是 `_lite` 版本。

---

## R4. 数据与产物

### R4.1 输入数据

**无外部数据**：所有算例的初值与参考解均**程序生成**
（`src/reference_solver.py::make_initial_condition`），无下载依赖。

| 算例 | 关键参数 | 备注 |
|---|---|---|
| heal | `eps=0.8, sigma=1.5` | 高斯坑愈合，T=5 |
| pair | `sep=5.0, xi=0.5` | 涡旋-反涡旋湮灭，T=6 |
| quench | `ell=1.5, rms=0.4, seed=2` | Kibble-Zurek 淬火，T=4 |
| abrikosov | `N=32` 预置涡旋, 间距/抖动 | 磁场扩展，T=8 |

**quench 初值的关键性质（P2.6 修复）**：随机复场的 Fourier 模态集
$\{(m,n): |m|,|n|\le\lfloor L/\ell\rfloor\}$ 与归一化常数**与网格 $N$ 无关**，
即不同分辨率积分的是**同一连续随机场**。这是论文表 7 空间收敛研究对
quench 有意义的前提。

### R4.2 输出数据

```
results/
├── benchmarks_ms/                  # 主表：54 个运行
│   ├── {case}_{variant}_s{seed}.json
│   ├── summary.json / summary.md   # 自动汇总（表格唯一数据源）
│   └── nets/                       # 每个运行的网络权重缓存
├── benchmarks/                     # 诊断图（redraw_diag.py 重绘）
│   ├── {heal,pair,quench}_ref.npz / _nn.npz
│   ├── {heal,pair,quench}_diag.png
│   └── diag_stats.json
├── ablation/
│   └── ablation.png                # plot_ablation_ms.py 重绘（六变体）
├── convergence/                    # 收敛诊断（表 6/表 7、图 3）
│   ├── {K,Nres,capacity,data}_lite.json / .png
│   ├── grid_{heal,pair,quench}.json
│   ├── grid.json / grid.md / grid_spatial.png
├── lambda_scan/                    # λ 参数扫描（表 5、图 4）
│   ├── {case}_{variant}.json
│   ├── nets/                       # 非 full 变体网络缓存
│   └── summary.md / summary.png
├── generalization.json             # 未见 IC / 迁移 / 长时间（表 4）
└── stage3/
    ├── nets/{case}_lite_s{seed}.pt # 与 lambda_scan 共享的 full 变体缓存
    ├── abrikosov.json              # 磁场诊断（附录 C）
    └── speedup.json                # 加速比（表 8）
```

### R4.3 数据格式

**参考解 / 网络解 `.npz`**：

```python
{
  'snaps': ndarray (M, N, N) complex64,  # M=60 帧快照
  't': ndarray (M,),
  'L': float, 'N': int, 'T': float,
  'F': ndarray (M,),                     # 自由能（ref/nn 各一份）
  'vcount': ndarray (M,),                # 涡旋格点数
  'rel_l2' / 'linf': ndarray (M,),       # 仅 NN 文件
}
```

**主表 `.json`（每个运行）** 关键字段：`e2_mean`、`e2_ic`（$t=0$ 误差）、
`nn_peak_vortex`、`ref_peak_vortex`、`seed`、`recipe`、`t_train`。

---

## R5. 训练预算与时间

### R5.1 冻结预算（`--recipe lite`，全表统一）

| 参数 | 值 | 备注 |
|---|---|---|
| $L$ | 10.0 | 域大小 |
| $N_{\mathrm{grid}}$ | 32 | 训练网格 |
| $N_{\mathrm{ref}}$ | 48 | 参考解网格（表 7 证明其误差 $\le 2.5\times10^{-4}$） |
| $M_{\mathrm{ref}}$ | 40 | 参考解时间步（表 7：$1.3\times10^{-5}$–$6.2\times10^{-4}$） |
| $T$ | 5 / 6 / 4 | heal / pair / quench |
| IC 预训练 | 200 epochs | |
| $K$ | 4 段 × 100 epochs | no_homotopy / vanilla 用 $K=1$ 且合并段预算 |
| 校正 | 100 epochs/段 + 末段 200 epochs | `correct_schedule="always"` |
| `hidden` | 128 | |
| `num_blocks` | 4 | |
| `num_freqs` | 24 | `ff_sigma=0.25` |
| $N_{\mathrm{res}}$ | 2000 | 表 6 扫描证明 250–4000 平坦 |
| $N_{\mathrm{IC}}$ | 400 | |
| $N_{\mathrm{data}}^{\max}$ | 4000 | 表 6 扫描证明 2000–60000 平坦 |
| $w_{\mathrm{pde}}, w_{\mathrm{ic}}, w_D$ | 0.1, 100, 50 | |

**预算对齐**：全方法与所有消融/基线的**总 epoch 数完全一致**，因此表 2 的
变体间比较不受预算差异污染。

### R5.2 总时间预算

| 任务 | 估计 CPU 时间（8 核并行） |
|---|---|
| 主表（54 次训练，8 分片） | 4–6 h |
| 收敛诊断（4 项扫描） | 1–2 h |
| 网格收敛（3 算例 × 空间/时间） | ~1 h |
| λ 扫描（含网络缓存复用） | ~1.5 h |
| 泛化性 3 项 + 磁场 | ~1 h |
| **总计** | **~8–11 h** |

---

## R6. 实验稳健性

### R6.1 种子敏感性（$N_{\mathrm{seed}}=3$，统一预算）

| 算例 | full | no_homotopy | no_correct | no_ff | vanilla | causal |
|---|---|---|---|---|---|---|
| heal | 0.228±0.027 | 0.267±0.082 | 0.391±0.031 | 0.195±0.046 | 0.754±0.110 | 0.936±0.088 |
| pair | 0.396±0.199 | 0.318±0.037 | 0.439±0.066 | 0.247±0.021 | 0.729±0.065 | 1.356±0.274 |
| quench | **0.377±0.014** | 0.902±0.688 | 0.614±0.048 | 0.377±0.026 | 1.177±0.061 | 1.794±0.715 |

**诚实标注的种子现象**：
- `pair/full`：一个种子停滞在 0.62（另两个 0.25/0.31），使该格 std 达 0.199；
  论文表 2 保留该值并在正文说明，不做种子筛选。
- `quench/no_homotopy`：三种子为 0.35 / 0.68 / 1.67，呈**双峰**；这正是论文
  强调"同伦的价值在于鲁棒性"的证据（full 为 0.377±0.014）。

### R6.2 实现交叉验证

- **PDE 残差**：autograd 与 4 阶中心差分交叉验证，差 < 1e-3
- **ETD2RK 与 DST**：解析解交叉验证，差 < 4.4e-7
- **quench 初值的网格无关性**：$N=32$ 与 $N=64$ 实现的双线性插值互校，
  相对差 2%（双线性插值自身的误差量级），确认同一连续场
- **网络 vs 参考解**：自检（self-vs-self）误差恒为 0

### R6.3 异常点与不可复现结果的处理

| 配置 | 本次（lite）结果 | 历史（h1）结果 | 论文处理 |
|---|---|---|---|
| `hidden=256` | 0.462（比 128 差 2.2×） | 6.345（发散） | 只报告可复现的 2.2× 退化，并注明历史发散**未能复现** |
| `K=1` | 0.229 | 0.733（受 λ 退化 bug 污染） | 采用修复后的数字（§R7.2） |
| `data=5000` | 0.203 | 0.398 | 采用新数字；扫描整体平坦 |

---

## R7. P2.6 基准设计缺陷修复（影响全部定量结论）

### R7.1 quench 初值的网格依赖性（严重）

**缺陷**：旧实现 `rng.normal(size=(N,N))` 使随机场依赖网格 $N$。
训练用 $N=32$ 实现、参考解用 $N=48$ 实现，二者是**两个独立随机场**
（相对差 $\sqrt2 \approx 1.41$）。实测 $t=0$ 的相对误差
$e_2^{\mathrm{ic}}=1.42$，即 quench 全部误差被不可约的初值失配地板污染，
且空间收敛研究完全失效（误差不随 $N$ 收敛）。

**修复**（`src/reference_solver.py::initial_condition_quench`）：固定模态集
$m,n\in\mathbb Z^2,\ m^2+n^2\le(L/\ell)^2$，按固定顺序从 RNG 抽取系数，
用 Parseval 精确连续 RMS 归一，再在内点网格上解析求值。

**验证**：修复后 $e_2^{\mathrm{ic}}$ 从 1.42 降至 0.37（残差为网络自身 IC
拟合误差）；空间误差恢复单调收敛（表 7）；quench 参考峰值涡旋数由
84（受污染）变为 72（真实）。

### R7.2 $K=1$ 的 λ 语义（中等）

**缺陷**：早期实现 $\lam_k = k/\max(K-1,1)$，$K=1$ 时退化为 $\lam=0$
（纯热方程），使"$K=1$"实际训练的是错误的问题，造成"同伦增益 4×"的
假象。修复为 $K=1 \Rightarrow \lam=1$（真正的直接训练）。

**影响**：K 扫描由 0.733→0.183（4×）变为 0.229→0.212（8%）；
论文据此把同伦的卖点从"终端精度"改写为"鲁棒性 + λ 参数覆盖"
（表 5：未见 λ 上同伦版比 λ=1-only 版好 1.8–4.2×）。

---

## R8. 论文附录索引

- **附录 A**：ETDRK2 推导细节 + 稳定性（表 7 的离散化收敛）
- **附录 B**：Fourier 特征 σ 的选择原则（含消融）
- **附录 C**：初值详细公式 + 磁场可信度诊断
- **附录 D**：完整 GL 协变导数处理
- **附录 E**：本文档（可复现性清单）+ 负结果目录

---

## R9. 审稿人快速入口

**30 秒读懂**：
1. `README.md` → 方法摘要 + 命令清单
2. `docs/manuscript_cmame.tex` → Abstract + 节结构
3. 跑 `python scripts/emit_tables.py` → 看 `results/benchmarks_ms/summary.json`

**5 分钟复现关键数字**（直接用已发布的汇总文件）：
```bash
python scripts/emit_tables.py        # 基准表 / 消融表 / 激活模式表
python scripts/emit_extra_tables.py  # 扩展表（λ 扫描 / 泛化 / 网格 / 磁场 / 加速比）
# 期望（基准表，3 种子均值）：heal full 0.228, pair full 0.396, quench full 0.377
# 期望（激活模式表，3 种子均值）：scheduled 0.228/0.396/0.377,
#       a-posteriori 0.215/0.601/0.377，且 n_corrected=4/4（阈值从未生效）
```

**从零重跑**：见 §R3，总计 ~8–11 h（8 核 CPU）。

**错误时查文档**：
- "Fourier 特征为什么 no_ff 反而更好？" → 论文 §Discussion 第 1 条
- "hidden=256 为什么退化？" → 论文 §Convergence diagnostics + §Discussion 第 2 条
- "为什么触发判据用真实 PDE 残差？" → 论文 §Method（Algorithm 1）

---

## R10. 已知边界（论文 Discussion 节同步）

1. **硬件基线差异**：CPU vs GPU 计时比 ~1:5-10，精度（rel-L²）不变
2. **CUDA 兼容性**：PyTorch 2.0+ 支持 CUDA 11.8/12.1/12.4，无需额外代码
3. **Python 版本**：基线 3.14，向下兼容到 3.10
4. **平台**：Windows 11 / Linux x86_64 / macOS ARM 已测试
5. **长时间外推**：训练区间外（$t>T$）误差迅速增长（heal：0.27→0.96），
   不支持外推使用
6. **未见初值**：跨 IC 零样本误差退化 2.5–2.8×；迁移学习（fine-tune）
   在同等预算下无增益（0.97×）
