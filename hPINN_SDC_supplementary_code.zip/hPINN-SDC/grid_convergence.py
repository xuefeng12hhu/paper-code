"""
grid_convergence.py
===================
参考解（ETDRK2 + DST-I 正弦谱）的**空间与时间收敛性**验证。

动机（见 docs/paper_gap_analysis.md 阶段 9）
-------------------------------------------
论文所有 $e_2 \\approx 0.19$ 的结论都相对于 $N_{\\mathrm{ref}}=48$ 的参考解，
但参考解自身的离散误差从未量化——审稿人无法排除"$0.19$ 里有相当一部分是
参考解误差"。本脚本给出：

1. **空间收敛（谱）**：ETDRK2 的解位于 Dirichlet 正弦基张成的 $N$ 维子空间，
   因此可以**零填充精确重构**到任意细网格（带限插值，无插值误差）：
       φ(x_p,y_q) = (2/(N+1))² Σ_{m,n≤N} φ̂_{mn} sin(πmp/(N_f+1)) sin(πnq/(N_f+1))
   据此计算 ‖ψ_N − I_{N→N_f} ψ_N‖ / ‖ψ_{N_f}‖ 随 N 的衰减。

2. **时间收敛（二阶）**：固定 N，dt 逐次减半，用 Richardson 比值
   log2(e(dt)/e(dt/2)) 报告经验收敛阶。

3. **谱尾部能量**：DST 系数高阶模态占比，作为谱分辨率的独立佐证。

用法
----
    python grid_convergence.py                 # 三算例全跑
    python grid_convergence.py --cases heal
输出
----
    results/convergence/grid.json / grid.md
    results/convergence/grid_spatial.png
"""
import sys, os, json, time, argparse
sys.path.insert(0, '.')
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.reference_solver import (ETD2RK, make_initial_condition, dst2)

OUT = os.path.join("results", "convergence")
os.makedirs(OUT, exist_ok=True)

L = 10.0
N_LEVELS = [32, 48, 64, 96]      # 待检网格
N_FINE = 192                     # 视为"精确"的细网格
N_STEPS = 2000                   # 时间步数（dt 足够小，时间误差可忽略）

CASES = {
    "heal":   dict(kind="gaussian", params=dict(eps=0.8, sigma=1.5), T=5.0),
    "pair":   dict(kind="pair",     params=dict(sep=5.0, xi=0.5),   T=6.0),
    "quench": dict(kind="quench",   params=dict(ell=1.5, rms=0.4, seed=2), T=4.0),
}


def spectral_upsample(psi_coarse: torch.Tensor, N_fine: int, L: float):
    """把 N 网格上的 Dirichlet 正弦谱解精确重构到 N_fine 内点网格。

    利用 ETD2RK 解恒在 span{sin(πmx/L) sin(πny/L), m,n ≤ N} 内，
    故带限重构没有插值误差（等价于谱零填充）。
    """
    N = psi_coarse.shape[0]
    phi = (psi_coarse - 1.0)
    coeff = dst2(phi)                                   # (N, N)
    m = torch.arange(1, N + 1, dtype=torch.float64)
    p = torch.arange(1, N_fine + 1, dtype=torch.float64)
    S = torch.sin(torch.pi * p[:, None] * m[None, :] / (N_fine + 1))  # (Nf, N)
    coeff = coeff.to(torch.complex128)
    # 归一化必须取**源网格**的 (2/(N+1))^2。一维 DST-I 系数 X_m 与连续正弦
    # 展开系数 c_m 满足 X_m = c_m (N+1)/2；二维即 X_mn = c_mn (N+1)^2/4。
    # 重构到细网格只是把基函数在细网格上求值，系数不变，故前因子仍为
    # (2/(N+1))^2。旧版误用 (2/(N_fine+1))^2，把重构场整体缩小
    # ((N_fine+1)/(N+1))^2 倍（N=32 -> 192 时约 34 倍），使误差被
    # 替换为"细解自身的扰动幅度"，空间收敛曲线被人为压平。
    phi_f = (2.0 / (N + 1)) ** 2 * (S.to(torch.complex128) @ coeff
                                    @ S.to(torch.complex128).T)
    return (1.0 + phi_f).to(torch.complex64)


def _selftest_upsample(verbose=True):
    """回归自检：可在 N 网格上精确表示的正弦模态，带限重构应无误差。

    旧版前因子误用 N_fine，会把重构场整体缩小约 (N_fine/N)^2 倍，
    此自检即该 bug 的守门测试。
    """
    N, Nf, Lb = 32, 192, 10.0
    x = Lb / (N + 1) * torch.arange(1, N + 1, dtype=torch.float64)
    X, Y = torch.meshgrid(x, x, indexing="ij")

    def f(xx, yy):
        return (0.3 * torch.sin(torch.pi * 3 * xx / Lb)
                * torch.sin(torch.pi * 2 * yy / Lb)
                + 0.1 * torch.sin(torch.pi * 7 * xx / Lb)
                * torch.sin(torch.pi * 5 * yy / Lb))

    psi = (1.0 + f(X, Y)).to(torch.complex64)
    up = spectral_upsample(psi, Nf, Lb)
    xf = Lb / (Nf + 1) * torch.arange(1, Nf + 1, dtype=torch.float64)
    Xf, Yf = torch.meshgrid(xf, xf, indexing="ij")
    exact = (1.0 + f(Xf, Yf)).to(torch.complex128)
    err = (up.to(torch.complex128) - exact).abs().max().item()
    # 阈值取 float32 精度量级：complex64 往返本身约 1e-7。该自检的目的是
    # 捕捉量级级错误（旧版前因子使误差达 0.38），而非 float32 舍入。
    ok = err < 1e-5
    if verbose:
        print(f"[selftest] band-limited upsample max|err| = {err:.2e} "
              f"{'OK' if ok else 'FAIL'}", flush=True)
    assert ok, "spectral_upsample 归一化错误"
    return err


def spatial_study(cname, case, verbose=True):
    T, Lb = case["T"], L
    dt = T / N_STEPS

    # --- 细网格"精确"解 ---
    psi0f = make_initial_condition(case["kind"], N_FINE, Lb, **case["params"])
    t0 = time.time()
    fine = ETD2RK(lam=1.0, L_box=Lb, N=N_FINE).integrate(
        psi0f, dt=dt, n_steps=N_STEPS, snapshot_every=N_STEPS)[-1]
    t_fine = time.time() - t0

    rows = []
    for N in N_LEVELS:
        psi0 = make_initial_condition(case["kind"], N, Lb, **case["params"])
        t0 = time.time()
        psi_N = ETD2RK(lam=1.0, L_box=Lb, N=N).integrate(
            psi0, dt=dt, n_steps=N_STEPS, snapshot_every=N_STEPS)[-1]
        t_run = time.time() - t0

        up = spectral_upsample(psi_N, N_FINE, Lb)
        num = (up - fine).abs().pow(2).sum().sqrt().item()
        den = fine.abs().pow(2).sum().sqrt().item()
        rel = num / den
        linf = (up - fine).abs().max().item()

        # 谱尾部能量占比（自身解的高 4 阶模态）
        c = dst2(psi_N - 1.0).abs()
        tail = (c[-4:, :].sum() + c[:, -4:].sum()).item() / max(c.sum().item(), 1e-30)

        rows.append(dict(N=N, rel_l2_vs_fine=rel, linf_vs_fine=linf,
                         tail_frac=tail, t_run=t_run))
        if verbose:
            print(f"    N={N:3d}: rel-L2 vs N={N_FINE} = {rel:.3e}, "
                  f"Linf = {linf:.3e}, tail = {tail:.1e} ({t_run:.1f}s)",
                  flush=True)
    return dict(case=cname, T=T, N_fine=N_FINE, n_steps=N_STEPS,
                t_fine=t_fine, rows=rows)


def temporal_study(N=48, case=None, n_list=(63, 125, 250, 500, 1000)):
    """固定 N，dt 逐次减半的相对误差与经验收敛阶。"""
    T = case["T"]
    psi0 = make_initial_condition(case["kind"], N, L, **case["params"])
    solver = ETD2RK(lam=1.0, L_box=L, N=N)
    dt0 = T / n_list[0]
    ref = solver.integrate(psi0, dt=dt0 / 2 ** (len(n_list)),
                           n_steps=n_list[0] * 2 ** (len(n_list)),
                           snapshot_every=n_list[0] * 2 ** (len(n_list)))[-1]
    out, prev = [], None
    for n in n_list:
        dt = T / n
        sol = solver.integrate(psi0, dt=dt, n_steps=n, snapshot_every=n)[-1]
        err = (sol - ref).abs().max().item()
        order = None if prev is None else float(np.log2(prev / err))
        out.append(dict(n_steps=n, dt=dt, linf_err=err, order=order))
        prev = err
    return out


def main():
    _selftest_upsample()
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default="heal,pair,quench")
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--force", action="store_true",
                    help="忽略逐算例缓存，强制重算")
    args = ap.parse_args()
    torch.set_num_threads(args.threads)

    sel = [c.strip() for c in args.cases.split(",") if c.strip()]
    results = []
    for cname in sel:
        case = CASES[cname]
        fp = os.path.join(OUT, f"grid_{cname}.json")
        if not args.force and os.path.exists(fp):
            # 逐算例缓存：进程被中断时已完成算例不必重算
            with open(fp, encoding="utf-8") as f:
                sp = json.load(f)
            print(f"== {cname} (T={case['T']}) == [resume from cache]",
                  flush=True)
        else:
            print(f"== {cname} (T={case['T']}) ==", flush=True)
            sp = spatial_study(cname, case)
            tm = temporal_study(48, case)
            sp["temporal"] = tm
            with open(fp, "w", encoding="utf-8") as f:
                json.dump(sp, f, indent=1)
        results.append(sp)
        for r in sp["temporal"]:
            print(f"    dt=T/{r['n_steps']:5d}: Linf={r['linf_err']:.2e} "
                  f"order={r['order'] if r['order'] is None else round(r['order'],2)}",
                  flush=True)

    with open(os.path.join(OUT, "grid.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, indent=1)

    # ---- 报告 ----
    lines = ["# 参考解收敛性", "",
             f"细网格基准 N_fine = {N_FINE}，时间步数 = {N_STEPS}（H1 配方口径）。", "",
             "## 空间收敛（带限精确重构 vs N_fine）", "",
             "| 算例 | N | rel-L2 vs N_fine | Linf vs N_fine | 谱尾部占比 |",
             "|---|---|---|---|---|"]
    for r in results:
        for row in r["rows"]:
            lines.append(f"| {r['case']} | {row['N']} | {row['rel_l2_vs_fine']:.3e} "
                         f"| {row['linf_vs_fine']:.3e} | {row['tail_frac']:.1e} |")
    lines += ["", "## 时间收敛（N=48，dt 减半）", "",
              "| 算例 | n_steps | dt | Linf 误差 | 经验阶 |", "|---|---|---|---|---|"]
    for r in results:
        for row in r["temporal"]:
            o = "-" if row["order"] is None else f"{row['order']:.2f}"
            lines.append(f"| {r['case']} | {row['n_steps']} | {row['dt']:.2e} "
                         f"| {row['linf_err']:.2e} | {o} |")
    with open(os.path.join(OUT, "grid.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    # ---- 图 ----
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for r in results:
        Ns = [row["N"] for row in r["rows"]]
        es = [row["rel_l2_vs_fine"] for row in r["rows"]]
        axes[0].semilogy(Ns, es, "o-", label=r["case"])
        ts = [row["dt"] for row in r["temporal"]]
        te = [row["linf_err"] for row in r["temporal"]]
        axes[1].loglog(ts, te, "o-", label=r["case"])
    # dt² 参考斜率
    dts = np.array([row["dt"] for row in results[0]["temporal"]])
    axes[1].loglog(dts, 1e-3 * (dts / dts[0]) ** 2, "k--", lw=1, label=r"$\propto dt^2$")
    axes[0].set_xlabel("$N$"); axes[0].set_ylabel(r"rel-$L^2$ vs $N_{\rm fine}$")
    axes[0].set_title("Spatial (spectral) convergence")
    axes[1].set_xlabel(r"$\Delta t$"); axes[1].set_ylabel(r"$L^\infty$ error")
    axes[1].set_title("Temporal convergence")
    for ax in axes:
        ax.grid(alpha=0.3, which="both"); ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "grid_spatial.png"), dpi=130)
    plt.close(fig)
    print(f"[done] -> {OUT}/grid.json, grid.md, grid_spatial.png")


if __name__ == "__main__":
    main()
