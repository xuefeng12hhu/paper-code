"""
lambda_scan.py
==============
代理模型的 **λ 泛化** 实验（论文核心经济动机的实证）。

动机（见 docs/paper_gap_analysis.md 阶段 9）
-------------------------------------------
论文把"parametric λ-scan"作为主要经济动机反复陈述，但实验部分唯一与 λ 相关
的结果只有同伦路径的 Lipschitz 常数（stage4/lambda_sweep.json），**从未给出
任何 e₂(λ) 曲线**。本脚本补上这一空白，并进一步回答一个更有说服力的问题：

    同伦训练（K=4，训练中见过 λ∈{0,1/3,2/3,1}）是否比"只在 λ=1 训练"
    具有更好的 λ 泛化能力？

若是，则同伦延拓的价值不仅是"训练更容易"，更是"一次训练即可覆盖 λ 参数族"——
这正好支撑 ETDRK2 需要逐 λ 重算而代理模型不需要的论断。

用法
----
    python lambda_scan.py --cases heal --variants full,no_homotopy
    python lambda_scan.py --cases heal,pair,quench --variants full --recipe lite

输出
----
    results/lambda_scan/<case>_<variant>.json
    results/lambda_scan/summary.md / summary.png
"""
import sys, os, json, time, argparse
sys.path.insert(0, '.')
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.homotopy_nn import (TrainConfig, train_homotopy_nn, evaluate_grid,
                             HomotopyNet)
from src.reference_solver import ETD2RK, make_initial_condition
from src.evaluation import rel_l2_error, linf_error

OUT = os.path.join("results", "lambda_scan")
os.makedirs(OUT, exist_ok=True)

# full 变体的训练配置与 generalization.py 的完整方法网络完全一致，
# 二者共享缓存目录避免重复训练；其余变体用本地缓存。
GEN_NETS = os.path.join("results", "stage3", "nets")
LOCAL_NETS = os.path.join(OUT, "nets")

L = 10.0
N_REF = 48
M_REF = 40
LAMBDAS = [0.0, 0.25, 0.5, 0.75, 1.0]

CASES = {
    "heal":   dict(kind="gaussian", params=dict(eps=0.8, sigma=1.5), T=5.0),
    "pair":   dict(kind="pair",     params=dict(sep=5.0, xi=0.5),   T=6.0),
    "quench": dict(kind="quench",   params=dict(ell=1.5, rms=0.4, seed=2), T=4.0),
}

RECIPES = {
    "h1": dict(ic_pretrain_epochs=300, K=4, stage_epochs=300,
               correct_epochs=300, final_correct_epochs=900,
               N_data_max=20000),
    "lite": dict(ic_pretrain_epochs=200, K=4, stage_epochs=100,
                 correct_epochs=100, final_correct_epochs=200,
                 N_data_max=4000),
}


def make_cfg(recipe, variant, case, seed):
    R = RECIPES[recipe]
    total_stage = R["K"] * R["stage_epochs"]
    total_corr = R["correct_epochs"] * (R["K"] - 1) + R["final_correct_epochs"]
    base = dict(L=L, T=case["T"], ic_kind=case["kind"], ic_params=case["params"],
                seed=seed, ic_pretrain_epochs=R["ic_pretrain_epochs"],
                N_data_max=R["N_data_max"], N_grid=32, N_ic=400)
    if variant == "full":
        return TrainConfig(**base, K=R["K"], E_k=[R["stage_epochs"]] * R["K"],
                           correct_schedule="always",
                           correct_epochs=R["correct_epochs"],
                           final_correct_epochs=R["final_correct_epochs"],
                           final_extra_data=True)
    if variant == "no_homotopy":
        return TrainConfig(**base, K=1, E_k=[total_stage],
                           correct_schedule="always", correct_epochs=0,
                           final_correct_epochs=total_corr,
                           final_extra_data=True)
    if variant == "no_correct":
        return TrainConfig(**base, K=R["K"], E_k=[R["stage_epochs"]] * R["K"],
                           correct_schedule="always", correct_epochs=0,
                           final_correct_epochs=0, final_extra_data=False)
    raise ValueError(variant)


def get_trained_net(cfg, cname, variant, recipe, seed):
    """带缓存的网络获取：full 变体与 generalization.py 共享 stage3/nets。"""
    if variant == "full":
        os.makedirs(GEN_NETS, exist_ok=True)
        cache, key = GEN_NETS, f"{cname}_{recipe}_s{seed}"
    else:
        os.makedirs(LOCAL_NETS, exist_ok=True)
        cache, key = LOCAL_NETS, f"{cname}_{variant}_{recipe}_s{seed}"
    fp = os.path.join(cache, key + ".pt")
    if os.path.exists(fp):
        net = HomotopyNet(hidden=cfg.hidden, num_blocks=cfg.num_blocks,
                          num_freqs=cfg.num_freqs, sigma=cfg.ff_sigma,
                          in_dim=4, out_dim=2, L=cfg.L,
                          seed=cfg.seed).to(cfg.device)
        net.load_state_dict(torch.load(fp, map_location=cfg.device))
        print(f"  [{key}] net loaded from cache", flush=True)
        return net, 0.0, True
    t0 = time.time()
    net, hist = train_homotopy_nn(cfg, verbose=False)
    t_train = time.time() - t0
    torch.save(net.state_dict(), fp)
    print(f"  [{key}] trained in {t_train:.0f}s "
          f"(lam path={[round(h['lam'], 3) for h in hist]})", flush=True)
    return net, t_train, False


def run(cname, variant, recipe, seed, verbose=True):
    case = CASES[cname]
    fjson = os.path.join(OUT, f"{cname}_{variant}.json")
    if os.path.exists(fjson):
        with open(fjson, encoding="utf-8") as f:
            rec = json.load(f)
        if rec.get("recipe") == recipe:
            print(f"  [{cname}/{variant}] cached", flush=True)
            return rec

    cfg = make_cfg(recipe, variant, case, seed)
    net, t_train, net_cached = get_trained_net(cfg, cname, variant,
                                               recipe, seed)

    rows = []
    for lam in LAMBDAS:
        psi0 = make_initial_condition(case["kind"], N_REF, L, **case["params"])
        solver = ETD2RK(lam=lam, L_box=L, N=N_REF)
        t0 = time.time()
        ref = solver.integrate(psi0, dt=case["T"] / (M_REF - 1),
                               n_steps=M_REF - 1, snapshot_every=1)
        t_etd = time.time() - t0

        t0 = time.time()
        out = evaluate_grid(net, cfg, lam=lam, M=M_REF, N=N_REF)
        t_nn = time.time() - t0

        snaps = torch.tensor(out["snaps"])
        e2 = rel_l2_error(snaps, ref).numpy()
        ei = linf_error(snaps, ref).numpy()
        rows.append(dict(lam=lam, e2_mean=float(e2.mean()), e2_final=float(e2[-1]),
                         linf_final=float(ei[-1]),
                         t_etd=float(t_etd), t_nn=float(t_nn),
                         speedup_query=float(t_etd / max(t_nn, 1e-9))))
        print(f"    lam={lam:.2f}: e2={e2.mean():.3f}  "
              f"(ETD {t_etd*1e3:.0f} ms vs NN {t_nn*1e3:.0f} ms)", flush=True)

    t_etd1 = rows[-1]["t_etd"]
    t_nn1 = rows[-1]["t_nn"]
    rec = dict(case=cname, variant=variant, recipe=recipe, seed=seed,
               t_train=t_train, net_cached=net_cached, rows=rows,
               e2_mean_over_lam=float(np.mean([r["e2_mean"] for r in rows])),
               e2_worst_lam=float(np.max([r["e2_mean"] for r in rows])),
               e2_at_lam1=float(rows[-1]["e2_mean"]),
               break_even_queries=(int(np.ceil(t_train / max(t_etd1 - t_nn1, 1e-9)))
                                   if t_train > 0 else None),
               break_even_lamscans=(int(np.ceil(
                   t_train / max(sum(r["t_etd"] for r in rows)
                                 - sum(r["t_nn"] for r in rows), 1e-9)))
                   if t_train > 0 else None))
    with open(fjson, "w", encoding="utf-8") as f:
        json.dump(rec, f, indent=1)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default="heal")
    ap.add_argument("--variants", default="full,no_homotopy")
    ap.add_argument("--recipe", default="lite", choices=list(RECIPES.keys()))
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--threads", type=int, default=8)
    args = ap.parse_args()
    torch.set_num_threads(args.threads)

    cases = [c.strip() for c in args.cases.split(",") if c.strip()]
    variants = [v.strip() for v in args.variants.split(",") if v.strip()]
    recs = [run(c, v, args.recipe, args.seed) for c in cases for v in variants]

    lines = ["# λ 泛化实验", "",
             f"recipe={args.recipe}, seed={args.seed}, "
             f"λ ∈ {LAMBDAS}", "",
             "| 算例 | 变体 | 训练中见过的 λ | e₂(λ=1) | e₂ 全 λ 均值 | e₂ 全 λ 最差 |",
             "|---|---|---|---|---|---|"]
    for r in recs:
        lines.append(f"| {r['case']} | {r['variant']} | "
                     f"{[0.0, 0.333, 0.667, 1.0] if r['variant'] == 'full' else [1.0]} "
                     f"| {r['e2_at_lam1']:.3f} | {r['e2_mean_over_lam']:.3f} "
                     f"| {r['e2_worst_lam']:.3f} |")
    lines += ["", "| 算例 | 变体 | 训练耗时 | 单次 ETD 查询 | 单次 NN 查询 | break-even 查询数 | break-even λ-scan 次数 |",
              "|---|---|---|---|---|---|---|"]
    for r in recs:
        rows = r["rows"]
        lines.append(f"| {r['case']} | {r['variant']} | {r['t_train']:.0f}s "
                     f"| {rows[-1]['t_etd']*1e3:.0f} ms | {rows[-1]['t_nn']*1e3:.0f} ms "
                     f"| {r['break_even_queries']} | {r['break_even_lamscans']} |")
    with open(os.path.join(OUT, "summary.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    fig, ax = plt.subplots(figsize=(6, 4.2))
    for r in recs:
        ax.semilogy([x["lam"] for x in r["rows"]], [x["e2_mean"] for x in r["rows"]],
                    "o-", label=f"{r['case']} / {r['variant']}")
    ax.axvline(1.0, color="grey", ls=":", lw=1)
    ax.set_xlabel(r"$\lambda$"); ax.set_ylabel(r"$e_2$ (mean)")
    ax.set_title(r"$\lambda$ generalisation of the surrogate")
    ax.grid(alpha=0.3, which="both"); ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "summary.png"), dpi=130)
    plt.close(fig)
    print(f"[done] -> {OUT}/summary.md, summary.png")


if __name__ == "__main__":
    main()
