"""冒烟测试脚本：快速验证训练管线（P0 修复后）。"""
import sys, time
sys.path.insert(0, '.')
import torch
from src.homotopy_nn import TrainConfig, train_homotopy_nn, evaluate_grid, residual_rms
from src.reference_solver import solve_tdgl, total_mass, vortex_count, initial_condition

torch.manual_seed(0)

# 最小化冒烟测试（K=2 快速验证；tol 设小以便观察 learn-then-correct 触发）
cfg = TrainConfig(K=2, E_k=[60, 60], N_res=400, N_ic=100,
                  N_data_max=500, tol=1e-9, correct_epochs=10)
print('[train] K=2 quick test...')
t0 = time.time()
net, hist = train_homotopy_nn(cfg, verbose=True)
print(f'elapsed: {time.time()-t0:.1f}s')

print('[eval] lam=1.0 ...')
out = evaluate_grid(net, cfg, lam=1.0, M=10, N=32)
m = out['mass']
print(f'  mass range: {float(m.min()):.3f} -> {float(m.max()):.3f}')

# 与参考解定量对比（P1.1 的雏形）
ref = solve_tdgl(lam=1.0, L=cfg.L, N=32, T=cfg.T, M=10,
                 eps=cfg.eps, sigma=cfg.sigma_ic)
nn = torch.tensor(out['snaps'])
rel_l2 = ((nn - ref).abs()**2).sum().sqrt() / (ref.abs()**2).sum().sqrt()
print(f'  rel-L2 vs ETD2RK ref: {rel_l2.item():.3e}')
print(f'  ref net vortex: {vortex_count(ref[-1]).item():+.3f}')

# 触发记录
n_correct = sum(1 for _ in hist)  # history 每阶段一条
print(f'  stages: {len(hist)}, residual RMS: '
      f'{[f"{h["residual"]:.2e}" for h in hist]}')
print('OK smoke test passed.')
