"""
benchmarks.py
=============
阶段 1 定量基准：三类算例 × (参考解诊断 + NN 定量误差)。

算例套件（见 docs/formulas.md 第 8 节）：
  1. heal   高斯抑制区愈合（无拓扑，能量耗散基准）
  2. pair   涡旋-反涡旋对湮灭（拓扑事件，sep=5 时 t≈3 湮灭）
  3. quench 淬火无序相有序化（自发成核 ~88 个涡旋 + 级联湮灭）

输出（results/benchmarks/）：
  - <case>_ref.npz        参考解快照 + 能量 + 涡旋计数
  - <case>_nn.npz         网络解 + 误差表
  - <case>_diag.png       诊断图（能量、误差、涡旋数）
  - summary.md            汇总表
"""
import sys, time, os
sys.path.insert(0, '.')
import torch
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.reference_solver import ETD2RK, make_initial_condition
from src.homotopy_nn import TrainConfig, train_homotopy_nn, evaluate_grid
from src.evaluation import (free_energy, dissipation_residual, rel_l2_error,
                            linf_error, vortex_trajectory)

OUT = os.path.join("results", "benchmarks")
os.makedirs(OUT, exist_ok=True)

torch.manual_seed(0)

# 参考解分辨率 / 评估网格
N_REF = 48
# 阶段 2 配方：H1 经验最优（e2=0.186 on heal）。tol 仅作为 fallback；
# correct_schedule="always" 默认每段都校正，故 tol 实际不起作用。
NN_KW = dict()   # 用 TrainConfig 默认即可（H1 配方）

CASES = [
    dict(name="heal", ic_kind="gaussian", ic_params=dict(eps=0.8, sigma=1.5),
         T=5.0, M_ref=60),
    dict(name="pair", ic_kind="pair", ic_params=dict(sep=5.0, xi=0.5),
         T=6.0, M_ref=60),
    dict(name="quench", ic_kind="quench", ic_params=dict(ell=1.5, rms=0.4, seed=2),
         T=4.0, M_ref=60),
]

summary_rows = []


def run_case(cs):
    name, T, M = cs["name"], cs["T"], cs["M_ref"]
    L = 10.0
    print(f"\n===== case: {name} (T={T}) =====")

    # ---------- 1. 参考解 ----------
    psi0 = make_initial_condition(cs["ic_kind"], N_REF, L, **cs["ic_params"])
    solver = ETD2RK(lam=1.0, L_box=L, N=N_REF)
    t0 = time.time()
    ref = solver.integrate(psi0, dt=T/(M-1), n_steps=M-1, snapshot_every=1)
    t_ref = time.time() - t0

    F_ref, mono = dissipation_residual(ref, L, lam=1.0)
    from src.reference_solver import vortex_map
    w = vortex_map(ref)
    vcount = (w.abs() > 0.5).sum(dim=(-1, -2)).numpy()
    vnet = w.sum(dim=(-1, -2)).numpy()
    print(f"[ref] {t_ref:.2f}s, F: {F_ref[0]:.3f}->{F_ref[-1]:.3f}, "
          f"monotone={mono}, peak vortices={int(vcount.max())} "
          f"@t={float(np.argmax(vcount))*T/(M-1):.2f}")

    # ---------- 2. NN 训练 ----------
    cfg = TrainConfig(L=L, T=T, ic_kind=cs["ic_kind"],
                      ic_params=cs["ic_params"], **NN_KW)
    t0 = time.time()
    net, hist = train_homotopy_nn(cfg, verbose=False)
    t_train = time.time() - t0
    res_hist = [h["residual"] for h in hist]
    print(f"[nn ] train {t_train:.1f}s, residual RMS: "
          f"{res_hist[0]:.2e} -> {res_hist[-1]:.2e}")

    # ---------- 3. 定量误差 ----------
    out = evaluate_grid(net, cfg, lam=1.0, M=M, N=N_REF)
    nn_snaps = torch.tensor(out["snaps"])          # (M, N, N) 含 t=0
    e2 = rel_l2_error(nn_snaps, ref).numpy()
    ei = linf_error(nn_snaps, ref).numpy()
    F_nn = free_energy(nn_snaps, L, lam=1.0).numpy()
    t_grid = np.linspace(0, T, M)
    print(f"[err] rel-L2: mean={e2.mean():.3e}, final={e2[-1]:.3e}; "
          f"Linf final={ei[-1]:.3e}")

    # NN 涡旋计数
    w_nn = vortex_map(nn_snaps)
    vcount_nn = (w_nn.abs() > 0.5).sum(dim=(-1, -2)).numpy()

    # ---------- 4. 保存 ----------
    np.savez(os.path.join(OUT, f"{name}_ref.npz"),
             snaps=ref.numpy(), F=F_ref.numpy(), vcount=vcount, vnet=vnet,
             t=t_grid, N=N_REF, L=L, T=T)
    np.savez(os.path.join(OUT, f"{name}_nn.npz"),
             snaps=nn_snaps.numpy(), F=F_nn, vcount=vcount_nn,
             rel_l2=e2, linf=ei, t=t_grid, t_train=t_train,
             residual_hist=np.array(res_hist))

    # ---------- 5. 诊断图 ----------
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    axes[0].plot(t_grid, F_ref, "k-", label="ETDRK2 ref")
    axes[0].plot(t_grid, F_nn, "r--", label="homotopy NN")
    axes[0].set_xlabel("t"); axes[0].set_ylabel(r"$F_\lambda[\psi]$")
    axes[0].set_title(f"{name}: free energy"); axes[0].legend(); axes[0].grid(alpha=0.3)

    axes[1].semilogy(t_grid, np.maximum(e2, 1e-10), "b-", label="rel-L2")
    axes[1].semilogy(t_grid, np.maximum(ei, 1e-10), "g--", label="L-inf")
    axes[1].set_xlabel("t"); axes[1].set_ylabel("error vs ref")
    axes[1].set_title(f"{name}: NN error"); axes[1].legend(); axes[1].grid(alpha=0.3)

    axes[2].plot(t_grid, vcount, "k-", label="ref |w|>0.5 cells")
    axes[2].plot(t_grid, vcount_nn, "r--", label="NN")
    axes[2].set_xlabel("t"); axes[2].set_ylabel("vortex cells")
    axes[2].set_title(f"{name}: vortices"); axes[2].legend(); axes[2].grid(alpha=0.3)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, f"{name}_diag.png"), dpi=130)
    plt.close(fig)

    summary_rows.append(dict(
        name=name, T=T, t_ref=t_ref, t_train=t_train,
        e2_mean=float(e2.mean()), e2_final=float(e2[-1]),
        ei_final=float(ei[-1]), F_mono=bool(mono),
        peak_vortex=int(vcount.max()), nn_peak_vortex=int(vcount_nn.max()),
        res_first=float(res_hist[0]), res_last=float(res_hist[-1])))


for cs in CASES:
    run_case(cs)

# ---------- 汇总表 ----------
with open(os.path.join(OUT, "summary.md"), "w", encoding="utf-8") as f:
    f.write("# 阶段 1 基准汇总\n\n")
    f.write("| 算例 | T | 参考解耗时 | NN训练耗时 | rel-L2 均值 | rel-L2 末帧 | L∞ 末帧 | F单调 | 峰值涡旋(参考) | 峰值涡旋(NN) | 残差RMS首→末 |\n")
    f.write("|---|---|---|---|---|---|---|---|---|---|---|\n")
    for r in summary_rows:
        f.write(f"| {r['name']} | {r['T']} | {r['t_ref']:.2f}s | {r['t_train']:.0f}s | "
                f"{r['e2_mean']:.2e} | {r['e2_final']:.2e} | {r['ei_final']:.2e} | "
                f"{'✓' if r['F_mono'] else '✗'} | {r['peak_vortex']} | "
                f"{r['nn_peak_vortex']} | {r['res_first']:.1e}→{r['res_last']:.1e} |\n")
    f.write("\n注：阶段 2 冻结配方（H1）。NN = IC 预训练 300 + K=4×300 epochs + "
            "校正 300×3 + 末段 900 epochs (M×2 数据)。\n"
            "ref = ETDRK2 DST 谱方法 N=48。\n")

print("\n[done] benchmarks saved to", OUT)
for r in summary_rows:
    print(f"  {r['name']:8s} rel-L2 mean={r['e2_mean']:.2e} "
          f"peak_vortex ref/nn={r['peak_vortex']}/{r['nn_peak_vortex']}")
