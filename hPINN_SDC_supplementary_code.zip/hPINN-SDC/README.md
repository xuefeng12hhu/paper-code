# homotopy-tdgl

**Homotopy PINN with spectral-data correction for the time-dependent Ginzburg–Landau equation (TDGL).**

A hybrid solver that couples a homotopy physics-informed neural network (hPINN) with exponential-time-differencing second-order Runge–Kutta (ETD2RK) spectral snapshots, for solving the time-dependent Ginzburg–Landau equation

$$
\partial_t \psi = \nabla^2\psi + \lambda(1-|\psi|^2)\,\psi,\quad \psi|_{\partial\Omega}=1,\ \psi(\cdot,0)=\psi_0,
$$

where the homotopy parameter $\lambda\in[0,1]$ continuously turns on the cubic nonlinearity. See `docs/paper_outline.md` for the paper structure.

---

## Quick Start (复现全部基准)

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 跑通三个基准算例（heal / pair / quench），~5-10 分钟/算例
python benchmarks.py
# 产物：results/benchmarks/{heal,pair,quench}_ref.npz + _nn.npz + _diag.png + summary.md

# 3. 跨算例消融（heal × 5 种子 + pair/quench × 2 种子），~30-60 分钟
python ablation.py
# 产物：results/ablation/<variant>_seed<s>.json + summary.md + ablation.png

# 4. K / Nres / capacity / data 收敛扫描
python convergence.py --study K
python convergence.py --study Nres
python convergence.py --study capacity
python convergence.py --study data
# 产物：results/convergence/<study>.json + .png

# 5. 单点 demo（最小可运行示例）
python run_demo.py
```

## 仓库结构

```
src/
  reference_solver.py    - ETD2RK + DST 正弦谱参考求解器（含完整 GL 扩展）
  homotopy_nn.py         - 同伦 PINN 网络、TrainConfig、训练算法、触发判据
  evaluation.py          - 误差指标 + 物理诊断（自由能 / 涡旋 / 耗散）
  visualize.py           - 诊断图（场对比 / 自由能曲线 / 涡旋位置）
docs/
  paper_outline.md       - 论文结构大纲 + Abstract 草稿
  formulas.md            - 公式手册（GL、同伦、网络、ETD2RK、IC、损失）
  theory.md              - 同伦路径适定性 + a posteriori 界 + 收敛性
  related_work.md        - Related Work 章节素材
  reproducibility.md     - 论文可复现性清单
  paper_gap_analysis.md  - 阶段计划与 gap 分析
benchmarks.py           - 入口 1：三算例基准
ablation.py             - 入口 2：跨算例消融
convergence.py          - 入口 3：K/Nres/capacity/data 收敛扫描
run_demo.py             - 入口 4：单点 demo
results/
  benchmarks/            - 基准跑产物
  ablation/              - 消融跑产物
  convergence/           - 收敛扫描产物
  stage3/                - P3 模型升级产物（含 B 场扩展、加速比、迁移学习）
  stage4/                - P4 理论验证产物（4 份 JSON）
references.bib           - BibTeX 文献库
requirements.txt         - 依赖清单
```

## 方法核心（10 行摘要）

1. **同伦映射**：$\partial_t\psi=\nabla^2\psi+\lambda(1-|\psi|^2)\psi$ 把 $\lambda=1$（完整 GL）连续延拓到 $\lambda=0$（纯热方程）
2. **网络**：Fourier-feature + 残差块 MLP，3 层 × 128 单元，输入 $(x,y,t,\lambda)\in\mathbb R^4$，输出 $\psi\in\mathbb C$
3. **两阶段训练**：先 IC 预训练 200 epochs → 再 $K=2$ 段同伦 PINN 各 300 epochs → 再 900 epochs 数据校正
4. **数据校正触发器**：每段末在 250 配置点上算真实 PDE 残差 RMS，若 < tol=0.5 则触发 ETD2RK 60 帧采样，加入 $w_D=50$ 的监督损失
5. **三算例**：heal（高斯凹陷愈合）/ pair（V-AV 印迹湮灭）/ quench（Kibble-Zurek 涡旋粗化）
6. **数值精度**：rel-L² 跨算例 0.18-0.41（vs 纯 PINN 0.41-0.94，1.7-2.5× 改善）
7. **加速比**：单查询 ~750× 快；摊销优势在 ~500-6500 次查询后显现
8. **诚实负结果**：Fourier 特征在数据锚定 regime 下略有害（no_ff 0.175 < full 0.207）；hidden=256 灾难性发散（e2=6.3）

## 依赖

详见 `requirements.txt`。基线：

- Python 3.14+
- PyTorch 2.0+（CPU/CUDA 兼容）
- NumPy, Matplotlib

## 引用

论文投稿中。代码引用：

```bibtex
@software{homotopy_tdgl_2026,
  title={homotopy-tdgl: Homotopy PINN with spectral-data correction for TDGL},
  author={...},
  year={2026},
  url={https://github.com/.../homotopy-tdgl}
}
```

## 许可

学术研究使用。详见 `LICENSE`（待添加）。