"""
make_figure_9_speedup.py
=========================
Fig 9: Acceleration ratio of neural surrogate vs. ETDRK2.

Plots cumulative wall-clock time vs. number of queries for two grid sizes
(N=32 and N=64). Shows ETDRK2 cost, surrogate training, surrogate inference
and the break-even query count.

Typesetting:
  - All text and math use a Times-like serif (Times New Roman / STIX),
    matching the manuscript's main font.
  - Scalar variables are typeset italic; subscripts/superscripts follow
    LaTeX convention.
  - Log axes display ticks as $10^k$ with upright exponent to avoid
    crowding from the default "1000, 10000, 100000" string labels.

Data source: results/stage3/speedup.json
Output:      results/figures/fig9_speedup.{pdf,png}
"""
from __future__ import annotations
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style
use_style()

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FixedLocator, FuncFormatter, NullFormatter

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "results", "figures")
os.makedirs(OUT_DIR, exist_ok=True)
DATA = os.path.join(os.path.dirname(__file__), "..", "results", "stage3", "speedup.json")


# -- tick formatters ---------------------------------------------------------

def _log10_label(exp: int) -> str:
    """Return $10^{exp}$ as a LaTeX math string. exp==0 collapses to $10^{0}$."""
    return rf"$10^{{{exp}}}$"


def style_log_axes(ax, x_decades=(0, 1, 2, 3, 4, 5),
                   y_decades=(-3, -2, -1, 0, 1, 2)):
    """Show only 10^k major ticks as compact $10^k$ labels (no crowding),
    with minor gridlines at every 2..9 multiple of 10^k.
    """
    for axis, (x_max_dec, y_max_dec) in zip(
        (ax.xaxis, ax.yaxis),
        ((x_decades[-1], x_decades[-1] + 1), (y_decades[-1], y_decades[-1] + 1)),
    ):
        # explicit major tick locations at exactly 10^k
        if axis is ax.xaxis:
            major_locs = [10.0 ** e for e in x_decades]
        else:
            major_locs = [10.0 ** e for e in y_decades]
        axis.set_major_locator(FixedLocator(major_locs))
        axis.set_major_formatter(FuncFormatter(lambda v, _pos: _log10_label(int(np.round(np.log10(v))))))
        # minor ticks at 2..9 * 10^k (no labels, no gridlines)
        minor_locs = []
        for e in (x_decades if axis is ax.xaxis else y_decades):
            minor_locs.extend(10.0 ** e * m for m in range(2, 10))
        axis.set_minor_locator(FixedLocator(minor_locs))
        axis.set_minor_formatter(NullFormatter())
        axis.label.set_fontsize(13.0)
        for tk in axis.get_major_ticks():
            tk.label1.set_fontsize(11.0)
            tk.label2.set_fontsize(11.0)


# -- main --------------------------------------------------------------------

def main():
    with open(DATA) as f:
        data = json.load(f)

    fig, axes = plt.subplots(1, 2, figsize=(14.5, 6.0))

    for ax, key in zip(axes, ["N=32", "N=64"]):
        cfg = data[key]
        t_train = cfg["t_train"]
        t_infer = cfg["t_infer_T5"]
        t_etd = cfg["t_etd_T5"]
        be = cfg["break_even_queries"]
        e2 = cfg["e2_T5"]

        n_q = np.logspace(0, 5.5, 400)
        etd_curve = t_etd * n_q
        surrogate_curve = t_train + t_infer * n_q

        ax.loglog(n_q, etd_curve, color="#1F4E79", lw=2.2, label="ETDRK2")
        ax.loglog(n_q, surrogate_curve, color="#C00000", lw=2.2, ls="--",
                  label=r"Surrogate ($N_q$ inferences)")

        ax.axvline(be, color="#385723", ls=":", lw=1.2)
        ax.scatter([be], [t_train + t_infer * be], color="#385723", zorder=5,
                   s=80, edgecolor="black", linewidth=0.8)
        ax.annotate("Break-even\n" + rf"$N_q^{{\star}}\!\approx\!{int(be)}$",
                    xy=(be, t_train + t_infer * be),
                    xytext=(be * 1.6, t_train + t_infer * be * 3.5),
                    fontsize=12.0, ha="left",
                    arrowprops=dict(arrowstyle="->", color="#385723", lw=1.0))

        ax.fill_between(n_q, etd_curve, surrogate_curve,
                        where=(surrogate_curve < etd_curve),
                        color="#C6E0B4", alpha=0.35,
                        label="Surrogate preferable")
        ax.fill_between(n_q, etd_curve, surrogate_curve,
                        where=(surrogate_curve >= etd_curve),
                        color="#F8CBAD", alpha=0.30,
                        label="ETDRK2 preferable")

        # axis labels: italic scalars, upright unit [s]
        ax.set_xlabel(r"Number of queries $N_q$", fontsize=13.0)
        ax.set_ylabel(r"Cumulative wall-clock time $t$ $[\mathrm{s}]$",
                      fontsize=13.0)
        # title: relative L^2 italic L with superscript, italic e_2 with subscript
        ax.set_title(
            rf"{key}   (rel.\ $L^{{2}}$ err.\ $e_{{2}} = {e2:.3f}$ at $T = 5$)",
            fontsize=13.0,
        )
        ax.legend(loc="lower right", fontsize=11.0, frameon=False)
        ax.grid(False)
        style_log_axes(ax)

    fig.suptitle(r"Acceleration ratio: surrogate vs.\ ETDRK2",
                 fontsize=15.0, weight="bold", y=1.02)

    plt.tight_layout()
    out_pdf = os.path.join(OUT_DIR, "fig9_speedup.pdf")
    out_png = os.path.join(OUT_DIR, "fig9_speedup.png")
    plt.savefig(out_pdf, bbox_inches="tight")
    plt.savefig(out_png, bbox_inches="tight", dpi=200)
    print(f"[Fig 9] written to {out_pdf} and {out_png}")


if __name__ == "__main__":
    main()