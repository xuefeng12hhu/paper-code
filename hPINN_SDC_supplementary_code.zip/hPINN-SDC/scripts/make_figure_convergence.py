"""
make_figure_convergence.py
==========================
Convergence diagnostics: four sub-panels that together form the manuscript's
"Convergence diagnostics" figure (panel (a)-(d)).

  (a) homotopy-segment count K          -> K_lite.{pdf,png}
  (b) residual collocation count Nres   -> Nres_lite.{pdf,png}
  (c) network capacity (hidden width h) -> capacity_lite.{pdf,png}
  (d) data-anchor cardinality           -> data_lite.{pdf,png}

Each panel plots three relative-error metrics on a log-x sweep:
  e2_mean   : mean over the whole trajectory
  e2_final  : terminal time T=5
  e2_ic     : initial-condition anchor error

Typesetting follows the manuscript's convention:
  - Times-like serif (Times New Roman / STIX) for all text + math
  - italic scalars (K, h, t, e_2), upright subscripts for multi-letter tokens
  - log axis: compact $10^k$ major labels; minor ticks invisible
  - no background grid (cleaner look at print resolution)

Inputs : results/convergence/<study>_lite.json
Outputs: results/convergence/<study>_lite.pdf and .png

The .png is what the manuscript tex references via subfigure \\includegraphics,
so regenerating here directly updates the printed figure.
"""
from __future__ import annotations
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style
use_style()

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FixedLocator, FuncFormatter, NullFormatter

CONV_DIR = os.path.join(os.path.dirname(__file__), "..", "results", "convergence")
os.makedirs(CONV_DIR, exist_ok=True)


# -- panel configuration ------------------------------------------------------

PANELS = [
    # (json stem,   x-label,                                       legend loc)
    ("K",        r"Homotopy segments $K$",                              "upper right"),
    ("Nres",     r"Residual collocation points $N_{\mathrm{res}}$",      "upper right"),
    ("capacity", r"Hidden width $h$",                                   "upper left"),
    ("data",     r"Data anchors $N_{\mathrm{data}}^{\max}$",             "lower right"),
]


# -- helpers ------------------------------------------------------------------

def _load(study: str) -> list[dict]:
    with open(os.path.join(CONV_DIR, f"{study}_lite.json")) as f:
        return json.load(f)


def _log_ticks(axis, decades):
    """Major ticks at 10^k formatted as $10^k$; minor at 2..9 * 10^k, no labels."""
    major_locs = [10.0 ** e for e in decades]
    minor_locs = [10.0 ** e * m for e in decades for m in range(2, 10)]
    axis.set_major_locator(FixedLocator(major_locs))
    axis.set_major_formatter(
        FuncFormatter(lambda v, _p: rf"$10^{{{int(round(np.log10(v)))}}}$"))
    axis.set_minor_locator(FixedLocator(minor_locs))
    axis.set_minor_formatter(NullFormatter())
    for tk in axis.get_major_ticks():
        tk.label1.set_fontsize(11.0)
        tk.label2.set_fontsize(11.0)


def _draw_panel(ax, study: str, x_label: str, legend_loc: str = "best") -> None:
    rows = _load(study)
    x = np.array([r["value"]  for r in rows], dtype=float)
    e2_mean  = np.array([r["e2_mean"]  for r in rows])
    e2_final = np.array([r["e2_final"] for r in rows])
    e2_ic    = np.array([r["e2_ic"]    for r in rows])

    common = dict(marker="o", lw=2.0, ms=7.0, mec="black", mew=0.6)
    ax.loglog(x, e2_mean,  color="#1F4E79", label=r"Mean $e_{2}$",          **common)
    ax.loglog(x, e2_final, color="#C00000", ls="--",
              label=r"Terminal $e_{2}(T)$",                                  **common)
    ax.loglog(x, e2_ic,    color="#385723", ls=":",
              label=r"Initial-condition $e_{2}^{\mathrm{IC}}$",               **common)

    # compact tick labelling: $10^k$ only
    decades = [int(round(np.log10(x.min()))), int(round(np.log10(x.max())))]
    if decades[0] == decades[1]:
        decades = [decades[0] - 1, decades[0] + 1]
    _log_ticks(ax.xaxis, decades)

    # y axis: linear with light ticks (errors all ~ 0.1 ... 0.5)
    ax.set_yscale("linear")
    ylo, yhi = min(e2_ic.min(), e2_mean.min(), e2_final.min()), \
               max(e2_ic.max(), e2_mean.max(), e2_final.max())
    pad = 0.05 * (yhi - ylo)
    ax.set_ylim(max(0.0, ylo - pad), yhi + pad)
    ax.tick_params(axis="y", labelsize=11.0)

    ax.set_xlabel(x_label, fontsize=13.0)
    ax.set_ylabel(r"Relative error $e_{2}$", fontsize=13.0)
    # No border on the legend box; locate per-panel to avoid covering curves
    ax.legend(loc=legend_loc, fontsize=11.0, frameon=False)
    # no gridlines
    ax.grid(False)


# -- main ---------------------------------------------------------------------

def main():
    fig, axes = plt.subplots(2, 2, figsize=(12.5, 8.5))
    for ax, (study, x_label, _loc) in zip(axes.flat, PANELS):
        _draw_panel(ax, study, x_label, legend_loc=_loc)

    fig.suptitle(r"Convergence diagnostics (recipe: lite)",
                 fontsize=15.0, weight="bold", y=1.01)
    plt.tight_layout()

    # write each panel as its own file (matches the manuscript's subfigure
    # includegraphics path) AND a combined view for reference.
    for (study, x_label, loc) in PANELS:
        fig_single, ax_single = plt.subplots(figsize=(6.0, 5.4))
        _draw_panel(ax_single, study, x_label, legend_loc=loc)
        fig_single.tight_layout()
        for ext in ("pdf", "png"):
            out = os.path.join(CONV_DIR, f"{study}_lite.{ext}")
            fig_single.savefig(out, bbox_inches="tight",
                               dpi=200 if ext == "png" else None)
        plt.close(fig_single)
        print(f"[convergence] {study}: regenerated")

    plt.close(fig)


if __name__ == "__main__":
    main()