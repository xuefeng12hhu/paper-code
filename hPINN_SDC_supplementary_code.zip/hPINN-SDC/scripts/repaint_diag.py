"""
repaint_diag.py
===============
Repaint results/benchmarks/<case>_diag.png using already-saved
<case>_ref.npz and <case>_nn.npz (which contain t, F, vcount, rel_l2, linf),
without re-running the surrogate or the ETDRK2 reference.  Applies the
manuscript's shared font / math style (figure_style.use_style).
"""
from __future__ import annotations
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style
use_style()

import matplotlib.pyplot as plt
import numpy as np

OUT = os.path.join(os.path.dirname(__file__), "..", "results", "benchmarks")
CASES = ["heal", "pair", "quench"]


def repaint(case: str) -> None:
    ref = np.load(os.path.join(OUT, f"{case}_ref.npz"))
    nn  = np.load(os.path.join(OUT, f"{case}_nn.npz"))

    t      = ref["t"]
    F_ref  = ref["F"]
    v_ref  = ref["vcount"]
    F_nn   = nn["F"]
    v_nn   = nn["vcount"]
    e2     = nn["rel_l2"]
    ei     = nn["linf"]

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.0))

    # (a) free energy
    axes[0].plot(t, F_ref, "k-",  label="ETDRK2 ref.")
    axes[0].plot(t, F_nn,  "r--", label="homotopy NN")
    axes[0].set_xlabel(r"$t$")
    axes[0].set_ylabel(r"$F_\lambda[\psi]$")
    axes[0].set_title(f"{case}: free energy")
    axes[0].legend(); axes[0].grid(alpha=0.3)

    # (b) error vs ref (semilog)
    axes[1].semilogy(t, np.maximum(e2, 1e-10), "b-",  label=r"rel.-$L^2$")
    axes[1].semilogy(t, np.maximum(ei, 1e-10), "g--", label=r"$L^\infty$")
    axes[1].set_xlabel(r"$t$")
    axes[1].set_ylabel(r"error vs. ref.")
    axes[1].set_title(f"{case}: NN error")
    axes[1].legend(); axes[1].grid(alpha=0.3, which="both")

    # (c) vortex plaquette count
    axes[2].plot(t, v_ref, "k-",  label=r"ref. $|w|>\frac{1}{2}$ cells")
    axes[2].plot(t, v_nn,  "r--", label="NN")
    axes[2].set_xlabel(r"$t$")
    axes[2].set_ylabel(r"vortex cells")
    axes[2].set_title(f"{case}: vortices")
    axes[2].legend(); axes[2].grid(alpha=0.3)

    fig.tight_layout()
    out_pdf = os.path.join(OUT, f"{case}_diag.pdf")
    out_png = os.path.join(OUT, f"{case}_diag.png")
    fig.savefig(out_pdf)
    fig.savefig(out_png, dpi=130)
    plt.close(fig)
    print(f"[repaint] {case} -> {out_png}")


def main():
    for c in CASES:
        if os.path.exists(os.path.join(OUT, f"{c}_ref.npz")):
            repaint(c)
        else:
            print(f"[skip] {c}: missing {c}_ref.npz (run redraw_diag.py first)")


if __name__ == "__main__":
    main()