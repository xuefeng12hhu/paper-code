"""
emit_extra_tables.py
====================
从实验 JSON 生成论文新增章节的 LaTeX 行与派生数字，**单一事实来源**：

1. 参考解收敛性（results/convergence/grid.json）
   -> 空间收敛表 + 时间收敛表 + "N_ref=48 上参考解自身的离散误差上界"
2. lambda 泛化（results/lambda_scan/*.json）
   -> e2(lambda) 表 + 同伦 vs 只在 lambda=1 训练 的对照数字
3. 泛化性（results/stage3/*.json）
   -> 未见初值迁移表 + 微调加速表 + 长时外推数字 + 磁场诊断表
4. 外部基线 causal PINN（results/benchmarks_ms/summary.json）
   -> causal 变体的 Table 2 行与相对 full 的增益

用法
----
    python scripts/emit_extra_tables.py              # 打印
    python scripts/emit_extra_tables.py --write      # 写入 results/extra_tables.tex
"""
import os, json, glob, argparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, "results")
ORDER = ["heal", "pair", "quench"]


def load(path, default=None):
    if not os.path.exists(path):
        return default
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def f3(v):
    return f"{v:.3f}"


# ---------------------------------------------------------------------------
# 1. 参考解收敛性
# ---------------------------------------------------------------------------
def grid_block(L):
    d = load(os.path.join(R, "convergence", "grid.json"))
    if not d:
        L.append("% [grid] results/convergence/grid.json 缺失 —— 先运行 grid_convergence.py")
        return
    L.append("% ===== Reference-solver spatial convergence (auto) =====")
    L.append("% case & N & rel-L2 vs N_fine & Linf vs N_fine & spectral tail")
    for entry in d:
        for row in entry["rows"]:
            L.append(f"{entry['case']:6s} & {row['N']:3d} & "
                     f"{row['rel_l2_vs_fine']:.2e} & {row['linf_vs_fine']:.2e} & "
                     f"{row['tail_frac']:.1e} \\\\")
    L.append("")
    L.append("% ===== Reference-solver temporal convergence (N=48, dt halved) =====")
    L.append("% case & n_steps & dt & Linf error & empirical order")
    for entry in d:
        for row in entry["temporal"]:
            o = "--" if row["order"] is None else f"{row['order']:.2f}"
            L.append(f"{entry['case']:6s} & {row['n_steps']:5d} & {row['dt']:.2e} & "
                     f"{row['linf_err']:.2e} & {o} \\\\")
    L.append("")
    # 关键派生数字：N=48 处参考解的相对离散误差上界
    at48 = []
    for entry in d:
        for row in entry["rows"]:
            if row["N"] == 48:
                at48.append((entry["case"], row["rel_l2_vs_fine"]))
    if at48:
        wc, wv = max(at48, key=lambda t: t[1])
        detail = ", ".join(f"{c}:{v:.2e}" for c, v in at48)
        L.append(f"% [KEY] max rel-L2 discretisation error of the N_ref=48 reference: "
                 f"{wv:.2e} ({wc}); all cases: {detail}")
    orders = [row["order"] for e in d for row in e["temporal"] if row["order"]]
    if orders:
        L.append(f"% [KEY] empirical temporal order: "
                 f"{min(orders):.2f}--{max(orders):.2f} (expect ~2 for ETDRK2)")
    L.append("")


# ---------------------------------------------------------------------------
# 2. lambda 泛化
# ---------------------------------------------------------------------------
def lam_block(L):
    files = sorted(glob.glob(os.path.join(R, "lambda_scan", "*_*.json")))
    recs = [load(p) for p in files]
    recs = [r for r in recs if r and "rows" in r]
    if not recs:
        L.append("% [lambda] results/lambda_scan/*.json 缺失 —— 先运行 lambda_scan.py")
        return
    L.append("% ===== lambda generalisation (auto) =====")
    L.append("% case & variant & e2(lam=1) & mean over lam & worst lam & worst e2")
    for r in sorted(recs, key=lambda r: (ORDER.index(r["case"]) if r["case"] in ORDER else 9,
                                         r["variant"])):
        worst = max(r["rows"], key=lambda x: x["e2_mean"])
        L.append(f"{r['case']:6s} & {r['variant']:12s} & {f3(r['e2_at_lam1'])} & "
                 f"{f3(r['e2_mean_over_lam'])} & {worst['lam']:.2f} & "
                 f"{f3(worst['e2_mean'])} \\\\")
    L.append("")
    # 同伦 vs 非同伦在未见 lambda 上的比值
    pairs = {}
    for r in recs:
        pairs.setdefault(r["case"], {})[r["variant"]] = r
    for c, p in pairs.items():
        if "full" in p and "no_homotopy" in p:
            f_ = p["full"]
            n_ = p["no_homotopy"]
            unseen = [lam for lam in (0.0, 0.25, 0.5, 0.75, 1.0) if lam != 1.0]
            def mean_unseen(rec):
                xs = [x["e2_mean"] for x in rec["rows"] if x["lam"] in unseen]
                return sum(xs) / max(len(xs), 1)
            L.append(f"% [KEY] {c}: e2 on lam!=1  homotopy={mean_unseen(f_):.3f} "
                     f"vs lam=1-only={mean_unseen(n_):.3f} "
                     f"(ratio {mean_unseen(n_) / max(mean_unseen(f_), 1e-12):.2f}x)")
            L.append(f"% [KEY] {c}: break-even queries (single lam scan) "
                     f"full={f_.get('break_even_lamscans')} "
                     f"no_homotopy={n_.get('break_even_lamscans')}")
    L.append("")


# ---------------------------------------------------------------------------
# 3. 泛化性
# ---------------------------------------------------------------------------
def gen_block(L):
    st3 = os.path.join(R, "stage3")
    L.append("% ===== Generalisation experiments (auto) =====")

    # 新版 generalization.py 输出到 results/generalization.json；
    # 旧版 stage3/{unseen_ic,transfer,long_time_extrap}.json 仅作回退。
    gen = load(os.path.join(R, "generalization.json"))
    un = (gen or {}).get("unseen_ic") or load(os.path.join(st3, "unseen_ic.json"))
    if un:
        L.append("% --- unseen initial condition (zero-shot cross-IC) ---")
        L.append("% train on & test on & e2 in-distribution & e2 unseen & ref vortices @T")
        for r in un:
            L.append(f"{r['train_on']:6s} & {r['test_on']:6s} & "
                     f"{f3(r['e2_in_dist'])} & {f3(r['e2_unseen'])} & "
                     f"{r['ref_vortex_at_T']} \\\\")
        L.append("")

    tr = (gen or {}).get("transfer") or load(os.path.join(st3, "transfer.json"))
    if tr:
        L.append("% --- fine-tuning speed-up ---")
        L.append(f"% scratch e2={f3(tr['e2_scratch'])} "
                 f"({tr['t_scratch']:.0f}s) -> finetune e2={f3(tr['e2_finetune'])} "
                 f"({tr['t_finetune']:.0f}s), improvement={tr['improvement']:.2f}x")
        L.append(f"% [KEY] transfer {tr['pre_train']} -> {tr['target']}: "
                 f"{f3(tr['e2_scratch'])} -> {f3(tr['e2_finetune'])} "
                 f"({tr['improvement']:.2f}x)")
        L.append("")

    lt = (gen or {}).get("long_time") or load(os.path.join(st3, "long_time_extrap.json"))
    if lt:
        L.append(f"% [KEY] long-time extrapolation: e2(T={lt['T_train']:.0f})="
                 f"{f3(lt['e2_at_T_train'])} -> e2(T={lt['T_eval']:.0f})="
                 f"{f3(lt['e2_at_T_eval'])} (trained on T={lt['T_train']:.0f})")

    ab = load(os.path.join(st3, "abrikosov.json"))
    if ab:
        L.append("% --- magnetic-field credibility diagnostics ---")
        L.append("% B & dt & mass/N^2 & max|psi| & vortices (init -> final) & F(0) & F(T)")
        for e in ab:
            for d in e["dt"]:
                L.append(f"{e['B']:.2f} & {d['dt']:.2f} & {d['mass_ratio']:.3f} & "
                         f"{d['max_psi_final']:.3f} & {d['vortex_init']} $\\to$ "
                         f"{d['vortex_final']} & {d['F0']:.3f} & {d['FT']:.3f} \\\\")
        L.append(f"% [KEY] Abrikosov: max|psi| over all B,dt = "
                 f"{max(d['max_psi_final'] for e in ab for d in e['dt']):.3f} "
                 f"(equilibrium bound |psi|<=1)")
    L.append("")


# ---------------------------------------------------------------------------
# 4. 外部基线 causal PINN
# ---------------------------------------------------------------------------
def causal_block(L):
    S = load(os.path.join(R, "benchmarks_ms", "summary.json"))
    if not S:
        L.append("% [causal] results/benchmarks_ms/summary.json 缺失")
        return
    tab = S["table"]
    if not any("causal" in tab.get(c, {}) for c in ORDER):
        L.append("% [causal] 尚无 causal 变体结果 —— 先运行 "
                 "benchmarks_multiseed.py --variants causal")
        return
    L.append("% ===== External baseline: causal PINN (auto) =====")
    L.append("% case & causal mean+-std & full mean & ratio")
    for c in ORDER:
        if "causal" not in tab.get(c, {}):
            continue
        d = tab[c]["causal"]
        fu = tab[c]["full"]["mean"]
        L.append(f"{c:6s} & {f3(d['mean'])}$\\pm${d['std']:.3f} & {f3(fu)} & "
                 f"{d['mean'] / fu:.2f} \\\\")
    ratios = {c: tab[c]["causal"]["mean"] / tab[c]["full"]["mean"]
              for c in ORDER if "causal" in tab.get(c, {})}
    if ratios:
        lo, hi = min(ratios.values()), max(ratios.values())
        detail = ", ".join(f"{c}:{v:.2f}x" for c, v in ratios.items())
        L.append(f"% [KEY] full vs causal: {lo:.2f}--{hi:.2f}x ({detail})")
    L.append("")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args()

    L = ["% ==== auto-generated by scripts/emit_extra_tables.py ====", ""]
    grid_block(L)
    lam_block(L)
    gen_block(L)
    causal_block(L)
    txt = "\n".join(L)
    print(txt)

    if args.write:
        p = os.path.join(R, "extra_tables.tex")
        with open(p, "w", encoding="utf-8") as f:
            f.write(txt + "\n")
        print(f"\n[written] {p}")


if __name__ == "__main__":
    main()
