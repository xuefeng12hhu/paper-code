"""
emit_tables.py
==============
从 results/benchmarks_ms/summary.json 直接生成论文表 1/表 2 的 LaTeX 行与
全部派生增益区间，**单一事实来源**，避免手工转录导致摘要/正文/结论数字不一致。

用法
----
    python scripts/emit_tables.py                # 打印到标准输出
    python scripts/emit_tables.py --write        # 写入 results/benchmarks_ms/tables.tex

产出
----
1. Table 1 行：full / no_homotopy / no_correct（mean±std）+ 涡旋数
2. Table 2 行：五个变体（mean±std）
3. 增益区间：
   - full vs no_homotopy（同伦贡献）
   - full vs no_correct（数据校正贡献）
   - full vs no_ff（Fourier 特征贡献，可能为负）
   - full vs vanilla
"""
import os, json, argparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUM = os.path.join(ROOT, "results", "benchmarks_ms", "summary.json")

ORDER = ["heal", "pair", "quench"]
VARIANTS = ["full", "no_homotopy", "no_correct", "no_ff", "vanilla", "causal"]
TEXNAME = {"full": "full", "no_homotopy": "no homotopy",
           "no_correct": "no correction", "no_ff": "no Fourier",
           "vanilla": "vanilla", "causal": "causal PINN"}


def fmt(v, s=None):
    return f"{v:.3f}" if s is None else f"{v:.3f}$\\pm${s:.3f}"


def best_per_row(tab):
    """逐算例找最小均值，用于加粗。"""
    out = {}
    for c in ORDER:
        vals = {v: tab[c][v]["mean"] for v in VARIANTS if v in tab.get(c, {})}
        out[c] = min(vals, key=vals.get) if vals else None
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args()

    with open(SUM, encoding="utf-8") as f:
        S = json.load(f)
    tab, refs = S["table"], S.get("refs", {})
    best = best_per_row(tab)
    L = []

    n_seed = max((r["n"] for c in tab.values() for r in c.values()), default=0)

    # ---- Table 1 ----
    L.append("% ===== Table 1: main benchmarks (auto-generated) =====")
    for c in ORDER:
        if c not in tab:
            continue
        r = refs.get(c, {})
        cells = []
        missing = False
        for v in ("full", "no_homotopy", "no_correct"):
            if v not in tab[c]:
                cells.append("--"); missing = True
                continue
            d = tab[c][v]
            s = fmt(d["mean"], d["std"])
            cells.append(f"\\textbf{{{s}}}" if v == best[c] else s)
        if missing:
            L.append(f"% [partial] {c}: some variants pending")
        peak = (f" & {tab[c]['full']['peak_vortex']:.0f}"
                if "full" in tab[c] else " & --")
        L.append(f"{c:6s} & " + " & ".join(cells)
                 + f" & {r.get('ref_vortex_at_T', '?')}" + peak + r" \\")
    L.append("")

    # ---- Table 2 ----
    L.append("% ===== six-variant ablation (auto-generated) =====")
    for c in ORDER:
        if c not in tab:
            continue
        cells = []
        for v in VARIANTS:
            if v not in tab[c]:
                cells.append("--")
                continue
            d = tab[c][v]
            s = fmt(d["mean"], d["std"])
            cells.append(f"\\textbf{{{s}}}" if v == best[c] else s)
        L.append(f"{c:6s} & " + " & ".join(cells) + r" \\")
    L.append("")

    # ---- 增益区间 ----
    L.append("% ===== Derived gain ranges (use these verbatim in text) =====")
    for v in ("no_homotopy", "no_correct", "no_ff", "vanilla", "causal"):
        gains = {c: tab[c][v]["mean"] / tab[c]["full"]["mean"]
                 for c in ORDER
                 if c in tab and v in tab[c] and "full" in tab[c]}
        if not gains:
            continue
        lo, hi = min(gains.values()), max(gains.values())
        detail = ", ".join(f"{c}:{g:.2f}x" for c, g in gains.items())
        L.append(f"% full vs {v:12s}: {lo:.2f}--{hi:.2f}x   ({detail})")
    L.append("")
    # 外部基线：causal 与 no_correct / no_homotopy 的单独对照
    if all("causal" in tab.get(c, {}) for c in ORDER):
        for other in ("no_correct", "no_homotopy"):
            r = {c: tab[c][other]["mean"] / tab[c]["causal"]["mean"]
                 for c in ORDER if other in tab.get(c, {})}
            lo, hi = min(r.values()), max(r.values())
            detail = ", ".join(f"{c}:{g:.2f}x" for c, g in r.items())
            L.append(f"% causal vs {other:12s}: {lo:.2f}--{hi:.2f}x   "
                     f"({detail})")
    L.append("")
    L.append(f"% N_seed = {n_seed}")
    # ---- 激活模式对照（论文表 tab:trigger）----
    if all("trigger" in tab.get(c, {}) for c in ORDER):
        L.append("% ===== Table: activation mode (scheduled vs a-posteriori) =====")
        for c in ORDER:
            f_, t_ = tab[c]["full"], tab[c]["trigger"]
            L.append(f"{c:6s} & {fmt(f_['mean'], f_['std'])} & "
                     f"{fmt(t_['mean'], t_['std'])} & "
                     f"{t_['n']} seeds \\\\")
        L.append("")
    txt = "\n".join(L)
    print(txt)

    if args.write:
        p = os.path.join(ROOT, "results", "benchmarks_ms", "tables.tex")
        with open(p, "w", encoding="utf-8") as f:
            f.write(txt + "\n")
        print(f"\n[written] {p}")


if __name__ == "__main__":
    main()
