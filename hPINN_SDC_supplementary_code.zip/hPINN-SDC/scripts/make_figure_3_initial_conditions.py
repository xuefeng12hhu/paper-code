"""
make_figure_3_initial_conditions.py
====================================
Fig 3: Three benchmark initial conditions (heal / pair / quench).

Renders |psi_0| for each benchmark on a common axis range, plus the
underlying complex phase field for context.

Output:
    results/figures/fig3_initial_conditions.pdf
    results/figures/fig3_initial_conditions.png
"""
from __future__ import annotations
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style
use_style()

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import matplotlib.pyplot as plt
import numpy as np
import torch

from src.reference_solver import make_initial_condition

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "results", "figures")
os.makedirs(OUT_DIR, exist_ok=True)
L = 10.0
N = 32


def panel(ax, psi0_np, title, sub):
    """Render |psi| with annotation."""
    extent = [0, L, 0, L]
    im = ax.imshow(np.abs(psi0_np), extent=extent, origin="lower",
                   cmap="viridis", vmin=0, vmax=1.4)
    ax.set_title(f"({sub}) {title}", fontsize=11)
    ax.set_xticks([0, 2.5, 5, 7.5, 10])
    ax.set_yticks([0, 2.5, 5, 7.5, 10])
    ax.set_xlabel(r"Coordinate $x$", fontsize=11)
    ax.set_ylabel(r"Coordinate $y$", fontsize=11)
    cb = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cb.set_label(r"$|\psi_{0}|$", fontsize=10)


def main():
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.4))

    # (a) heal: Gaussian amplitude perturbation
    psi_heal = make_initial_condition("gaussian", N, L,
                                       eps=0.8, sigma=1.5, seed=0)
    panel(axes[0], psi_heal.numpy(),
          "Heal: Gaussian amplitude depression",
          "a")

    # (b) pair: vortex-antivortex imprint
    psi_pair = make_initial_condition("pair", N, L,
                                       sep=5.0, xi=0.5, seed=0)
    panel(axes[1], psi_pair.numpy(),
          r"Pair: vortex--antivortex imprint, $Q=\pm 1$",
          "b")

    # (c) quench: random-phase patches (Kibble--Zurek)
    psi_quench = make_initial_condition("quench", N, L,
                                        ell=1.5, rms=0.4, seed=2)
    panel(axes[2], psi_quench.numpy(),
          "Quench: random-phase patches (Kibble--Zurek)",
          "c")

    fig.suptitle(r"Initial conditions $\psi_0(x,y)$",
                 fontsize=13.0, weight="bold", y=1.02)

    plt.tight_layout()
    out_pdf = os.path.join(OUT_DIR, "fig3_initial_conditions.pdf")
    out_png = os.path.join(OUT_DIR, "fig3_initial_conditions.png")
    plt.savefig(out_pdf, bbox_inches="tight")
    plt.savefig(out_png, bbox_inches="tight", dpi=200)
    print(f"[Fig 3] written to {out_pdf} and {out_png}")


if __name__ == "__main__":
    main()