"""
make_all_figures.py
====================
Unified driver: generates all 6 manuscript figures (Fig 1, 3, 5, 6, 9, 13).

Each script writes both PDF (vector, for typesetting) and PNG (raster, for
preview) to results/figures/.

Usage:
    python scripts/make_all_figures.py        # all figures
    python scripts/make_all_figures.py --only 1,5,9    # subset
"""
from __future__ import annotations
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--only", default=None,
                        help="comma-separated figure ids to render, e.g. '1,5,9'")
    args = parser.parse_args()

    SCRIPTS = {
        "1": "make_figure_1_architecture.py",
        "2": "make_figure_2_homotopy_panel.py",
        "3": "make_figure_3_initial_conditions.py",
        "5": "make_figure_5_algorithm_flowchart.py",
        "6": "make_figure_6_vortex_topology.py",
        "9": "make_figure_9_speedup.py",
        "13": "make_figure_13_abrikosov.py",
    }
    order = sorted(SCRIPTS.keys(), key=int)
    if args.only:
        order = [s for s in order if s in set(args.only.split(","))]

    here = os.path.dirname(__file__)
    for fig_id in order:
        script = SCRIPTS[fig_id]
        path = os.path.join(here, script)
        t0 = time.time()
        print(f"\n[make_all_figures] Fig {fig_id} ({script})")
        # Re-execute the script
        with open(path, encoding="utf-8") as f:
            code = f.read()
        # Minimal namespace
        ns = {"__name__": "__main__", "__file__": path}
        try:
            exec(compile(code, path, "exec"), ns)
        except Exception as e:
            print(f"  !! error: {e}")
            continue
        print(f"  done in {time.time() - t0:.1f}s")

    print("\nAll requested figures rendered to results/figures/")


if __name__ == "__main__":
    main()