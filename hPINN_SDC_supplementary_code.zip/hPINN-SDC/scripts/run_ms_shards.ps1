# 分片并行运行 benchmarks_multiseed.py
# 用法: powershell -ExecutionPolicy Bypass -File scripts\run_ms_shards.ps1
#       -Shards 8 -Threads 4 -Seeds 3 -Recipe lite -Cases heal,pair,quench
param(
    [int]$Shards = 8,
    [int]$Threads = 4,
    [int]$Seeds = 3,
    [string]$Recipe = "lite",
    [string]$Cases = "heal,pair,quench",
    [string]$Variants = "full,no_homotopy,no_correct,no_ff,vanilla",
    [string]$Python = "C:\Users\26271\.workbuddy\binaries\python\versions\3.14.3\python.exe"
)

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
New-Item -ItemType Directory -Force -Path "logs" | Out-Null
$env:PYTHONUNBUFFERED = "1"

for ($i = 0; $i -lt $Shards; $i++) {
    $args = @(
        "benchmarks_multiseed.py",
        "--recipe", $Recipe,
        "--threads", "$Threads",
        "--seeds-mode", "uniform",
        "--seeds", "$Seeds",
        "--cases", $Cases,
        "--variants", $Variants,
        "--shard", "$i/$Shards"
    )
    Start-Process -FilePath $Python -ArgumentList $args `
        -WorkingDirectory $root `
        -RedirectStandardOutput "$root\logs\ms_$i.log" `
        -RedirectStandardError  "$root\logs\ms_$i.err" `
        -NoNewWindow
}
Write-Host "launched $Shards shards (threads=$Threads, seeds=$Seeds, recipe=$Recipe)"
