"""
make_figure_13_abrikosov.py
============================
Fig 13: Full TDGL with magnetic field -- Abrikosov lattice.

Four panels:
  (a) Abrikosov initial condition |psi_0| with 32 imprinted vortices (L=20)
  (b) B=0 final state -- complete annihilation
  (c) B=0.05 final state -- 6 vortices retained
  (d) Vortex count N_v(t) curves for B in {0, 0.05, 0.10}

Data source:
    results/stage3/abrikosov.json (initial/final summary)
    ETDRK2 reference for instantaneous snapshots

Output:
    results/figures/fig13_abrikosov.pdf
    results/figures/fig13_abrikosov.png
"""
from __future__ import annotations
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style
use_style()

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import matplotlib.pyplot as plt
import numpy as np
import torch

from src.reference_solver import (initial_condition_abrikosov, ETD2RK,
                                    vortex_map, vortex_count)

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "results", "figures")
os.makedirs(OUT_DIR, exist_ok=True)

DATA = os.path.join(os.path.dirname(__file__), "..", "results", "stage3",
                    "abrikosov.json")

# Smaller L for tractable compute (full L=20 needs more memory)
L = 12.0
N = 32
T = 8.0


def colormap_winding():
    from matplotlib.colors import ListedColormap
    return ListedColormap(["#3B6FB6", "#FFFFFF", "#D62728"])


def run_simulation(B: float):
    """Run ETDRK2 with B-field for Abrikosov initial condition."""
    psi0 = initial_condition_abrikosov(N, L, n_v=4, xi=0.7,
                                      spacing=3.0, orientation="hex")
    # Use ETD2RK with vector potential (gauge=A_symmetric)
    etd = ETD2RK(lam=1.0, L_box=L, N=N, B_field=B, gauge="symmetric")
    snaps = etd.integrate(psi0, dt=0.2, n_steps=int(T / 0.2),
                          snapshot_every=1).numpy()
    return snaps


def main():
    with open(DATA) as f:
        summary_rows = json.load(f)

    # index by B
    summary = {row["B"]: row for row in summary_rows}

    fig = plt.figure(figsize=(14, 9))
    gs = fig.add_gridspec(2, 3, height_ratios=[1, 1.0], hspace=0.32, wspace=0.28)
    axes = [fig.add_subplot(gs[0, 0]),
            fig.add_subplot(gs[0, 1]),
            fig.add_subplot(gs[0, 2])]
    ax_curve = fig.add_subplot(gs[1, :])

    extent = [0, L, 0, L]

    # (a) initial condition -- all three sub-cases use the same psi0
    psi0 = initial_condition_abrikosov(N, L, n_v=4, xi=0.7,
                                       spacing=3.0, orientation="hex").numpy()
    axes[0].imshow(np.abs(psi0), extent=extent, origin="lower",
                   cmap="viridis", vmin=0, vmax=1.4)
    axes[0].set_title("(a) $|\\psi_0|$ Abrikosov lattice\n($N_v = 32$ imprinted)",
                      fontsize=11)

    # Run simulations
    snaps_B0 = run_simulation(0.0)
    snaps_B05 = run_simulation(0.05)

    # (b) B=0 final -- |psi| (complete annihilation -> uniform mean field)
    f0 = np.abs(snaps_B0[-1])
    axes[1].imshow(f0, extent=extent, origin="lower",
                   cmap="viridis", vmin=0.0, vmax=1.4)
    axes[1].set_title(r"(b) $B = 0$, $t = T$: Complete"
                      "\n" r"annihilation ($|\psi|$ uniform)",
                      fontsize=11)

    # (c) B=0.20 final -- |psi| (residual vortex lattice persists)
    snaps_B20 = run_simulation(0.20)
    f20 = np.abs(snaps_B20[-1])
    w20 = vortex_map(torch.from_numpy(snaps_B20[-1]).unsqueeze(0))[0].numpy()
    nv20 = int(np.abs(w20).sum())
    axes[2].imshow(f20, extent=extent, origin="lower", cmap="viridis",
                   vmin=0.0, vmax=1.3)
    axes[2].set_title(rf"(c) $B = 0.20$, $t = T$: Residual"
                      "\n" rf"vortex lattice ($N_v = {nv20}$)",                       fontsize=11)


    for ax in axes:
        ax.set_xlabel("$x$"); ax.set_ylabel("$y$")
        ax.grid(False)

    # (d) Vortex count time series
    # NB: keep complex64 (matches vortex_map's tested working dtype);
    # .double() triggers a wrap bug inside vortex_map for complex128.
    vc_B0 = vortex_count(torch.from_numpy(snaps_B0)).numpy()
    vc_B05 = vortex_count(torch.from_numpy(snaps_B05)).numpy()
    snaps_B1 = run_simulation(0.10)
    vc_B1 = vortex_count(torch.from_numpy(snaps_B1)).numpy()
    t = np.linspace(0, T, snaps_B0.shape[0])

    ax_curve.plot(t, np.abs(vc_B0), color="#1F4E79", lw=2.0,
                  label="$B = 0$")
    ax_curve.plot(t, np.abs(vc_B05), color="#C00000", lw=2.0, ls="--",
                  label="$B = 0.05$")
    ax_curve.plot(t, np.abs(vc_B1), color="#385723", lw=2.0, ls=":",
                  label="$B = 0.10$")
    ax_curve.set_xlabel("$t$")
    ax_curve.set_ylabel(r"Vortex count $\mathcal{N}_v(t)$")
    ax_curve.set_title("(d) Vortex count " + r"$\mathcal{N}_v(t)$"
                       + " for finite magnetic field",
                       fontsize=11)
    ax_curve.legend(loc="upper right", fontsize=10.0, frameon=False)
    ax_curve.grid(False)
    ax_curve.set_axisbelow(True)

    fig.suptitle("Full TDGL with magnetic field: Abrikosov vortex lattice",
                 fontsize=13.0, weight="bold", y=0.995)
    plt.savefig(os.path.join(OUT_DIR, "fig13_abrikosov.pdf"),
                bbox_inches="tight")
    plt.savefig(os.path.join(OUT_DIR, "fig13_abrikosov.png"),
                bbox_inches="tight", dpi=200)
    print(f"[Fig 13] written")


if __name__ == "__main__":
    main()