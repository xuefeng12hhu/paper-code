"""
figure_style.py
===============
Shared matplotlib rcParams for the manuscript figures.

Goals:
  - Times New Roman for all text and math (matches the manuscript main font)
  - Mathtext rendered with STIX (a Times-compatible math font) so that:
        * scalar variables (N, q, t, x, L, e, ...) are italic
        * multi-letter identifiers and unit-like labels are upright
        * sub/superscripts follow LaTeX convention
  - PDFs embed TrueType outlines (fonttype=42) so LaTeX/Acrobat can
    re-flow text instead of treating glyphs as paths.

Usage:
    from figure_style import use_style
    use_style()      # call BEFORE importing pyplot or creating figures

    # optionally per-axes
    from figure_style import style_axes, math_label
"""
from __future__ import annotations

_RC_DEFAULTS = {
    # ---- Text ----
    "font.family":     "serif",
    "font.serif":      ["Times New Roman", "Times",
                         "STIX", "DejaVu Serif"],
    "font.size":       10.5,

    # ---- Math (STIX is a Times-compatible math font) ----
    # mathtext.default == "regular" -> single letters in math mode render
    # italic (which is what we want for scalar variables N, q, t, ...);
    # multi-letter "names" render upright by default unless wrapped in
    # \mathit{}.  Subscripts and superscripts follow LaTeX rules: <raw
    # sub/sup doesn't override LaTeX rules.
    "mathtext.fontset": "stix",
    "mathtext.default": "regular",
    "mathtext.bf":      "serif:bold",

    # ---- Symbols ----
    "axes.unicode_minus": False,

    # ---- Embedding (so PDF text stays as text) ----
    "pdf.fonttype": 42,
    "ps.fonttype":  42,

    # ---- Lines / markers (defaults kept, just tightened) ----
    "lines.linewidth": 1.4,
    "lines.markersize": 4,
}


def use_style() -> None:
    """Apply the manuscript rcParams.  Call once per script, before plotting."""
    import matplotlib
    import matplotlib.pyplot as plt
    matplotlib.use("Agg")
    plt.rcParams.update(_RC_DEFAULTS)


def style_axes(ax, *, tick_size: float = 9.5, label_size: float = 10.5,
               title_size: float = 11.0) -> None:
    """Tighten tick / label / title sizes for one Axes."""
    ax.tick_params(axis="both", which="major", labelsize=tick_size)
    ax.xaxis.label.set_size(label_size)
    ax.yaxis.label.set_size(label_size)
    if ax.get_title():
        ax.title.set_size(title_size)


# ---- Math-label helpers (single source of truth) ----
# These wrap common LaTeX fragments so that all scripts agree on
# italic / upright / sub/superscript usage.

def scalar(s: str) -> str:
    """Wrap a scalar identifier so it stays upright inside a math region.
    Use for already-upright identifiers like 'PDE' inside a subscript
    that would otherwise inherit italic from the outer letters."""
    return r"\mathrm{" + s + r"}"


def ms(x: str) -> str:
    """Inline math: ensure the scalar letter is italic (default behaviour,
    but kept as a hook in case future rcParams changes the default)."""
    return f"${x}$"


def unit(s: str) -> str:
    """A unit in upright text: ``\\unit[s]`` -> '\\mathrm{s}'."""
    return r"$\mathrm{" + s + r"}$"


# Common patterns used across figures (no I/O; just strings)
LABEL_T = r"$t$"                       # time axis
LABEL_X = r"$x$"
LABEL_Y = r"$y$"
LABEL_LAMBDA = r"$\lambda$"
LABEL_PSI = r"$\psi$"
LABEL_PSI_HAT = r"$\hat{\psi}$"
LABEL_L2 = r"$L^2$"                    # relative L^2 error
LABEL_E2 = r"$e_{2}$"                  # relative L^2 error symbol
LABEL_NQ = r"$N_q$"                    # number of queries
LABEL_NV = r"$\mathcal{N}_v$"          # vortex count (calligraphic)
LABEL_RMS = r"\mathrm{rms}"