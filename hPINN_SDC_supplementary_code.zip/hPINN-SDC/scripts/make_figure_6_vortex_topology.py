"""
make_figure_6_vortex_topology.py
=================================
Fig 6: Vortex topology recovery on the pair benchmark.

Four panels:
  (a) initial condition |psi_0| (vortex-antivortex imprinted)
  (b) reference solution at a representative t_star, plaquette winding w
      in {-1, 0, +1}, with the cores outlined
  (c) neural surrogate at the same t_star, same colour code, cores outlined
  (d) pixel-wise |psi_hat - psi_ref| at t_star, with a colour-bar whose
      upper bound is clipped at the 99th-percentile so the bulk of the
      structure remains readable.

t_star is picked automatically: the latest frame in which BOTH the reference
and the surrogate still carry at least one |w|>0.5 plaquette, i.e. before the
pair has fully annihilated. This guarantees the visualisation shows recovered
topology at a meaningful time rather than (as a naive argmax|vortex_count|
does) the trivial t=0 imprint where every panel collapses to the IC.

Output:
    results/figures/fig6_vortex_topology.pdf
    results/figures/fig6_vortex_topology.png
"""
from __future__ import annotations
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import matplotlib
matplotlib.use("Agg")
sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style
use_style()
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import ListedColormap
import numpy as np
import torch

from src.reference_solver import (make_initial_condition, ETD2RK,
                                    vortex_map)

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "results", "figures")
os.makedirs(OUT_DIR, exist_ok=True)

BENCH_DIR = os.path.join(os.path.dirname(__file__), "..", "results", "benchmarks")
L = 10.0


def colormap_winding():
    """Discretised colormap: blue (anti-vortex), white (none), red (vortex)."""
    return ListedColormap(["#3B6FB6", "#FFFFFF", "#D62728"])


def pick_t_star(ref_snaps: np.ndarray, nn_snaps: np.ndarray) -> int:
    """Latest frame where ref AND nn still host at least one vortex plaquette.

    Using `vortex_count` (sum of w) is misleading for the pair benchmark: the
    net winding is ~0 throughout because +1 and -1 cancel. We instead count
    plaquettes with |w|>0.5 in each frame.
    """
    T = ref_snaps.shape[0]
    for t in range(T - 1, -1, -1):
        w_ref = vortex_map(torch.from_numpy(ref_snaps[t]).unsqueeze(0))[0].numpy()
        w_nn  = vortex_map(torch.from_numpy(nn_snaps[t]).unsqueeze(0))[0].numpy()
        if (np.abs(w_ref) > 0.5).any() and (np.abs(w_nn) > 0.5).any():
            return t
    return 0  # fallback: imprint


def draw_core_outline(ax, w: np.ndarray, extent, color: str, lw: float = 2.4):
    """Trace the boundary of every |w|>0.5 plaquette on `ax`."""
    mask = (np.abs(w) > 0.5).astype(float)
    if mask.sum() == 0:
        return
    # Plaquette grid (N+1)x(N+1) sits in a box of size extent; rescale.
    x0, x1, y0, y1 = extent
    Ny, Nx = mask.shape
    dx = (x1 - x0) / Nx
    dy = (y1 - y0) / Ny
    ax.contour(mask, levels=[0.5], colors=color, linewidths=lw,
               extent=(x0, x0 + Nx * dx, y0, y0 + Ny * dy),
               origin="lower")


def main():
    nn_npz = os.path.join(BENCH_DIR, "pair_nn.npz")
    ref_npz = os.path.join(BENCH_DIR, "pair_ref.npz")
    if os.path.exists(nn_npz) and os.path.exists(ref_npz):
        data_nn  = np.load(nn_npz)
        data_ref = np.load(ref_npz)
        nn_snaps  = data_nn["snaps"]
        ref_snaps = data_ref["snaps"]
        N = nn_snaps.shape[1]
    else:
        N = 32
        psi0 = make_initial_condition("pair", N, L, sep=5.0, xi=0.5)
        etd = ETD2RK(lam=1.0, L_box=L, N=N)
        ref_snaps = etd.integrate(psi0, dt=0.1, n_steps=60, snapshot_every=1).numpy()
        nn_snaps = ref_snaps  # placeholder

    t_star = pick_t_star(ref_snaps, nn_snaps)
    print(f"[Fig 6] picked t_star = {t_star}")

    psi0 = make_initial_condition("pair", N, L, sep=5.0, xi=0.5).numpy()
    extent = [0, L, 0, L]
    fig, axes = plt.subplots(1, 4, figsize=(17.0, 5.0))

    # (a) |psi_0|
    im_a = axes[0].imshow(np.abs(psi0), extent=extent, origin="lower",
                          cmap="viridis", vmin=0, vmax=1.4)
    axes[0].set_title(rf"(a)\," + r"$|\psi_0|$ Imprint", fontsize=12.5)

    # (b) reference winding
    w_ref = vortex_map(torch.from_numpy(ref_snaps[t_star]).unsqueeze(0))[0].numpy()
    axes[1].imshow(w_ref, extent=extent, origin="lower",
                   cmap=colormap_winding(), vmin=-1, vmax=1,
                   interpolation="nearest")
    n_ref_pos = int((w_ref > 0.5).sum())
    n_ref_neg = int((w_ref < -0.5).sum())
    axes[1].set_title(
        rf"(b) Ref.\ winding   $t = {t_star}$    "
        rf"($+1\!:\, {n_ref_pos}$, $-1\!:\, {n_ref_neg}$)",
        fontsize=12.5,
    )
    draw_core_outline(axes[1], w_ref, extent, color="black", lw=2.4)

    # (c) NN winding
    w_nn = vortex_map(torch.from_numpy(nn_snaps[t_star]).unsqueeze(0))[0].numpy()
    axes[2].imshow(w_nn, extent=extent, origin="lower",
                   cmap=colormap_winding(), vmin=-1, vmax=1,
                   interpolation="nearest")
    n_nn_pos = int((w_nn > 0.5).sum())
    n_nn_neg = int((w_nn < -0.5).sum())
    axes[2].set_title(
        rf"(c) Surrogate winding   $t = {t_star}$    "
        rf"($+1\!:\, {n_nn_pos}$, $-1\!:\, {n_nn_neg}$)",
        fontsize=12.5,
    )
    draw_core_outline(axes[2], w_nn, extent, color="black", lw=2.4)

    # (d) pixel error: vmax clipped to 99th percentile so boundary hotspots
    # do not flatten the bulk of the field.
    err = np.abs(nn_snaps[t_star] - ref_snaps[t_star])
    vmax = float(np.percentile(err, 99))
    if vmax <= 0:
        vmax = float(err.max()) or 1.0
    im_d = axes[3].imshow(err, extent=extent, origin="lower",
                          cmap="magma", vmin=0, vmax=vmax)
    axes[3].set_title(
        rf"(d) $|\hat\psi - \psi^{{+\mathrm{{ref}}}}|$   "
        rf"($v_{{\max}} = p_{{99}} = {vmax:.3f}$)",
        fontsize=12.5,
    )
    cb = fig.colorbar(im_d, ax=axes[3], fraction=0.046, pad=0.04)
    cb.set_label(r"Pointwise error", fontsize=11.0)
    cb.ax.tick_params(labelsize=10.0)

    for ax in axes:
        ax.set_xlabel(r"$x$", fontsize=12.0)
        ax.set_ylabel(r"$y$", fontsize=12.0)
        ax.tick_params(labelsize=10.0)
        ax.grid(False)

    # add a manual legend for the discretised colormap
    handles = [mpatches.Patch(color="#D62728", label="+1 vortex"),
               mpatches.Patch(facecolor="#FFFFFF",  label="0  none",
                              edgecolor="lightgray"),
               mpatches.Patch(color="#3B6FB6", label="-1 antivortex")]
    fig.legend(handles=handles, loc="lower center", ncol=3,
               bbox_to_anchor=(0.5, -0.02), frameon=False, fontsize=11.0)

    fig.suptitle(rf"Vortex topology recovery: pair benchmark   ($t = {t_star}$)",
                 fontsize=15.0, weight="bold", y=1.02)

    plt.tight_layout(rect=[0, 0.04, 1, 0.97])
    out_pdf = os.path.join(OUT_DIR, "fig6_vortex_topology.pdf")
    out_png = os.path.join(OUT_DIR, "fig6_vortex_topology.png")
    plt.savefig(out_pdf, bbox_inches="tight")
    plt.savefig(out_png, bbox_inches="tight", dpi=200)
    print(f"[Fig 6] written to {out_pdf} and {out_png}")


if __name__ == "__main__":
    main()