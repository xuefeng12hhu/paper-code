"""
make_figure_5_algorithm_flowchart.py
=====================================
Fig 5: Two-phase hPINN-SDC training flowchart.

Three-column layout with clean arrow connections:
  Phase A  (left)    Psi_0 -> L_IC -> Adam
  Phase B  (middle)  Lambda grid -> L_PDE -> residual test -> diamond
  Trigger  (right)   ETDRK2 -> subsample -> data anchor

Diamond:
  Yes  -> arrow right  -> Data anchor (activates trigger column)
  No   -> arrow up-left -> next lambda_{k+1} (loops back to top of Phase B)

After data anchor:
  arrow back-left to L_PDE (continues variational descent)

Termination:
  from Phase B bottom -> Return box

Output:
    results/figures/fig5_algorithm_flowchart.pdf
    results/figures/fig5_algorithm_flowchart.png
"""
from __future__ import annotations
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style
use_style()

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "results", "figures")
os.makedirs(OUT_DIR, exist_ok=True)


def box(ax, xy, w, h, text, fc="#E8F1FB", ec="#1F4E79", lw=1.3, fs=10,
        bold=False):
    rect = FancyBboxPatch(xy, w, h,
                          boxstyle="round,pad=0.02,rounding_size=0.05",
                          linewidth=lw, edgecolor=ec, facecolor=fc)
    ax.add_patch(rect)
    weight = "bold" if bold else "normal"
    ax.text(xy[0] + w / 2, xy[1] + h / 2, text,
            ha="center", va="center", fontsize=fs, weight=weight)


def arrow(ax, p1, p2, color="#1F4E79", lw=1.3, ls="-", mut=14,
          connectionstyle="arc3,rad=0"):
    arr = FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=mut,
                          linewidth=lw, color=color, linestyle=ls,
                          shrinkA=0, shrinkB=0,
                          connectionstyle=connectionstyle)
    ax.add_patch(arr)


# ===== Geometry: every box is referenced as (x_left, y_bottom, w, h) =========
# Phase A (left column, x in [0.4, 4.0])
A_PSI    = (0.40, 5.20, 1.50, 0.70)   # psi_0
A_LOSS   = (2.10, 5.20, 1.80, 0.70)   # L_IC
A_ADAM   = (2.10, 3.90, 1.80, 0.70)   # Adam
# Phase B (middle column, x in [4.6, 8.4])
B_LAMBDA = (5.10, 5.20, 1.80, 0.70)   # lambda grid
B_LOSS   = (4.60, 3.90, 3.20, 0.70)   # L_PDE
B_RESID  = (4.60, 2.60, 3.20, 0.70)   # residual test
B_DIAMOND_C = (6.70, 1.50)            # diamond centre, half-w=0.90, half-h=0.50
# Trigger (right column, x in [9.0, 12.6])
T_ETD    = (9.10, 5.20, 3.20, 0.70)   # ETDRK2 reference
T_SUBS   = (9.10, 3.90, 3.20, 0.70)   # subsample
T_DATA   = (9.10, 2.60, 3.20, 0.70)   # data anchor
# Termination (bottom middle)
T_RET    = (4.60, 0.30, 3.20, 0.60)   # Return box


def cx(b): return (b[0] + b[2] / 2, b[1] + b[3] / 2)
def top(b): return (b[0] + b[2] / 2, b[1] + b[3])
def bot(b): return (b[0] + b[2] / 2, b[1])
def left(b): return (b[0], b[1] + b[3] / 2)
def right(b): return (b[0] + b[2], b[1] + b[3] / 2)


def main():
    fig, ax = plt.subplots(figsize=(13.0, 7.4))
    ax.set_xlim(0, 13)
    ax.set_ylim(0, 6.6)
    ax.set_axis_off()

    # ---- Column banners ----
    ax.text(cx(A_LOSS)[0], 6.30, "Phase A\nIC pre-training", ha="center",
            fontsize=12, weight="bold", color="#C00000")
    ax.text(cx(B_LOSS)[0], 6.30, "Phase B\nhomotopy continuation", ha="center",
            fontsize=12, weight="bold", color="#1F4E79")
    ax.text(cx(T_ETD)[0], 6.30, "Trigger\nsnapshot supervision", ha="center",
            fontsize=12, weight="bold", color="#385723")

    # ---- Column separators (light dotted) ----
    for x in [4.30, 8.70]:
        ax.plot([x, x], [0.20, 6.10], color="#bbb", lw=0.6, ls=":")

    # ====================== Phase A (left column) ============================
    box(ax, (A_PSI[0],  A_PSI[1]),  A_PSI[2],  A_PSI[3],
        r"$\psi_0$" + "\ninitial data", fc="#FFF2CC", fs=9)
    box(ax, (A_LOSS[0], A_LOSS[1]), A_LOSS[2], A_LOSS[3],
        r"$\mathcal{L}=w_{\mathrm{IC}}\|\mathcal{R}_{\mathrm{IC}}\|^{2}$",
        fc="#DDEBF7", fs=8.5)
    box(ax, (A_ADAM[0], A_ADAM[1]), A_ADAM[2], A_ADAM[3],
        r"Adam iter" + "\n" + r"$E_{\mathrm{IC}}=200$ epochs",
        fc="#E2EFDA", fs=9)

    arrow(ax, right(A_PSI), left(A_LOSS))
    arrow(ax, bot(A_LOSS), top(A_ADAM))

    # Phase A terminates -> pass to Phase B (arrow right and down)
    arrow(ax, right(A_ADAM), left(B_LAMBDA),
          connectionstyle="arc3,rad=-0.20", color="#C00000")
    ax.text(4.10, 4.30, "to Phase B", fontsize=8, color="#C00000",
            style="italic", ha="center")

    # ====================== Phase B (middle column) ==========================
    box(ax, (B_LAMBDA[0], B_LAMBDA[1]), B_LAMBDA[2], B_LAMBDA[3],
        r"$\lambda_k = k/K$" + "\n" + r"$K=2$ segments",
        fc="#FCE4D6", fs=9)
    box(ax, (B_LOSS[0], B_LOSS[1]), B_LOSS[2], B_LOSS[3],
        r"$\mathcal{L}=w_{\mathrm{PDE}}\|\mathcal{R}_{\mathrm{PDE}}\|^{2}+"
        r"w_{\mathrm{IC}}\|\mathcal{R}_{\mathrm{IC}}\|^{2}$"
        + "\n(" + r"$E_k=300$ epochs" + ")",
        fc="#DDEBF7", fs=8.5)
    box(ax, (B_RESID[0], B_RESID[1]), B_RESID[2], B_RESID[3],
        r"$\varepsilon_{\mathrm{PDE}}=\mathrm{rms}(\mathcal{R}_{\mathrm{PDE}})$"
        + "\n" + r"on $N_{\mathrm{res}}=250$",
        fc="#FFF2CC", fs=8.5)

    arrow(ax, bot(B_LAMBDA), top(B_LOSS))
    arrow(ax, bot(B_LOSS), top(B_RESID))

    # ---- Decision diamond ----
    cx0, cy0 = B_DIAMOND_C
    hw, hh = 0.90, 0.50
    diamond = Polygon([(cx0, cy0 + hh), (cx0 + hw, cy0),
                       (cx0, cy0 - hh), (cx0 - hw, cy0)],
                      closed=True, fill=True, facecolor="#FFE699",
                      edgecolor="#BF8F00", linewidth=1.4)
    ax.add_patch(diamond)
    ax.text(cx0, cy0, r"$\varepsilon_{\mathrm{PDE}}<\epsilon_{\mathrm{tol}}$?",
            ha="center", va="center", fontsize=8.5)
    arrow(ax, bot(B_RESID), (cx0, cy0 + hh))

    # ---- Diamond Yes -> right to Trigger ----
    arrow(ax, (cx0 + hw, cy0), left(T_DATA),
          color="#385723", lw=1.6)
    ax.text((cx0 + hw + left(T_DATA)[0]) / 2, cy0 + 0.15, "Yes",
            fontsize=9, color="#385723", style="italic", ha="center")

    # ---- Diamond No -> loop back up to next lambda ----
    # arrow from bottom vertex curving left then up to B_LAMBDA left edge
    arrow(ax, (cx0 - hw, cy0), (B_LAMBDA[0], B_LAMBDA[1] + B_LAMBDA[3]/2),
          color="#C00000", lw=1.4,
          connectionstyle="arc3,rad=-0.55")
    ax.text(cx0 - 1.30, cy0 + 0.15, "No",
            fontsize=9, color="#C00000", style="italic", ha="center")

    # ====================== Trigger (right column) ===========================
    box(ax, (T_ETD[0],  T_ETD[1]),  T_ETD[2],  T_ETD[3],
        "ETDRK2 reference" + "\n" + r"$M=60$ steps, $N=32$",
        fc="#E2EFDA", fs=8.5)
    box(ax, (T_SUBS[0], T_SUBS[1]), T_SUBS[2], T_SUBS[3],
        "Subsample " + r"$N_{\mathrm{data}}^{\max}=20{,}000$" + "\npoints",
        fc="#E2EFDA", fs=8.5)
    box(ax, (T_DATA[0], T_DATA[1]), T_DATA[2], T_DATA[3],
        "Data anchor " + r"$w_D=50$" + "\n" +
        r"$\mathcal{L} \leftarrow \mathcal{L} + w_D\|\mathcal{R}_D\|^{2}$",
        fc="#DDEBF7", fs=8.5)

    arrow(ax, bot(T_ETD),  top(T_SUBS))
    arrow(ax, bot(T_SUBS), top(T_DATA))

    # After data anchor: feedback left to Phase B's loss (continues descent)
    arrow(ax, left(T_DATA), right(B_LOSS),
          color="#1F4E79", lw=1.2, ls="--",
          connectionstyle="arc3,rad=-0.25")
    ax.text((left(T_DATA)[0] + right(B_LOSS)[0]) / 2, 3.55,
            "data correction feedback",
            fontsize=8, color="#1F4E79", style="italic", ha="center")

    # ====================== Termination ======================================
    box(ax, (T_RET[0], T_RET[1]), T_RET[2], T_RET[3],
        r"Return $\hat{\psi}_{\theta}(\cdot,\cdot,\cdot;\lambda)$ surrogate",
        fc="#C6E0B4", fs=10, bold=True)
    # Termination arrow: from below the diamond
    arrow(ax, (cx0, cy0 - hh), top(T_RET), color="#1F4E79")

    # ====================== Bottom annotation ================================
    ax.text(0.30, -0.05,
            "Algorithm 1 (manuscript). Two sequential phases. "
            "Phase A pre-trains the surrogate against " + r"$\psi_0$"
            + ". Phase B alternates variational Adam descent on " + r"$\lambda_k$"
            + " with a-posteriori trigger-based snapshot supervision.",
            fontsize=8, style="italic", color="#444")

    out_pdf = os.path.join(OUT_DIR, "fig5_algorithm_flowchart.pdf")
    out_png = os.path.join(OUT_DIR, "fig5_algorithm_flowchart.png")
    plt.savefig(out_pdf, bbox_inches="tight")
    plt.savefig(out_png, bbox_inches="tight", dpi=200)
    print(f"[Fig 5] written to {out_pdf} and {out_png}")


if __name__ == "__main__":
    main()