"""Fig 1 composite: solution family over lambda, 1 row x 3 columns."""
from __future__ import annotations
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style
use_style()

import matplotlib.pyplot as plt
import matplotlib.image as mpimg

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "results", "figures")
os.makedirs(OUT_DIR, exist_ok=True)

LAMBDAS = [
    (r"$\lambda = 0$",   "results/02_field_lambda_000.png"),
    (r"$\lambda = 0.5$", "results/02_field_lambda_050.png"),
    (r"$\lambda = 1.0$",  "results/02_field_lambda_100.png"),
]


def main():
    here = os.path.dirname(__file__)
    parent = os.path.join(here, "..")
    fig, axes = plt.subplots(3, 1, figsize=(6.4, 12.6))
    for ax, (label, rel_path) in zip(axes, LAMBDAS):
        png_path = os.path.join(parent, rel_path)
        img = mpimg.imread(png_path)
        ax.imshow(img)
        ax.set_axis_off()
        ax.set_title(label, fontsize=14)
    fig.suptitle(
        r"Solution family $|\psi(x,y)|$ over $\lambda$: heal benchmark (NN top, ETDRK2 ref. bottom)",
        fontsize=12.5, weight="bold", y=1.02)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    out_pdf = os.path.join(OUT_DIR, "fig2_field_lambda.pdf")
    out_png = os.path.join(OUT_DIR, "fig2_field_lambda.png")
    plt.savefig(out_pdf, bbox_inches="tight")
    plt.savefig(out_png, bbox_inches="tight", dpi=200)
    print(f"[Fig 1] composite written (1x3 layout)")


if __name__ == "__main__":
    main()