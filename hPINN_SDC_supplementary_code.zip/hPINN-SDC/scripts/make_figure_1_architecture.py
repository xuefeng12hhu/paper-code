"""
make_figure_1_architecture.py
=============================
Fig 1: Neural surrogate architecture & variational objective.

Two-tier layout:
  Top tier    (y in [4.4, 5.2])   network: input -> Fourier -> ResBlocks -> output
  Mid tier    (y in [2.4, 3.1])   three residual functionals + weighted sum
  Bottom tier (y in [0.4, 1.2])   Adam iteration + activation trigger

Arrows are constrained so each originates on a box edge and terminates on
the destination box edge. No floating arrows.

Output:
    results/figures/fig1_architecture.pdf
    results/figures/fig1_architecture.png
"""
from __future__ import annotations
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style

use_style()

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "results", "figures")
os.makedirs(OUT_DIR, exist_ok=True)
OUT_PDF = os.path.join(OUT_DIR, "fig1_architecture.pdf")
OUT_PNG = os.path.join(OUT_DIR, "fig1_architecture.png")


def box(ax, xy, w, h, text, fc="#E8F1FB", ec="#1F4E79", lw=1.4, fs=10,
        bold=False):
    rect = FancyBboxPatch(xy, w, h,
                          boxstyle="round,pad=0.02,rounding_size=0.05",
                          linewidth=lw, edgecolor=ec, facecolor=fc)
    ax.add_patch(rect)
    weight = "bold" if bold else "normal"
    ax.text(xy[0] + w / 2, xy[1] + h / 2, text,
            ha="center", va="center", fontsize=fs, weight=weight)


def arrow(ax, p1, p2, color="#1F4E79", lw=1.3, ls="-", mut=14):
    arr = FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=mut,
                          linewidth=lw, color=color, linestyle=ls,
                          shrinkA=0, shrinkB=0)
    ax.add_patch(arr)


# ---- Geometry of every box (left, bottom, width, height) -------------------
# Top tier (network)
INPUT    = dict(x=0.20, y=4.40, w=1.60, h=0.55)
FOURIER  = dict(x=2.10, y=4.40, w=1.90, h=0.55)
RB_X0    = 4.30
RB_W, RB_H, RB_DX = 1.00, 0.55, 1.10
N_RB     = 3
OUTPUT   = dict(x=8.10, y=4.40, w=1.50, h=0.55)

# Mid tier (loss functionals)
PDE      = dict(x=0.30, y=2.30, w=2.30, h=0.75)
IC       = dict(x=3.20, y=2.30, w=2.00, h=0.75)
DATA     = dict(x=5.80, y=2.30, w=2.40, h=0.75)
LSUM     = dict(x=8.40, y=2.30, w=1.40, h=0.75)

# Bottom tier (Adam + trigger)
ADAM     = dict(x=3.20, y=0.40, w=3.40, h=0.75)
TRIGGER  = dict(x=7.80, y=0.40, w=2.00, h=0.75)


def right(b): return (b["x"] + b["w"], b["y"] + b["h"] / 2)
def left(b):  return (b["x"],            b["y"] + b["h"] / 2)
def top(b):   return (b["x"] + b["w"]/2, b["y"] + b["h"])
def bot(b):   return (b["x"] + b["w"]/2, b["y"])


def resblock(i):
    return dict(x=RB_X0 + i * RB_DX, y=4.40, w=RB_W, h=RB_H)


def main():
    fig, ax = plt.subplots(figsize=(10.0, 6.4))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6.2)
    ax.set_axis_off()

    # ---- Title ----
    ax.text(5, 6.05,
            r"Neural surrogate $\hat{\psi}_{\theta}(x,y,t;\lambda)$ and variational objective",
            ha="center", va="center", fontsize=12.5, weight="bold")

    # ===================== TOP TIER (network) =================================
    box(ax, (INPUT["x"],   INPUT["y"]),   INPUT["w"],   INPUT["h"],
        r"Input" + "\n" + r"$(x,y,t,\lambda)\in\mathbb{R}^{4}$",
        fc="#FCE4D6", fs=9)
    box(ax, (FOURIER["x"], FOURIER["y"]), FOURIER["w"], FOURIER["h"],
        r"Fourier features $\gamma$" + "\n" + r"$\sigma=0.25$, $m=24$",
        fc="#FCE4D6", fs=9)
    arrow(ax, right(INPUT), left(FOURIER))

    for i in range(N_RB):
        rb = resblock(i)
        label = r"ResBlock" + "\n" + r"$h=128$" if i == 1 else r"ResBlock"
        box(ax, (rb["x"], rb["y"]), rb["w"], rb["h"], label,
            fc="#FFF2CC", fs=9)

    # arrows between ResBlocks
    for i in range(1, N_RB):
        a = right(resblock(i - 1))
        b = left(resblock(i))
        arrow(ax, a, b)

    # arrow from Fourier to first ResBlock
    arrow(ax, right(FOURIER), left(resblock(0)))

    # Output
    box(ax, (OUTPUT["x"], OUTPUT["y"]), OUTPUT["w"], OUTPUT["h"],
        r"Output" + "\n" + r"$\hat{\psi}\in\mathbb{C}$",
        fc="#E2EFDA", fs=9)
    arrow(ax, right(resblock(N_RB - 1)), left(OUTPUT))

    # Skip connection: above ResBlocks, from Fourier-region to Output-region
    y_skip = 5.15
    arrow(ax, (FOURIER["x"] + FOURIER["w"]/2, y_skip),
          (OUTPUT["x"] + OUTPUT["w"]/2,  y_skip),
          color="#888", ls="--", mut=12)
    ax.text(5.0, y_skip + 0.10, "identity skip",
            ha="center", fontsize=8, color="#888", style="italic")

    # ===================== MID TIER (loss functionals) =========================
    box(ax, (PDE["x"], PDE["y"]), PDE["w"], PDE["h"],
        r"PDE residual" + "\n" + r"$\mathcal{R}_{\mathrm{PDE}}$" +
        "\n(eq.~(8))", fc="#DDEBF7", fs=9)
    box(ax, (IC["x"],  IC["y"]),  IC["w"],  IC["h"],
        r"IC anchor" + "\n" + r"$\mathcal{R}_{\mathrm{IC}}$" +
        "\non " + r"$\psi_0$", fc="#DDEBF7", fs=9)
    box(ax, (DATA["x"], DATA["y"]), DATA["w"], DATA["h"],
        r"Snapshot anchor" + "\n" + r"$\mathcal{R}_D$ on $\psi^{\mathrm{ref}}$"
        + "\n(ETDRK2)", fc="#DDEBF7", fs=9)
    box(ax, (LSUM["x"], LSUM["y"]), LSUM["w"], LSUM["h"],
        r"$\mathcal{L}$" + "\n" + r"(eq.~(9))",
        fc="#FCE4D6", fs=9, bold=True)

    # arrows Output -> each functional
    arrow(ax, (OUTPUT["x"] + OUTPUT["w"]/2, OUTPUT["y"]),
          (PDE["x"] + PDE["w"]/2, PDE["y"] + PDE["h"]))
    # IC anchor arrow from the initial condition label (drawn as small marker)
    arrow(ax, (OUTPUT["x"] + OUTPUT["w"]/2, OUTPUT["y"]),
          (IC["x"] + IC["w"]/2, IC["y"] + IC["h"]))
    arrow(ax, (OUTPUT["x"] + OUTPUT["w"]/2, OUTPUT["y"]),
          (DATA["x"] + DATA["w"]/2, DATA["y"] + DATA["h"]))

    # arrows from functionals to L sum
    arrow(ax, right(PDE),  left(LSUM))
    arrow(ax, right(IC),   left(LSUM))
    arrow(ax, right(DATA), left(LSUM))

    # ===================== BOTTOM TIER ========================================
    box(ax, (ADAM["x"], ADAM["y"]), ADAM["w"], ADAM["h"],
        r"Adam iteration" + "\n" +
        r"$\theta \leftarrow \theta - \eta\,\nabla_{\theta}\mathcal{L}$",
        fc="#E2EFDA", fs=10, bold=True)
    arrow(ax, bot(LSUM), top(ADAM))

    box(ax, (TRIGGER["x"], TRIGGER["y"]), TRIGGER["w"], TRIGGER["h"],
        r"Trigger" + "\n" + r"$\varepsilon_{\mathrm{PDE}}<\epsilon_{\mathrm{tol}}$",
        fc="#FFE699", fs=9, bold=True)
    arrow(ax, bot(DATA), top(TRIGGER))

    # Feedback: Trigger -> activates snapshot -> goes back up
    arrow(ax, (TRIGGER["x"] + 0.5, TRIGGER["y"] + TRIGGER["h"]),
          (DATA["x"] + DATA["w"]/2, DATA["y"] + DATA["h"]),
          color="#A05000", ls="--", mut=12)
    ax.text(7.0, 1.5, "activate", fontsize=8, color="#A05000",
            style="italic", ha="center")

    # ---- Legend strip ----
    ax.text(0.30, 0.10,
            r"Fourier features (Tancik et al. 2020)  $\cdot$  "
            r"residual blocks  $\cdot$  phase-A pre-training on "
            r"$\psi_0$ for 200 epochs  $\cdot$  phase-B homotopy for "
            r"$K{=}2$, 300 epochs each  $\cdot$  data correction 900 epochs",
            fontsize=8, color="#444", style="italic")

    plt.savefig(OUT_PDF, bbox_inches="tight")
    plt.savefig(OUT_PNG, bbox_inches="tight", dpi=200)
    print(f"[Fig 1] written to {OUT_PDF} and {OUT_PNG}")


if __name__ == "__main__":
    main()