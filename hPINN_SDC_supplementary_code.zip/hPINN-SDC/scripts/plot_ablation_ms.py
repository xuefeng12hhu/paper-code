"""
plot_ablation_ms.py
===================
从 results/benchmarks_ms/summary.json 重绘六变体消融柱状图
（覆盖 results/ablation/ablation.png），与论文表 2 同一数据源。
Times New Roman，无网格线。
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- Times New Roman 全局字体 ----
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "Nimbus Roman", "DejaVu Serif"],
    "mathtext.fontset": "stix",          # 与 Times 观感一致的数学字体
    "axes.grid": False,                   # 去掉网格线
})

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S = json.load(open(os.path.join(ROOT, "results", "benchmarks_ms", "summary.json"),
                   encoding="utf-8"))
tab = S["table"]

CASES = ["heal", "pair", "quench"]
VARIANTS = ["full", "no_homotopy", "no_correct", "no_ff", "vanilla", "causal"]
LABELS = {"full": "Full", "no_homotopy": "No Homotopy", "no_correct": "No Correction",
          "no_ff": "No Fourier", "vanilla": "Vanilla", "causal": "Causal PINN"}
COLORS = ["#1f3b73", "#7fa8d9", "#b3c7e8", "#f4a261", "#e76f51", "#8d99ae"]

# 真实种子数：取表中最大 n
n_seed = max((int(r["n"]) for c in tab.values() for r in c.values()), default=0)

x = np.arange(len(CASES))
w = 0.13
fig, ax = plt.subplots(figsize=(9, 4.2))
for i, v in enumerate(VARIANTS):
    means = [tab[c][v]["mean"] for c in CASES]
    stds = [tab[c][v]["std"] for c in CASES]
    ax.bar(x + (i - 2.5) * w, means, w, yerr=[2 * s for s in stds],
           capsize=2, color=COLORS[i], label=LABELS[v],
           error_kw={"elinewidth": 0.8})
ax.set_xticks(x); ax.set_xticklabels([c.capitalize() for c in CASES])
ax.set_ylabel(r"Mean Relative $L^2$ Error $e_2$")
ax.set_title(rf"Cross-Benchmark Ablation (Mean $\pm 2\sigma$,"
             rf" $N_{{\rm seed}} = {n_seed}$, Unified Budget)")
ax.legend(fontsize=8, ncol=3, frameon=False)
fig.tight_layout()
out = os.path.join(ROOT, "results", "ablation", "ablation.png")
fig.savefig(out, dpi=130)
print("saved", out, "| n_seed =", n_seed)
