"""
make_figure_10_lambda_scan.py
=============================
Fig 10 (manuscript label fig:lambda_scan): parametric accuracy across the
homotopy parameter λ.

The training + scan itself is done by `lambda_scan.py` at the project root,
which writes:

    results/lambda_scan/<case>_<variant>.json

This script ONLY re-paints the summary figure
(`results/lambda_scan/summary.png`) from those JSON files -- no re-training.

The plot is a single semilog-y axes with two curve families per benchmark:
  - full      (homotopy-trained, λ ∈ {0, 1/3, 2/3, 1} seen during training)
  - no_homotopy (trained only at λ = 1, used as a baseline)

Typesetting matches the rest of the manuscript:
  - Times-like serif (Times New Roman / STIX) via figure_style.use_style()
  - italic λ, italic e₂, upright 2; upright "homotopy" / "λ-only"
  - no gridlines, legend without border
  - sentence-case title and axis labels
"""
from __future__ import annotations
import glob
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from figure_style import use_style
use_style()

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter, LogLocator


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LAMBDA_DIR = os.path.join(ROOT, "results", "lambda_scan")
OUT_PNG = os.path.join(LAMBDA_DIR, "summary.png")


# style: marker + colour per (case, variant)
COLORS = {
    "heal":   "#1F4E79",
    "pair":   "#C00000",
    "quench": "#385723",
}
MARKERS = {
    "full":        "o",
    "no_homotopy": "s",
}
LINESTYLES = {
    "full":        "-",
    "no_homotopy": "--",
}
LABEL = {
    "full":        r"homotopy ($\lambda \in \{0,\tfrac{1}{3},\tfrac{2}{3},1\}$)",
    "no_homotopy": r"$\lambda = 1$ only",
}


def load_records() -> list[dict]:
    """Load every <case>_<variant>.json produced by lambda_scan.py."""
    paths = sorted(glob.glob(os.path.join(LAMBDA_DIR, "*_*.json")))
    recs = []
    for p in paths:
        with open(p, encoding="utf-8") as f:
            recs.append(json.load(f))
    return recs


def main():
    recs = load_records()
    if not recs:
        raise SystemExit(f"no records in {LAMBDA_DIR} -- run lambda_scan.py first")

    fig, ax = plt.subplots(figsize=(7.5, 5.2))

    for r in recs:
        case = r["case"]
        variant = r["variant"]
        xs = [row["lam"] for row in r["rows"]]
        ys = [max(row["e2_mean"], 1e-4) for row in r["rows"]]
        ax.semilogy(
            xs, ys,
            color=COLORS.get(case, "#444"),
            marker=MARKERS.get(variant, "o"),
            ls=LINESTYLES.get(variant, "-"),
            lw=2.0, ms=8.0, mec="black", mew=0.6,
            label=f"{case} / {variant}",
        )

    # dashed marker at λ = 1 (training point of the λ-only baseline)
    ax.axvline(1.0, color="#888", ls=":", lw=1.2)
    # light annotation, no bbox, no border
    ax.text(1.02, 1.05, r"$\lambda = 1$ (training point)",
            transform=ax.get_xaxis_transform(),
            fontsize=11.0, color="#888", style="italic", ha="left")

    # sentence-case axes, italic math scalars
    ax.set_xlabel(r"Homotopy parameter $\lambda$", fontsize=13.0)
    ax.set_ylabel(r"Mean relative error $e_{2}$ (over $t \in [0, T]$)",
                  fontsize=13.0)
    ax.set_title(r"Parametric accuracy across the homotopy parameter",
                 fontsize=14.0, weight="bold", y=1.02)

    ax.tick_params(axis="both", labelsize=11.0)
    # minor gridlines on x at λ = 0.25, 0.5, 0.75 if visible
    ax.set_xticks([0.0, 0.25, 0.5, 0.75, 1.0])
    ax.set_xlim(-0.05, 1.10)

    # y-axis: log scale with decimal tick labels (0.1, 0.2, ... 1, 2, 5)
    # instead of the default "10^k" rendering of semilogy.
    def _dec(v, _pos):
        if v >= 1:
            return f"{v:.1f}"
        # below 1, two significant digits but always show one decimal
        return f"{v:.1f}".rstrip("0").rstrip(".") or "0"
    ax.yaxis.set_major_locator(
        LogLocator(base=10.0, subs=(1.0, 2.0, 3.0, 5.0, 7.0), numticks=8)
    )
    ax.yaxis.set_major_formatter(FuncFormatter(_dec))
    ax.yaxis.set_minor_locator(
        LogLocator(base=10.0, subs=(2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0),
                   numticks=12)
    )
    ax.yaxis.set_minor_formatter(plt.NullFormatter())

    # no gridlines, no legend border; legend moved down into the empty top-middle
    ax.grid(False)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, 0.92),
              fontsize=10.0, frameon=False, ncol=3)

    plt.tight_layout()
    plt.savefig(OUT_PNG, bbox_inches="tight", dpi=200)
    plt.close(fig)
    print(f"[Fig 10] rewritten summary.png at {OUT_PNG}")


if __name__ == "__main__":
    main()