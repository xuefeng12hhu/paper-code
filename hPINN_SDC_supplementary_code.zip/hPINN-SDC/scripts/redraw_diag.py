"""
redraw_diag.py
==============
用 results/stage3/nets 中缓存的 lite/full 网络（与 benchmarks_ms 表格同配置）
重绘 results/benchmarks/<case>_diag.png 诊断面板，不重新训练。

quench 初值在 P2.6 修复后与网格无关，旧图（修复前 IC）必须重绘。
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from figure_style import use_style
use_style()

import numpy as np
import torch
import matplotlib.pyplot as plt

from src.homotopy_nn import TrainConfig, evaluate_grid, HomotopyNet
from src.reference_solver import ETD2RK, make_initial_condition, vortex_map
from src.evaluation import rel_l2_error, linf_error, free_energy, dissipation_residual

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results", "benchmarks")
NETS = os.path.join(ROOT, "results", "stage3", "nets")
L, N_REF, M = 10.0, 48, 60

CASES = {
    "heal":   dict(kind="gaussian", params=dict(eps=0.8, sigma=1.5), T=5.0),
    "pair":   dict(kind="pair",     params=dict(sep=5.0, xi=0.5),   T=6.0),
    "quench": dict(kind="quench",   params=dict(ell=1.5, rms=0.4, seed=2), T=4.0),
}
RECIPES = {
    "lite": dict(ic_pretrain_epochs=200, K=4, stage_epochs=100,
                 correct_epochs=100, final_correct_epochs=200, N_data_max=4000),
}


def make_cfg(recipe, case, seed):
    R = RECIPES[recipe]
    return TrainConfig(L=L, T=case["T"], ic_kind=case["kind"],
                       ic_params=case["params"], seed=seed,
                       ic_pretrain_epochs=R["ic_pretrain_epochs"], K=R["K"],
                       E_k=[R["stage_epochs"]] * R["K"],
                       correct_schedule="always", correct_epochs=R["correct_epochs"],
                       final_correct_epochs=R["final_correct_epochs"],
                       final_extra_data=True, N_data_max=R["N_data_max"],
                       N_grid=32, N_ic=400)


def main():
    torch.set_num_threads(2)
    stats = {}
    for cname, case in CASES.items():
        T = case["T"]
        cfg = make_cfg("lite", case, 0)
        fp = os.path.join(NETS, f"{cname}_lite_s0.pt")
        assert os.path.exists(fp), fp
        net = HomotopyNet(hidden=cfg.hidden, num_blocks=cfg.num_blocks,
                          num_freqs=cfg.num_freqs, sigma=cfg.ff_sigma,
                          in_dim=4, out_dim=2, L=cfg.L, seed=cfg.seed).to(cfg.device)
        net.load_state_dict(torch.load(fp, map_location=cfg.device))

        psi0 = make_initial_condition(case["kind"], N_REF, L, **case["params"])
        ref = ETD2RK(lam=1.0, L_box=L, N=N_REF).integrate(
            psi0, dt=T / (M - 1), n_steps=M - 1, snapshot_every=1)
        F_ref, mono = dissipation_residual(ref, L, lam=1.0)
        v_ref = (vortex_map(ref).abs() > 0.5).sum(dim=(-1, -2)).numpy()

        out = evaluate_grid(net, cfg, lam=1.0, M=M, N=N_REF)
        nn = torch.tensor(out["snaps"])
        e2 = rel_l2_error(nn, ref).numpy()
        ei = linf_error(nn, ref).numpy()
        F_nn = free_energy(nn, L, lam=1.0).numpy()
        v_nn = (vortex_map(nn).abs() > 0.5).sum(dim=(-1, -2)).numpy()
        t = np.linspace(0, T, M)

        np.savez(os.path.join(OUT, f"{cname}_ref.npz"), snaps=ref.numpy(),
                 F=F_ref.numpy(), vcount=v_ref, t=t, N=N_REF, L=L, T=T)
        np.savez(os.path.join(OUT, f"{cname}_nn.npz"), snaps=nn.numpy(),
                 F=F_nn, vcount=v_nn, rel_l2=e2, linf=ei, t=t)

        fig, axes = plt.subplots(1, 3, figsize=(13.5, 3.8))
        LW = 3.0
        axes[0].plot(t, F_ref, "k-",  lw=LW, label="ETDRK2 ref.")
        axes[0].plot(t, F_nn,  "r--", lw=LW, label="Homotopy NN")
        axes[0].set_xlabel(r"$t$", fontsize=14.0)
        axes[0].set_ylabel(r"Free energy $F_\lambda[\psi]$", fontsize=14.0)
        axes[0].set_title(f"{cname.capitalize()}: Free energy", fontsize=17.0)
        axes[0].legend(fontsize=12.5, frameon=False); axes[0].grid(False)
        axes[1].semilogy(t, np.maximum(e2, 1e-10), "b-",  lw=LW,
                         label=r"Rel.\ $L^{2}$")
        axes[1].semilogy(t, np.maximum(ei, 1e-10), "g--", lw=LW,
                         label=r"$L^{\infty}$")
        axes[1].set_xlabel(r"$t$", fontsize=14.0)
        axes[1].set_ylabel(r"Error vs.\ ref.", fontsize=14.0)
        axes[1].set_title(f"{cname.capitalize()}: NN error", fontsize=17.0)
        axes[1].legend(fontsize=12.5, frameon=False); axes[1].grid(False)
        axes[2].plot(t, v_ref, "k-",  lw=LW, label=r"Ref.\ $|w|>0.5$ cells")
        axes[2].plot(t, v_nn,  "r--", lw=LW, label="NN")
        axes[2].set_xlabel(r"$t$", fontsize=14.0)
        axes[2].set_ylabel(r"Vortex cells", fontsize=14.0)
        axes[2].set_title(f"{cname.capitalize()}: Vortices", fontsize=17.0)
        axes[2].legend(fontsize=12.5, frameon=False); axes[2].grid(False)
        for ax in axes:
            ax.tick_params(axis="both", labelsize=12.0)
        fig.tight_layout()
        for ext in (".pdf", ".png"):
            fig.savefig(os.path.join(OUT, f"{cname}_diag{ext}"),
                        dpi=200 if ext == ".png" else None)
        plt.close(fig)
        stats[cname] = dict(e2_mean=float(e2.mean()), e2_final=float(e2[-1]),
                            peak_ref=int(v_ref.max()), peak_nn=int(v_nn.max()),
                            F_mono=bool(mono))
        print(f"{cname}: e2_mean={e2.mean():.3f} peak vortices "
              f"ref/nn={int(v_ref.max())}/{int(v_nn.max())} F_mono={mono}", flush=True)
    with open(os.path.join(OUT, "diag_stats.json"), "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=1)


if __name__ == "__main__":
    main()
