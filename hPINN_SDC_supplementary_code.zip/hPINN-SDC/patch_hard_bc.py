"""硬约束改造：HomotopyNet + 训练时 psi0 索引修正。"""
import re
from pathlib import Path

path = Path(r"c:\Users\26271\CodeBuddy\20260915195945\homotopy-tdgl\src\homotopy_nn.py")
src = path.read_text(encoding="utf-8")

# 1) 替换 HomotopyNet 类
old_block = '''class HomotopyNet(nn.Module):
    """神经网络代理 ψ̂(x,y,t,λ) → (u,v)。"""

    def __init__(self, hidden: int = 64, num_blocks: int = 3,
                 num_freqs: int = 16, sigma: