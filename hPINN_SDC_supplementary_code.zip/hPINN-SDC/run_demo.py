"""
run_demo.py
===========
完整演示脚本：
1. 在多个 λ 值上运行 ETDRK2 正弦谱参考求解器（P0 修复后）
2. 训练同伦神经网络代理（真实 PDE 残差触发 learn-then-correct）
3. 对比评估并生成可视化

运行方法（需先 cd 到本项目根目录）:
    python run_demo.py

依赖: torch, numpy, matplotlib
"""

from __future__ import annotations

import sys
import os
import time

# 让 src/ 能作为包导入
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import numpy as np
import torch

from src.reference_solver import solve_tdgl, total_mass, initial_condition
from src.homotopy_nn import (
    HomotopyNet, TrainConfig, train_homotopy_nn, evaluate_grid,
)
from src.visualize import (
    plot_field_comparison, plot_homotopy_path_diagnostics,
    plot_time_diagnostics, plot_phase_density, plot_lambda_panel,
)


def main():
    print("=" * 70)
    print("  Neural-Homotopy Hybrid Solver for Superconducting TDGL")
    print("=" * 70)

    # --------------------- 配置 ---------------------
    device = "cpu"
    L = 10.0
    T = 5.0
    N_grid = 32
    M_snap = 50

    cfg = TrainConfig(
        L=L, T=T, N_grid=N_grid, M_snap=M_snap,
        eps=0.8, sigma_ic=1.5,
        K=6,
        E_k=[400, 400, 400, 400, 400, 500],
        lr=1.5e-3,
        N_res=2000, N_ic=500,
        N_data_max=4000, tol=1.0,
        correct_epochs=100,
        device=device,
    )

    # --------------------- 1. 参考解（多 λ）---------------------
    print("\n[1/4] 生成 ETD2RK 参考解...")
    lam_values = [0.0, 0.25, 0.5, 0.75, 1.0]
    ref_snaps_by_lam = {}
    ref_mass_by_lam = {}
    psi0 = initial_condition(N_grid, L, eps=cfg.eps, sigma=cfg.sigma_ic,
                              device=device)

    for lam in lam_values:
        t0 = time.time()
        snaps = solve_tdgl(lam=lam, L=L, N=N_grid, T=T, M=M_snap,
                            eps=cfg.eps, sigma=cfg.sigma_ic, device=device)
        ref_snaps_by_lam[lam] = snaps.cpu().numpy()
        ref_mass_by_lam[lam] = total_mass(snaps).cpu().numpy()
        print(f"  λ={lam:.2f}  shape={snaps.shape}  "
              f"elapsed={time.time() - t0:.2f}s")

    # --------------------- 2. 神经网络训练 ---------------------
    print("\n[2/4] 训练同伦神经网络代理...")
    t0 = time.time()
    net, history = train_homotopy_nn(cfg, verbose=True)
    print(f"  训练耗时: {time.time() - t0:.2f}s")

    # --------------------- 3. 评估与对比 ---------------------
    print("\n[3/4] 评估神经网络代理（多 λ）...")
    nn_snaps_by_lam = {}
    nn_mass_by_lam = {}
    for lam in lam_values:
        out = evaluate_grid(net, cfg, lam=lam, M=20, N=N_grid)
        nn_snaps_by_lam[lam] = out["snaps"]
        nn_mass_by_lam[lam] = out["mass"]

    # --------------------- 4. 可视化 ---------------------
    print("\n[4/4] 生成可视化...")
    out_dir = "results"
    os.makedirs(out_dir, exist_ok=True)

    # (a) 同伦路径诊断
    plot_homotopy_path_diagnostics(history,
                                    f"{out_dir}/01_homotopy_diag.png")

    # (b) 多 λ 场对比
    for lam in lam_values:
        plot_field_comparison(
            nn_snaps_by_lam[lam],
            ref_snaps_by_lam[lam],
            lam=lam, L=L, T=T,
            out_path=f"{out_dir}/02_field_lambda_{int(lam*100):03d}.png",
            title_prefix="",
        )

    # (c) λ=1 时间演化诊断
    nn_m = nn_mass_by_lam[1.0]
    ref_m = ref_mass_by_lam[1.0]
    t_nn = np.linspace(0, T, nn_m.size)
    t_ref = np.linspace(0, T, ref_m.size)
    plot_time_diagnostics(nn_m, ref_m,
                           t_nn=t_nn, t_ref=t_ref, lam=1.0,
                           out_path=f"{out_dir}/03_mass_evolution.png")

    # (d) 相位+密度图 (TDGL 终态)
    final_idx = nn_snaps_by_lam[1.0].shape[0] - 1
    plot_phase_density(nn_snaps_by_lam[1.0][final_idx],
                       t_val=T, L=L,
                       out_path=f"{out_dir}/04_phase_density_tdgl.png")

    # (e) 多 λ 拼图
    final_snaps = {lam: nn_snaps_by_lam[lam][-1] for lam in lam_values}
    plot_lambda_panel(final_snaps, L=L,
                       out_path=f"{out_dir}/05_lambda_panel.png")

    print(f"\n[done] 可视化结果保存到: {out_dir}/")
    for fname in sorted(os.listdir(out_dir)):
        print(f"  - {fname}")


if __name__ == "__main__":
    main()