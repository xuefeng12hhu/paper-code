"""homotopy_nn.py -- Neural-Homotopy for TDGL."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple, Callable
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from .reference_solver import (
    ETD2RK, make_initial_condition as make_ic,
    A_symmetric, A_landau_y,
)


class FourierFeatures(nn.Module):
    def __init__(self, in_dim, num_freqs=16, sigma=2.0, seed=0):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        self.register_buffer("B", sigma * torch.randn(num_freqs, in_dim, generator=g))
    def forward(self, v):
        proj = 2*np.pi*v @ self.B.T
        return torch.cat([v, torch.sin(proj), torch.cos(proj)], dim=-1)


class ResidualBlock(nn.Module):
    def __init__(self, dim): super().__init__(); self.fc1=nn.Linear(dim,dim); self.fc2=nn.Linear(dim,dim)
    def forward(self,x): return x + torch.tanh(self.fc2(torch.tanh(self.fc1(x))))



class HomotopyNet(nn.Module):
    def __init__(self, hidden=64, num_blocks=3, num_freqs=16, sigma=2.0,
                 in_dim=4, out_dim=2, seed=0, L=10.0):
        super().__init__()
        self.ff = FourierFeatures(in_dim, num_freqs=num_freqs, sigma=sigma, seed=seed)
        ff_dim = in_dim + 2*num_freqs
        self.input_proj = nn.Linear(ff_dim, hidden)

        self.blocks = nn.ModuleList([ResidualBlock(hidden) for _ in range(num_blocks)])
        self.output = nn.Linear(hidden, out_dim)
        self.L = float(L)

    def forward(self, xyt_l):
        h = torch.tanh(self.input_proj(self.ff(xyt_l)))
        for blk in self.blocks: h = blk(h)
        raw = self.output(h)
        x = xyt_l[:,0]; y = xyt_l[:,1]
        d = torch.minimum(torch.minimum(x, self.L-x), torch.minimum(y, self.L-y))
        return 1.0 + d.unsqueeze(-1) * raw



@dataclass
class TrainConfig:
    L: float = 10.0
    T: float = 5.0
    N_grid: int = 32
    M_snap: int = 50
    eps: float = 0.5
    sigma_ic: float = 1.2
    # ---- 初值类型分发（阶段 1.2）：gaussian / pair / quench ----
    ic_kind: str = "gaussian"
    ic_params: Dict = field(default_factory=dict)  # pair: {sep,xi}; quench: {ell,rms,seed}
    K: int = 4
    E_k: List[int] = field(default_factory=lambda: [300]*4)
    lr: float = 2e-3
    N_res: int = 2000
    N_ic: int = 400
    N_data_max: int = 20000
    tol: float = 0.05
    correct_epochs: int = 300
    # ---- 校正调度（阶段 2：触发机制与预算重设计）----
    # "always"   每段 λ_k 都做 learn-then-correct（调度式，不依赖残差阈值——
    #            残差受 Fourier 特征导数噪声地板 (~0.5) 干扰，低残差算例如 heal
    #            触发过晚，e2 最差）
    # "residual" 旧式：残差 RMS > tol 才触发
    # 数据项 minibatch（0=全批）。阶段 2 发现：纯数据拟合 3000 epochs × 8192 点
    # 可达 e2=0.045，而全批 20000 点的校正循环受 epoch 预算限制只到 0.19
    batch_data: int = 0
    final_correct_epochs: int = 900   # 阶段 2 经验：900 是甜点，更长 e2 反而上升
    final_extra_data: bool = True      # 末段 ETD 快照加密（M×2）
    # 末段 PDE 权重（-1 表示沿用 w_pde）。数据主导精度，末段可进一步弱化残差项
    w_pde_final: float = -1.0
    # 校正段余弦退火：默认关闭（H1 配方 900 ep 无退火 e2=0.186；开启退火 e2=0.424）。
    # 仅在长预算（≥1500 epochs）下开启可避免发散（G1: 无退火 2500 ep → e2=1.6）；
    # 短预算（~900 ep）下退火损伤有效学习。
    correct_lr_decay: bool = False
    lr_min_factor: float = 0.05
    correct_schedule: str = "always"
    # ---- 损失权重（阶段 1 发现：约束平衡 + 数据主导精度）----
    w_pde: float = 0.1        # PDE 残差权重（正则化 / λ 泛化；过大产生导数噪声失衡）
    w_ic: float = 100.0       # 初值项权重（L_pde 量级 ~1e3，w_ic=10 时 IC 被淹没）
    w_data: float = 50.0      # learn-then-correct 数据项权重（精度的主力来源）
    # ---- 网络架构（阶段 1 发现：特征带宽 → 导数噪声地板）----
    ff_sigma: float = 0.25    # Fourier 特征带宽：σ 大 → 拟合值准但 ∇² 噪声爆炸
    hidden: int = 128
    num_blocks: int = 4
    num_freqs: int = 24
    # ---- 训练课程（阶段 1 发现：先 IC 预训练，否则 PDE 项摧毁 IC 拟合）----
    ic_pretrain_epochs: int = 300
    # 阶段 2：收敛判据驱动预训练（固定 epoch 数在细网格/全格点监督下远远不够：
    # N_grid=48 全格点时 800 epochs 仅达 rel-L2 0.25，纯回归需 1500+ 才能到 0.06）
    ic_pretrain_tol: float = 0.0    # >0 时启用：L_ic < tol 即提前结束
    ic_pretrain_max: int = 4000     # 早停模式下的 epoch 上限
    m_snap_correct: int = 30  # learn-then-correct 快照帧数（含 t=0）
    device: str = "cpu"
    # ---- 随机性（多种子统计）----
    # 统一随机源：train_homotopy_nn 开头执行 torch.manual_seed(seed)，网络初始化、
    # Fourier 特征基、配置点采样、数据下采样全部由它派生。
    # 旧版特征基固定 seed=0、数据下采样固定 rng(0)，只有网络初始化与采样随调用方的
    # manual_seed 变化，多种子统计的自由度被低估。
    seed: int = 0
    # ---- 因果时间加权（外部基线 causal PINN，Wang et al. 2024）----
    # causal=True 时 PDE 残差按时间分箱加权
    #     w_b = exp(-eps * sum_{k<b} L_k),  L_b = bin b 的残差均方
    # 使晚时残差只在早时被压低之后才被计入，缓解"长时误差累积"这一
    # PINN 失效模式。作为外部基线，用于检验因果加权能否替代
    # 同伦延拓 + 数据校正。
    causal: bool = False
    causal_bins: int = 8
    causal_eps: float = 1.0
    # ---- 阶段 3：完整 GL 含矢量势 A ----
    # B_field > 0 时启用 (-i∇-A)² ψ 项；gauge 指定规范选择
    B_field: float = 0.0
    gauge: str = "symmetric"  # "symmetric" 或 "landau_y"
    # 显式 A 场函数（None 时按 B_field + gauge 自动构造）

    def initial_state(self, N: int, device: str = "cpu"):
        """按配置生成分辨率 N 的初值（训练/评估共用）。"""
        params = dict(self.ic_params)
        if self.ic_kind == "gaussian":
            params.setdefault("eps", self.eps)
            params.setdefault("sigma", self.sigma_ic)
        return make_ic(self.ic_kind, N, self.L, device=device, **params)

    def A_field(self):
        """构造 A 场 callable：B_field=0 时返回 None。

        A_field(x, y) → (Ax, Ay)，同 x, y 形状。
        """
        if self.B_field == 0.0:
            return None
        if self.gauge == "symmetric":
            return lambda x, y, B=self.B_field: A_symmetric(x, y, B)
        if self.gauge == "landau_y":
            return lambda x, y, B=self.B_field: A_landau_y(x, y, B)
        raise ValueError(f"unknown gauge: {self.gauge}")



def initial_condition_np(N, L, eps, sigma, device="cpu"):
    """内点网格上的初值（与 reference_solver.initial_condition 一致）。"""
    h = L / (N + 1)
    x = h * np.arange(1, N + 1)
    X, Y = np.meshgrid(x, x, indexing="ij")
    r2 = (X-L/2)**2 + (Y-L/2)**2
    g = np.exp(-r2/(2*sigma**2))
    u = np.clip(1.0 - eps*g, 0.05, None)
    v = -0.2*eps*np.exp(-r2/(2*(0.6*sigma)**2))
    return np.stack([u, v], axis=-1)



def sample_collocation_points(cfg, lam, psi0=None, requires_grad=True):
    """采样 PDE 配置点与初值监督点。

    P0/阶段1 修复：初值监督点必须在 ψ0 所在的内点格点上采样，
    坐标 (x_i, y_j) 与目标值 ψ0[i,j] 严格配对（旧版连续采样坐标
    却配独立随机索引的目标值，IC 损失是纯噪声，卡在 ~0.18 即初值
    场自身方差，无论加权/加密都无法收敛）。

    Parameters
    ----------
    psi0 : (N, N) complex tensor，内点初值（cfg.N_grid 分辨率）
    """
    d = cfg.device
    xy = torch.rand(cfg.N_res, 2, device=d)*cfg.L
    t = torch.rand(cfg.N_res, 1, device=d)*cfg.T
    lc = torch.full((cfg.N_res, 1), lam, device=d)
    xyt_l = torch.cat([xy, t, lc], dim=-1)

    out = dict(xyt_l=xyt_l)
    if psi0 is not None:
        N = psi0.shape[0]
        h = cfg.L / (N + 1)
        Ntot = N * N
        # 阶段2：N_ic ≥ N² 时退化为全格点监督（IC 拟合瓶颈在分辨率
        # 而非采样密度——32→48 网格使 t=0 误差降 36%）
        if cfg.N_ic >= Ntot:
            ix, iy = torch.meshgrid(torch.arange(N, device=d),
                                    torch.arange(N, device=d), indexing="ij")
            ix = ix.reshape(-1); iy = iy.reshape(-1)
        else:
            ix = torch.randint(0, N, (cfg.N_ic,), device=d)
            iy = torch.randint(0, N, (cfg.N_ic,), device=d)
        xs = (ix + 1).float() * h
        ys = (iy + 1).float() * h
        vals = psi0[ix, iy]
        ic_xytl = torch.stack([xs, ys,
                               torch.zeros_like(xs),
                               torch.ones_like(xs)], dim=-1)
        ic_target = torch.stack([vals.real, vals.imag], dim=-1).float()
        out['ic_xytl'] = ic_xytl
        out['ic_target'] = ic_target
    if requires_grad: xyt_l = xyt_l.requires_grad_(True)
    out['xyt_l'] = xyt_l
    return out



def pde_residual(net, xyt_l, lam_value, A_field=None):
    """同伦 PDE 残差（P0.1c 修正后的同伦定义，阶段 3 扩展矢量势）：

    同伦 PDE
        ∂t ψ = (∇ − iA)² ψ + λ (1−|ψ|²) ψ,   ψ|∂Ω = 1
    协变 Laplace（库仑规范 ∇·A = 0）
        (∇ − iA)² ψ = ∇²ψ − 2 i (A·∇ψ) − |A|² ψ

    故残差实现为
        H = ψ_t − (∇−iA)²ψ − λ(1−|ψ|²)ψ
          = (ψ_t − ∇²ψ − λ(1−|ψ|²)ψ) + 2i(A·∇ψ) + |A|²ψ
    其中 A·∇ψ 用 ψ 的 ∂_x, ∂_y 一阶梯度与 A 的标量乘积。

    A_field=None 时退化为 P0.1c 的标准同伦（仅 ∇² + GL 非线性）。
    A_field(x, y) → (Ax, Ay)：实数值矢量势场（如对称规范 A=(-By/2, Bx/2)）。

    P1 修复（见 docs/paper_gap_analysis.md 阶段 9）：旧版此处写作
    ``H = H - gauge_term - A_sq_term``（即 +|A|²ψ + 2iA·∇ψ 进入 PDE
    右端），与 ``ETD2RK._nonlinear`` 的旧符号错误一致，且与本文档
    自身推导的表达式相矛盾。现统一为物理约定 (∇−iA)²。
    """
    u = net(xyt_l); pu = u[:,0]; pv = u[:,1]
    gU = torch.autograd.grad(pu, xyt_l, torch.ones_like(pu), create_graph=True, retain_graph=True)[0]
    gV = torch.autograd.grad(pv, xyt_l, torch.ones_like(pv), create_graph=True, retain_graph=True)[0]

    pu_x,pu_y,pu_t,_ = gU[:,0],gU[:,1],gU[:,2],gU[:,3]
    pv_x,pv_y,pv_t,_ = gV[:,0],gV[:,1],gV[:,2],gV[:,3]
    hUx = torch.autograd.grad(pu_x, xyt_l, torch.ones_like(pu_x), create_graph=True)[0][:,0]
    hUy = torch.autograd.grad(pu_y, xyt_l, torch.ones_like(pu_y), create_graph=True)[0][:,1]
    hVx = torch.autograd.grad(pv_x, xyt_l, torch.ones_like(pv_x), create_graph=True)[0][:,0]
    hVy = torch.autograd.grad(pv_y, xyt_l, torch.ones_like(pv_y), create_graph=True)[0][:,1]
    lap_u = hUx + hUy; lap_v = hVx + hVy
    psi_t = torch.complex(pu_t, pv_t)
    psi = torch.complex(pu, pv)
    nabla2 = torch.complex(lap_u, lap_v)
    psi2 = psi.abs()**2
    H = psi_t - nabla2 - lam_value*(1-psi2)*psi

    if A_field is not None:
        # 在 collocation 点上求 A 与 |A|²
        x = xyt_l[:, 0]; y = xyt_l[:, 1]
        Ax, Ay = A_field(x, y)
        # +2i(A·∇ψ)：来自 −(∇−iA)²ψ 展开中的 −2iA·∇ψ
        psi_x = torch.complex(pu_x, pv_x)
        psi_y = torch.complex(pu_y, pv_y)
        gauge_term = 2j * (Ax * psi_x + Ay * psi_y)
        # +|A|² ψ
        A_sq = (Ax * Ax + Ay * Ay).to(psi.dtype)
        A_sq_term = A_sq * psi
        H = H + gauge_term + A_sq_term
    return H


def residual_rms(net, xyt_l, lam_value):
    """配置点上的 PDE 残差均方根（P0.2：learn-then-correct 的触发判据）。"""
    H = pde_residual(net, xyt_l, lam_value)
    return torch.sqrt((H.abs()**2).mean())


def _causal_pde_mse(r2, t, cfg):
    """PDE 残差的因果时间加权（Wang et al. 2024, "causal PINN"）。

    把 [0, T] 等分为 B 个时间箱，箱内残差均方 L_b，权重

        w_b = exp(-eps * sum_{k<b} L_k),
        L   = (sum_b n_b w_b L_b) / (sum_b n_b w_b),

    其中 n_b 为箱内点数。w_b 按常数（detach）处理，使梯度仍是加权最小二乘
    步。eps -> 0 时退化为无权均方。若权重全部下溢为 0（eps 过大或残差量级
    过高），回退到无权均方，避免 0/0。
    """
    bins = max(int(cfg.causal_bins), 1)
    r2 = r2.reshape(-1)
    t = t.reshape(-1).detach()
    edges = torch.linspace(0.0, float(cfg.T), bins + 1,
                           device=r2.device, dtype=r2.dtype)
    num = torch.zeros((), device=r2.device, dtype=r2.dtype)
    den = torch.zeros((), device=r2.device, dtype=r2.dtype)
    cum = torch.zeros((), device=r2.device, dtype=r2.dtype)
    n_used = 0
    for b in range(bins):
        lo, hi = edges[b], edges[b + 1]
        mask = (t >= lo) & (t < hi) if b < bins - 1 else (t >= lo) & (t <= hi)
        n = int(mask.sum().item())
        if n == 0:
            continue
        n_used += n
        Lb = r2[mask].mean()
        w = torch.exp(-cfg.causal_eps * cum)
        num = num + float(n) * w * Lb
        den = den + float(n) * w
        cum = cum + Lb.detach()
    if n_used == 0 or float(den.item()) == 0.0:
        return r2.mean()
    return num / den


def pde_loss(net, xyt_l, lam_value, A_field=None, cfg=None):
    """PDE 能量项：默认取残差均方；cfg.causal=True 时启用因果时间加权。"""
    H = pde_residual(net, xyt_l, lam_value, A_field=A_field)
    r2 = H.abs()**2
    if cfg is not None and getattr(cfg, "causal", False):
        return _causal_pde_mse(r2, xyt_l[:, 2], cfg)
    return r2.mean()


def _stack_data(data_xytl, data_psi, max_n, rng):
    """拼接校正数据集；超过 max_n 点时随机下采样（P0.2b 修复）。

    旧版在 total > N_data_max 时 pop(0)，而单个数据集就有 M·N² 个点
    （默认 20·32² = 20480 > 4000），导致刚加入的数据被立即驱逐、
    校正循环从未真正训练。现改为无放回下采样。
    """
    X = np.concatenate(data_xytl, axis=0)
    Y = np.concatenate(data_psi, axis=0)
    if X.shape[0] > max_n:
        idx = rng.choice(X.shape[0], size=max_n, replace=False)
        X, Y = X[idx], Y[idx]
    return X, Y


def _generate_etd_snapshots(cfg, lam, psi0, M):
    solver = ETD2RK(lam=lam, L_box=cfg.L, N=cfg.N_grid, device=cfg.device,
                    B_field=cfg.B_field, gauge=cfg.gauge)
    dt = cfg.T/(M-1)
    return solver.integrate(psi0, dt=dt, n_steps=M-1, snapshot_every=1)


def _snapshots_to_data(cfg, snaps, lam):
    """把 ETD 快照转成训练数据。快照含 t=0 初值帧（内点网格）。"""
    M, N, _ = snaps.shape
    L = cfg.L
    h = L / (N + 1)
    x = h * np.arange(1, N + 1)
    X, Y = np.meshgrid(x, x, indexing='ij')
    Xf = X.reshape(-1); Yf = Y.reshape(-1)
    sr = snaps.real.cpu().numpy(); si = snaps.imag.cpu().numpy()
    rx, ry = [], []
    for m in range(M):
        tv = (m/(M-1))*cfg.T
        rx.append(np.stack([Xf, Yf, np.full_like(Xf, tv), np.full_like(Xf, lam)], axis=-1))
        ry.append(np.stack([sr[m].reshape(-1), si[m].reshape(-1)], axis=-1))
    return np.concatenate(rx, axis=0), np.concatenate(ry, axis=0)


def train_homotopy_nn(cfg=None, verbose=True, net=None):
    """同伦两阶段变分极小化。

    Parameters
    ----------
    net : HomotopyNet 或 None
        提供时作为**初始网络**（迁移学习 / 微调热启动）而不是随机初始化；
        架构必须与 cfg 一致（hidden / num_blocks / num_freqs 相同）。
    """
    if cfg is None: cfg = TrainConfig()
    device = cfg.device
    torch.manual_seed(cfg.seed)
    psi0 = cfg.initial_state(cfg.N_grid, device=device)
    A_field = cfg.A_field()  # None 当 B_field=0
    if net is None:
        net = HomotopyNet(hidden=cfg.hidden, num_blocks=cfg.num_blocks,
                          num_freqs=cfg.num_freqs, sigma=cfg.ff_sigma,
                          in_dim=4, out_dim=2, L=cfg.L, seed=cfg.seed).to(device)
    else:
        net = net.to(device)
    opt = torch.optim.Adam(net.parameters(), lr=cfg.lr)

    # ---- 阶段 1 修复：IC 预训练 ----
    # 直接联合训练时，L_pde 的巨大梯度会把网络拖入与初值不匹配的解流形，
    # L_ic 随后无法恢复（卡在 ~0.15）。先单独拟合初值，再开物理项。
    n_pre = cfg.ic_pretrain_epochs
    if cfg.ic_pretrain_tol > 0:
        n_pre = max(cfg.ic_pretrain_epochs, cfg.ic_pretrain_max)
    for e in range(n_pre):
        pts = sample_collocation_points(cfg, 1.0, psi0=psi0)
        L_ic = F.mse_loss(net(pts['ic_xytl']), pts['ic_target'])
        opt.zero_grad(); L_ic.backward(); opt.step()
        if verbose and (e+1) % max(n_pre//3, 1) == 0:
            print(f'  [ic-pretrain e={e+1}/{n_pre}] L_ic={L_ic.item():.3e}')
        if cfg.ic_pretrain_tol > 0 and (e+1) >= cfg.ic_pretrain_epochs \
                and L_ic.item() < cfg.ic_pretrain_tol:
            if verbose:
                print(f'  [ic-pretrain converged @ e={e+1}] L_ic={L_ic.item():.3e}')
            break

    data_xytl = []; data_psi = []; history = []
    rng = np.random.default_rng(cfg.seed)
    for k in range(cfg.K):
        # P0.5 修复：旧式 lam_k = k/max(K-1, 1) 在 K=1 时退化为 lam_k = 0，
        # 即"单段"变体实际在纯热方程端（λ=0）训练——消融表的 no_homotopy /
        # vanilla 与 K 收敛扫描的 K=1 点因此全部失效。
        # K=1 的正确语义是"不做延拓，直接在 λ=1 上训练"。
        lam_k = (k / (cfg.K - 1)) if cfg.K > 1 else 1.0
        E_k = cfg.E_k[k] if k < len(cfg.E_k) else 200
        L_data = torch.tensor(0.0, device=device)
        for e in range(E_k):
            pts = sample_collocation_points(cfg, lam_k, psi0=psi0)
            L_pde = pde_loss(net, pts['xyt_l'], lam_k,
                             A_field=A_field, cfg=cfg)
            ic_pred = net(pts['ic_xytl'])
            L_ic = F.mse_loss(ic_pred, pts['ic_target'])
            if data_xytl:
                Xd, Yd = _stack_data(data_xytl, data_psi, cfg.N_data_max, rng)
                dx = torch.tensor(Xd, dtype=torch.float32, device=device)
                dp = torch.tensor(Yd, dtype=torch.float32, device=device)
                L_data = F.mse_loss(net(dx), dp)
            loss = cfg.w_pde*L_pde + cfg.w_ic*L_ic + cfg.w_data*L_data
            opt.zero_grad(); loss.backward(); opt.step()
            if verbose and (e+1) % max(E_k//5, 1) == 0:
                print(f'  [k={k} lam={lam_k:.2f} e={e+1:4d}/{E_k}] L_pde={L_pde.item():.3e} L_ic={L_ic.item():.3e} L_data={L_data.item():.3e}')
        # ---- P0.2 修复：用真实 PDE 残差 RMS 作为触发判据 ----
        # （旧版误用预测场范数 ‖ψ̂‖，与残差无关）
        pts_eval = sample_collocation_points(cfg, lam_k)
        with torch.enable_grad():
            r_k = float(residual_rms(net, pts_eval['xyt_l'], lam_k).item())
        history.append(dict(k=k, lam=lam_k, residual=r_k, L_pde=L_pde.item(), L_ic=L_ic.item(), L_bc=0.0))
        if verbose: print(f'  >> end of stage k={k} lam={lam_k:.2f}: PDE residual RMS={r_k:.3e}')
        # ---- 校正调度（阶段 2）：调度式优先，残差触发可选 ----
        is_final = (k == cfg.K - 1)
        trigger = (cfg.correct_schedule == "always") or \
                  (cfg.correct_schedule == "residual" and r_k > cfg.tol)
        if trigger:
            n_corr = cfg.final_correct_epochs if is_final else cfg.correct_epochs
            m_snap = cfg.m_snap_correct * 2 if (is_final and cfg.final_extra_data) \
                     else cfg.m_snap_correct
            if verbose:
                print(f'  -- learn-then-correct @ lam={lam_k:.2f} '
                      f'({n_corr} epochs, M={m_snap})')
            snaps = _generate_etd_snapshots(cfg, lam_k, psi0, M=m_snap)
            xytl_arr, psi_arr = _snapshots_to_data(cfg, snaps, lam_k)
            data_xytl.append(xytl_arr); data_psi.append(psi_arr)
            w_pde_eff = cfg.w_pde_final if (is_final and cfg.w_pde_final >= 0) \
                        else cfg.w_pde
            if cfg.correct_lr_decay and n_corr > 1:
                sched = torch.optim.lr_scheduler.CosineAnnealingLR(
                    opt, T_max=n_corr,
                    eta_min=cfg.lr * cfg.lr_min_factor)
            else:
                sched = None
            for _ in range(n_corr):
                Xd, Yd = _stack_data(data_xytl, data_psi, cfg.N_data_max, rng)
                if cfg.batch_data and len(Xd) > cfg.batch_data:
                    bidx = rng.choice(len(Xd), size=cfg.batch_data, replace=False)
                    Xd, Yd = Xd[bidx], Yd[bidx]
                pts = sample_collocation_points(cfg, lam_k, psi0=psi0)
                dx = torch.tensor(Xd, dtype=torch.float32, device=device)
                dp = torch.tensor(Yd, dtype=torch.float32, device=device)
                L_data = F.mse_loss(net(dx), dp)
                L_pde = pde_loss(net, pts['xyt_l'], lam_k,
                                 A_field=A_field, cfg=cfg)
                L_ic = F.mse_loss(net(pts['ic_xytl']), pts['ic_target'])
                loss = w_pde_eff*L_pde + cfg.w_ic*L_ic + cfg.w_data*L_data
                opt.zero_grad(); loss.backward(); opt.step()
                if sched is not None:
                    sched.step()
            history[-1]['corrected'] = True
    return net, history


def evaluate_grid(net, cfg, lam, M=50, N=64):
    """在内点网格（Dirichlet 约定）上评估网络，快照含 t=0 初值帧。"""
    device = cfg.device
    h = cfg.L / (N + 1)
    x = h * np.arange(1, N + 1)
    y = h * np.arange(1, N + 1)
    t = np.linspace(0.0, cfg.T, M)
    X, Y = np.meshgrid(x, y, indexing='ij')
    su = np.zeros((M, N, N)); sv = np.zeros((M, N, N))
    net.eval()
    with torch.no_grad():
        for m in range(M):
            xytl = np.stack([X.reshape(-1), Y.reshape(-1),
                             np.full(X.size, t[m]), np.full(X.size, lam)], axis=-1)
            xytl_t = torch.tensor(xytl, dtype=torch.float32, device=device)
            out = net(xytl_t).cpu().numpy()
            su[m] = out[:,0].reshape(N, N)
            sv[m] = out[:,1].reshape(N, N)
    net.train()
    mass = (su**2 + sv**2).sum(axis=(-1,-2))
    return dict(snaps=su+1j*sv, mass=mass, t=t, x=x, y=y, lam=lam)
