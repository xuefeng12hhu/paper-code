"""
homotopy-tdgl: 神经网络辅助的同伦算法求解超导TDGL方程。

模块:
    reference_solver  - ETDRK2 DST 正弦谱参考求解器
    homotopy_nn       - 同伦退火训练的神经网络代理
    evaluation        - 定量误差指标 + 物理诊断（自由能/涡旋）
    visualize        - 可视化与对比工具
"""

from .reference_solver import (
    ETD2RK,
    initial_condition,
    initial_condition_pair,
    initial_condition_quench,
    make_initial_condition,
    solve_tdgl,
    total_mass,
    vortex_count,
    vortex_map,
)

from .homotopy_nn import (
    FourierFeatures,
    HomotopyNet,
    TrainConfig,
    train_homotopy_nn,
    evaluate_grid,
    pde_residual,
    residual_rms,
)

from .evaluation import (
    rel_l2_error,
    linf_error,
    error_table,
    free_energy,
    dissipation_residual,
    vortex_trajectory,
    net_vortex_time_series,
)

__all__ = [
    "ETD2RK",
    "initial_condition",
    "initial_condition_pair",
    "initial_condition_quench",
    "make_initial_condition",
    "solve_tdgl",
    "total_mass",
    "vortex_count",
    "vortex_map",
    "FourierFeatures",
    "HomotopyNet",
    "TrainConfig",
    "train_homotopy_nn",
    "evaluate_grid",
    "pde_residual",
    "residual_rms",
    "rel_l2_error",
    "linf_error",
    "error_table",
    "free_energy",
    "dissipation_residual",
    "vortex_trajectory",
    "net_vortex_time_series",
]

__version__ = "0.2.0"
