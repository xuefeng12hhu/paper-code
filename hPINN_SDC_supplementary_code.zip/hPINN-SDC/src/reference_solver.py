"""
reference_solver.py
==================
TDGL 方程的 ETD2RK 正弦谱（DST）参考求解器。

P0 阶段修复（见 docs/paper_gap_analysis.md）：

P0.1a 旧版用周期 FFT + 每步强行覆盖边界一圈为 1，不自洽、破坏谱精度。
      现改为：ψ = 1 + φ，φ|∂Ω = 0，对 φ 用 DST-I 正弦谱方法求解，
      Dirichlet 边界条件（ψ|∂Ω = 1）精确满足。

P0.1b 旧版 "ETD2RK" 公式实际只有一阶精度（取 L=0 退化为
      u_{n+1} = u_n + 2h·N(a)）。现改为正确的 Cox–Matthews ETDRK2：
          a      = e^{hL} u_n + h φ1(hL) N(u_n)
          u_{n+1} = e^{hL} u_n + h [φ1(hL) − φ2(hL)] N(u_n)
                                  + h φ2(hL) N(a)
      其中 φ2(z) = (φ1(z) − 1)/z。L=0 时退化为 Heun 法（二阶）。

P0.1c 同伦定义修正：旧同伦 λ=0 端为 ∂tψ = ∇²ψ + ψ，与 Dirichlet 边界
      ψ|∂Ω=1 不相容（解指数增长，T=5 时质量 ~10⁶）。现改为非线性强度
      延拓：
          ∂tψ = ∇²ψ + λ (1−|ψ|²) ψ,  λ ∈ [0,1]
      λ=0：纯热方程（适定，扰动单调衰减）；λ=1：完整 TDGL。
      两端在 Dirichlet 边界下均适定。

网格约定（重要，下游代码须一致）：
    内点网格 x_i = i·h, y_j = j·h, i,j = 1..N, h = L/(N+1)
    边界 x,y ∈ {0, L} 处 ψ ≡ 1（不在快照数组中）。
    快照包含 t=0 的初值：integrate() 返回 1 + n_steps//snapshot_every 帧，
    第 0 帧为初值。

数学推导见 docs/formulas.md 第 6 节。
"""

import torch
import numpy as np


# -------------------------------------------------------------------------
# 网格
# -------------------------------------------------------------------------
def make_grid(L: float, N: int, T: float, M: int, device: str = "cpu"):
    """生成 Dirichlet 内点网格。

    Returns
    -------
    x, y : (N,) tensor，内点坐标 x_i = i·L/(N+1), i=1..N
    t : (M,) tensor，含 t=0
    """
    h = L / (N + 1)
    x = h * torch.arange(1, N + 1, device=device)
    y = h * torch.arange(1, N + 1, device=device)
    t = torch.linspace(0.0, T, M, device=device)
    return x, y, t


def make_laplacian_eigenvalues(N: int, L: float, device: str = "cpu"):
    """Dirichlet Laplacian 在正弦基下的本征值 -(k_m² + k_n²)。

    k_m = π m / L, m = 1..N（连续谱本征值，谱精度）。
    """
    k = torch.pi * torch.arange(1, N + 1, device=device) / L
    kx = k.view(-1, 1)
    ky = k.view(1, -1)
    return -(kx ** 2 + ky ** 2)


def initial_condition(N: int, L: float, eps: float = 0.5, sigma: float = 1.2,
                      device: str = "cpu") -> torch.Tensor:
    """中心模长扰动（形成"超导抑制区"，便于涡旋成核），在内点网格上取值：

        psi0 = (1 - eps * g) + i * eps_v * g_v

    其中 g 是高斯，eps_v 较小的虚部扰动用于诱导对称破缺。

    Returns
    -------
    psi0 : (N, N) complex64 tensor，内点值（边界恒为 1，不在数组中）
    """
    h = L / (N + 1)
    x = h * torch.arange(1, N + 1, device=device)
    X, Y = torch.meshgrid(x, x, indexing="ij")
    r2 = (X - L / 2) ** 2 + (Y - L / 2) ** 2
    g = torch.exp(-r2 / (2 * sigma ** 2))
    # 主扰动：模长抑制
    u = (1.0 - eps * g).clamp(min=0.05)   # Re(psi)
    # 次扰动：小的虚部，诱导对称破缺 / 涡旋对成核
    sigma2 = sigma * 0.6
    g2 = torch.exp(-r2 / (2 * sigma2 ** 2))
    v = -0.2 * eps * g2                    # Im(psi)
    return torch.complex(u, v)


def initial_condition_pair(N: int, L: float, sep: float = 5.0, xi: float = 0.5,
                           device: str = "cpu") -> torch.Tensor:
    """涡旋-反涡旋对印迹初值（净绕数 0，测试相互吸引与湮灭动力学）：

        psi0 = Π_c tanh(|r−c|/ξ) · exp(i·charge·θ_c(r))
    """
    h = L / (N + 1)
    x = h * torch.arange(1, N + 1, device=device)
    X, Y = torch.meshgrid(x, x, indexing="ij")
    psi = torch.ones((N, N), dtype=torch.complex64, device=device)
    pts = [(L / 2 - sep / 2, L / 2, +1), (L / 2 + sep / 2, L / 2, -1)]
    for (cx, cy, ch) in pts:
        dx, dy = X - cx, Y - cy
        r = torch.sqrt(dx ** 2 + dy ** 2)
        psi = psi * torch.tanh(r / xi) * torch.exp(1j * ch * torch.atan2(dy, dx))
    return psi.to(torch.complex64)


def initial_condition_quench(N: int, L: float, ell: float = 1.5,
                             rms: float = 0.4, seed: int = 2,
                             device: str = "cpu") -> torch.Tensor:
    """淬火无序初值（Kibble-Zurek 型相有序化）：

    截断到波长 ≥ ell 的随机傅里叶模叠加，RMS 模长归一到 rms。
    TDGL 弛豫驱动 |ψ|→1 的相有序化，自发成核大量涡旋-反涡旋对
    并级联湮灭（粗化动力学）。

    P2.6 修复：随机系数的个数与取值都**与 N 无关**（固定模态集
    m,n ∈ Z², m²+n² ≤ (L/ell)²，从 rng 按固定顺序抽取），归一化用
    Parseval 精确连续 RMS。旧版 `rng.normal(size=(N,N))` 在不同 N 下
    生成**不同的随机实现**，导致 N=32 训练 IC 与 N=48 参考 IC 是两个
    独立随机场（相对差 √2≈1.41），quench 基准的 e2 被不可约的 IC
    失配地板污染（实测 e2(t=0)=1.42）。
    """
    rng = np.random.default_rng(seed)
    # 固定模态集（只依赖 L/ell，不依赖 N）
    M = int(np.floor(L / ell))
    ms = np.arange(-M, M + 1)
    MMX, MMY = np.meshgrid(ms, ms, indexing="ij")
    mask = (MMX ** 2 + MMY ** 2) <= (L / ell) ** 2
    c = (rng.normal(size=(2 * M + 1, 2 * M + 1))
         + 1j * rng.normal(size=(2 * M + 1, 2 * M + 1))) * mask
    # 连续 RMS（Parseval）：mean|f|² = Σ|c|²，与 N 无关
    c = c / np.sqrt((np.abs(c) ** 2).sum()) * rms

    # 在内点网格 x_p = p·L/(N+1) 上求值（同一连续函数）
    x = L / (N + 1) * np.arange(1, N + 1)
    phix = np.exp(2j * np.pi * np.outer(x, ms) / L)      # (N, 2M+1)
    phiy = np.exp(2j * np.pi * np.outer(x, ms) / L)      # (N, 2M+1)
    f = phix @ c @ phiy.T
    return torch.tensor(f, dtype=torch.complex64, device=device)


def make_initial_condition(kind: str, N: int, L: float,
                           device: str = "cpu", **kw) -> torch.Tensor:
    """初值分发器（NN 管线与参考求解共用，单一事实来源）。

    kind ∈ {"gaussian", "pair", "quench", "abrikosov"}
    abrikosov: 用 Abrikosov 涡旋格子印迹多个 vortex（ch=+1）+ antivortex（ch=-1）。
        在施加外磁场后，TDGL 弛豫稳定在此格子附近（与文献 Abrikosov 1957 网格定性一致）。
    """
    if kind == "gaussian":
        return initial_condition(N, L, eps=kw.get("eps", 0.5),
                                 sigma=kw.get("sigma", 1.2), device=device)
    if kind == "pair":
        return initial_condition_pair(N, L, sep=kw.get("sep", 5.0),
                                      xi=kw.get("xi", 0.5), device=device)
    if kind == "quench":
        return initial_condition_quench(N, L, ell=kw.get("ell", 1.5),
                                        rms=kw.get("rms", 0.4),
                                        seed=kw.get("seed", 2), device=device)
    if kind == "abrikosov":
        return initial_condition_abrikosov(
            N, L,
            n_v=kw.get("n_v", 4), xi=kw.get("xi", 0.7),
            spacing=kw.get("spacing", 4.0),
            orientation=kw.get("orientation", "hex"),
            device=device)
    raise ValueError(f"unknown ic kind: {kind}")


def initial_condition_abrikosov(N: int, L: float,
                                n_v: int = 4,
                                xi: float = 0.7,
                                spacing: float = 4.0,
                                orientation: str = "hex",
                                device: str = "cpu") -> torch.Tensor:
    """Abrikosov 涡旋格子印迹初值：在内点网格上放置 n_v×n_v 个涡旋。

    方位 orientation ∈ {"hex", "square"}：
        - "hex"   经典 Abrikosov 三角格子（最低能量态，Abrikosov β=1.16）
        - "square"正方格子（次稳定态，便于直观对比）

    每个涡旋的相位为 ch · θ_c(r)，其中 ch=+1 表示 +vortex。
    总拓扑荷为 n_v²（每个带 +1 荷）。
    在外加磁场下，TDGL 弛豫稳定于此格子（与 Abrikosov 1957 一致）。

    Parameters
    ----------
    N : 网格内点数
    L : 盒长
    n_v : 单方向涡旋数（总涡旋数 = n_v²）
    xi : 涡旋核尺寸（tanh 半径）
    spacing : 相邻涡旋距离
    """
    h = L / (N + 1)
    x = h * torch.arange(1, N + 1, device=device)
    X, Y = torch.meshgrid(x, x, indexing="ij")
    psi = torch.ones((N, N), dtype=torch.complex64, device=device)

    # 居中放置 n_v × n_v 格子
    cx0 = L / 2 - (n_v - 1) * spacing / 2
    cy0 = L / 2 - (n_v - 1) * spacing / 2
    if orientation == "hex":
        # 三角格子：偶数行偏移 spacing/2
        offset = 0.0
    else:
        offset = 0.0
    for i in range(n_v):
        for j in range(n_v):
            if orientation == "hex" and (j % 2 == 1):
                cx = cx0 + i * spacing + offset
            else:
                cx = cx0 + i * spacing
            cy = cy0 + j * spacing
            dx, dy = X - cx, Y - cy
            r = torch.sqrt(dx ** 2 + dy ** 2)
            # ch = +1；可手动调整为 ±1 模拟 Abrikosov 嵌套态
            psi = psi * torch.tanh(r / xi) * torch.exp(1j * torch.atan2(dy, dx))
    return psi.to(torch.complex64)


# -------------------------------------------------------------------------
# DST-I 正弦变换（基于 FFT 的奇延拓实现，torch 复数版）
# -------------------------------------------------------------------------
def _dst1(x: torch.Tensor, dim: int) -> torch.Tensor:
    """沿 dim 做 I 型离散正弦变换（未归一化）：

        X_m = Σ_{i=1}^{N} x_i sin(π m i / (N+1)),  m = 1..N

    通过长度 2(N+1) 的奇延拓 FFT 实现：Y_m = -2i·X_m。
    """
    N = x.shape[dim]
    M = 2 * (N + 1)
    shape = list(x.shape)
    shape[dim] = M
    ext = torch.zeros(shape, dtype=x.dtype, device=x.device)
    sl = [slice(None)] * x.ndim
    sl[dim] = slice(1, N + 1)
    ext[tuple(sl)] = x
    sl[dim] = slice(N + 2, M)
    ext[tuple(sl)] = -torch.flip(x, dims=[dim])
    F = torch.fft.fft(ext, dim=dim)
    sl[dim] = slice(1, N + 1)
    return 0.5j * F[tuple(sl)]


def _idst1(X: torch.Tensor, dim: int) -> torch.Tensor:
    """_dst1 的精确逆变换（利用谱的奇反对称性 Y_{M-m} = -Y_m）。"""
    N = X.shape[dim]
    M = 2 * (N + 1)
    shape = list(X.shape)
    shape[dim] = M
    Y = torch.zeros(shape, dtype=X.dtype, device=X.device)
    sl = [slice(None)] * X.ndim
    sl[dim] = slice(1, N + 1)
    Y[tuple(sl)] = -2j * X
    sl[dim] = slice(N + 2, M)
    Y[tuple(sl)] = 2j * torch.flip(X, dims=[dim])
    x = torch.fft.ifft(Y, dim=dim)
    sl[dim] = slice(1, N + 1)
    return x[tuple(sl)]


def dst2(x: torch.Tensor) -> torch.Tensor:
    """二维 DST-I（两个维度各做一次一维 DST-I）。"""
    return _dst1(_dst1(x, dim=-1), dim=-2)


def idst2(X: torch.Tensor) -> torch.Tensor:
    """二维 DST-I 的逆变换。"""
    return _idst1(_idst1(X, dim=-1), dim=-2)


# -------------------------------------------------------------------------
# 矢量势 A（阶段 3：完整 GL 含磁场）
# -------------------------------------------------------------------------
def A_symmetric(x: torch.Tensor, y: torch.Tensor, B: float):
    """对称规范 A = (-By/2, Bx/2)，库仑规范 ∇·A = 0。

    Parameters
    ----------
    x, y : (...,) tensor，空间坐标
    B : 标量，垂直于 (x,y) 平面的磁场强度（单位制由问题决定；
        自然单位下，磁通量量子 Φ₀ = 2π，故 B 数值即无量纲通量密度）

    Returns
    -------
    Ax, Ay : 同形状 tensor
    """
    return -0.5 * B * y, 0.5 * B * x


def A_landau_y(x: torch.Tensor, y: torch.Tensor, B: float):
    """Landau 规范 A = (0, Bx)，∇·A = 0。"""
    zeros = torch.zeros_like(x)
    return zeros, B * x


# -------------------------------------------------------------------------
# ETD2RK 步进
# -------------------------------------------------------------------------
class ETD2RK:
    """单参数 lambda 下的 ETDRK2 正弦谱求解器。

    同伦 PDE（P0.1c 修正后）：
        ∂t ψ = (-i∇-A)²ψ + λ (1−|ψ|²) ψ,   ψ|∂Ω = 1
    当 B=0 时退化为 ∇²ψ 的标准 TDGL（P0.1c）。

    分解为
        ∂t φ = L φ + N(φ),  ψ = 1 + φ
        L φ  = ∇²φ                          （DST 对角）
        N(φ) = [λ (1-|ψ|²) ψ]
              + [|A|² ψ]                    （位置依赖系数）
              + [2 i (A·∇) ψ]              （含 ∇ψ 的 FD 近似）
    其中 A 由 gauge 参数给出；B=0 时全部 A 项消失，行为与原版一致。
    """

    def __init__(self, lam: float, L_box: float, N: int,
                 device: str = "cpu", dtype=torch.complex64,
                 B_field: float = 0.0, gauge: str = "symmetric"):
        self.lam = float(lam)
        self.N = N
        self.L_box = float(L_box)
        self.device = device
        self.dtype = dtype
        self.B_field = float(B_field)
        self.gauge = gauge

        self.L_hat = make_laplacian_eigenvalues(N, self.L_box, device).to(dtype)
        # 预计算网格坐标与 A 场（B≠0 时使用）
        h = self.L_box / (N + 1)
        xg = h * torch.arange(1, N + 1, device=device)
        Xg, Yg = torch.meshgrid(xg, xg, indexing="ij")
        self._x = Xg.to(dtype)
        self._y = Yg.to(dtype)
        if self.B_field != 0.0:
            Ax, Ay = self._build_A_field(Xg, Yg)
            self._Ax = Ax.to(dtype)
            self._Ay = Ay.to(dtype)
            self._A_sq = (Ax ** 2 + Ay ** 2).to(dtype)
        else:
            self._Ax = None
            self._Ay = None
            self._A_sq = None

    def _build_A_field(self, Xg: torch.Tensor, Yg: torch.Tensor):
        """按 gauge 选择 A 的表达式。"""
        if self.gauge == "symmetric":
            return A_symmetric(Xg, Yg, self.B_field)
        if self.gauge == "landau_y":
            return A_landau_y(Xg, Yg, self.B_field)
        raise ValueError(f"unknown gauge: {self.gauge}")

    def _nonlinear(self, phi: torch.Tensor) -> torch.Tensor:
        """N(φ) = λ(1−|ψ|²)ψ − |A|² ψ − 2 i (A·∇)ψ，ψ = 1+φ。"""
        psi = 1.0 + phi
        # ---- GL 非线性 ----
        out = self.lam * (1.0 - psi.abs() ** 2) * psi
        if self.B_field == 0.0:
            return out
        # ---- −|A|² ψ（位置依赖实系数）----
        out = out - self._A_sq * psi
        # ---- −2 i (A·∇) ψ（中心差分；边界单边）----
        h = self.L_box / (self.N + 1)
        psi_x = (torch.roll(psi, -1, dims=0) - torch.roll(psi, 1, dims=0)) / (2 * h)
        psi_y = (torch.roll(psi, -1, dims=1) - torch.roll(psi, 1, dims=1)) / (2 * h)
        psi_x[0, :] = (psi[1, :] - psi[0, :]) / h
        psi_x[-1, :] = (psi[-1, :] - psi[-2, :]) / h
        psi_y[:, 0] = (psi[:, 1] - psi[:, 0]) / h
        psi_y[:, -1] = (psi[:, -1] - psi[:, -2]) / h
        out = out - 2j * (self._Ax * psi_x + self._Ay * psi_y)
        return out

    def _phi1(self, z: torch.Tensor) -> torch.Tensor:
        """φ1(z) = (e^z − 1)/z，小 |z| 取泰勒级数。"""
        out = torch.zeros_like(z)
        mask = z.abs() > 1e-6
        zm = z[~mask]
        out[~mask] = 1.0 + zm / 2 + zm ** 2 / 6 + zm ** 3 / 24
        zm = z[mask]
        out[mask] = (torch.exp(zm) - 1.0) / zm
        return out

    def _phi2(self, z: torch.Tensor) -> torch.Tensor:
        """φ2(z) = (φ1(z) − 1)/z = (e^z − 1 − z)/z²，小 |z| 取泰勒级数。"""
        out = torch.zeros_like(z)
        mask = z.abs() > 1e-6
        zm = z[~mask]
        out[~mask] = 1.0 / 2 + zm / 6 + zm ** 2 / 24
        zm = z[mask]
        out[mask] = ((torch.exp(zm) - 1.0 - zm) / zm) / zm
        return out

    def step(self, psi: torch.Tensor, dt: float) -> torch.Tensor:
        """单步 ETDRK2（Cox–Matthews，二阶）。psi 为内点 ψ 值 (N, N)。

        B=0 时 DST 基底精确保持 Dirichlet ψ=1 at boundary；
        B≠0 时 −|A|² ψ 与 −2i(A·∇)ψ 项在边界附近抑制凝聚体
        （|A|² 随 r² 增长，物理上对应磁场对超导序参量的压制），
        自然演化使 ψ 偏离 1（真实物理：完整 GL 的平衡态不再是
        ψ=1，而是 Abrikosov 格子态，其 |ψ| 取决于 B 与几何）。
        我们保持 DST 边界表示不变（即假设 ψ→1 在远场），由
        动力学内部自洽达到 Abrikosov 解；该近似在 B≪1 时有效
        （B 大时边界与体相干涉显著，需改用 ψ=0 物理 BC 或周期
        BC）。修正符号后 max|ψ| ≤ 1，与 GL 平衡态一致。
        """
        phi = psi.to(self.dtype) - 1.0

        phi_hat = dst2(phi)
        Nn_hat = dst2(self._nonlinear(phi))

        eL = torch.exp(dt * self.L_hat)
        p1 = self._phi1(dt * self.L_hat)
        p2 = self._phi2(dt * self.L_hat)

        # 预估步 a = e^{hL}φ + h φ1 N(φ)   （ETD1，局部 O(h²)）
        a_hat = eL * phi_hat + dt * p1 * Nn_hat
        phi_a = idst2(a_hat)

        # 校正步 u = e^{hL}φ + h(φ1−φ2)N(φ) + h φ2 N(a)   （二阶）
        Na_hat = dst2(self._nonlinear(phi_a))
        b_hat = (eL * phi_hat + dt * (p1 - p2) * Nn_hat
                 + dt * p2 * Na_hat)
        return 1.0 + idst2(b_hat)

    def integrate(self, psi0: torch.Tensor, dt: float, n_steps: int,
                  snapshot_every: int = 1):
        """时间积分。返回快照 (S, N, N)，S = 1 + n_steps//snapshot_every，
        第 0 帧为初值 t=0（Dirichlet 边界自然满足，无需人工强制）。"""
        psi = psi0.to(self.dtype).clone()
        snaps = [psi.clone()]
        for n in range(n_steps):
            psi = self.step(psi, dt)
            if (n + 1) % snapshot_every == 0:
                snaps.append(psi.clone())
        return torch.stack(snaps)


# -------------------------------------------------------------------------
# 便捷接口
# -------------------------------------------------------------------------
def solve_tdgl(lam: float, L: float, N: int, T: float, M: int,
               eps: float = 0.3, sigma: float = 0.8,
               ic_kind: str = "gaussian",
               device: str = "cpu", seed: int = 0,
               B_field: float = 0.0, gauge: str = "symmetric",
               **ic_kw) -> torch.Tensor:
    """求解给定 lambda 下的同伦 PDE，返回 M 个时间快照（含 t=0）。

    阶段 3 扩展：
      ic_kind ∈ {"gaussian", "pair", "quench", "abrikosov"}
      B_field > 0 时启用含矢量势 A 的完整 GL（默认对称规范）

    Returns
    -------
    snaps : (M, N, N) complex64 tensor，snaps[m] 对应 t = m·T/(M-1)
    """
    torch.manual_seed(seed)
    if ic_kind == "gaussian":
        psi0 = initial_condition(N, L, eps=eps, sigma=sigma, device=device)
    else:
        psi0 = make_initial_condition(ic_kind, N, L, device=device, **ic_kw)
    dt = T / (M - 1)
    solver = ETD2RK(lam=lam, L_box=L, N=N, device=device,
                    B_field=B_field, gauge=gauge)
    return solver.integrate(psi0, dt=dt, n_steps=M - 1, snapshot_every=1)


def total_mass(snaps: torch.Tensor) -> torch.Tensor:
    """内点上 |psi|^2 的求和（未乘 h²，作相对比较用）。"""
    return (snaps.abs() ** 2).sum(dim=(-1, -2))


def vortex_map(snaps: torch.Tensor) -> torch.Tensor:
    """逐格点（plaquette）绕数。

    对每个格点单元沿四条边累积回绕相位增量（wrap 到 (-π, π]），
    环量/(2π) 即绕数，天然有界（替代旧版全场旋度求和的发散积分）。
    边界一圈 ψ≡1（相位 0），对内点场 padding 一圈后计算。

    Parameters
    ----------
    snaps : (..., N, N) complex tensor，内点 ψ 值

    Returns
    -------
    w : (..., N+1, N+1) tensor，每个格点单元的绕数（整数附近取值）
    """
    x = snaps
    single = (x.dim() == 2)
    if single:
        x = x.unsqueeze(0)
    Mbatch, N, _ = x.shape
    psi = torch.ones((Mbatch, N + 2, N + 2), dtype=x.dtype, device=x.device)
    psi[:, 1:N + 1, 1:N + 1] = x

    ph = torch.angle(psi)
    a = ph[:, :-1, :-1]   # 每个单元的左下角
    b = ph[:, :-1, 1:]    # 右下角
    c = ph[:, 1:, 1:]     # 右上角
    d = ph[:, 1:, :-1]    # 左上角

    def wrap(dd: torch.Tensor) -> torch.Tensor:
        return (dd + np.pi) % (2 * np.pi) - np.pi

    w = (wrap(b - a) + wrap(c - b) + wrap(d - c) + wrap(a - d)) / (2 * np.pi)
    return w[0] if single else w


def vortex_count(snaps: torch.Tensor) -> torch.Tensor:
    """净涡旋数 = 所有格点绕数之和（拓扑荷守恒时应为常数）。

    Returns
    -------
    net : (...) tensor
    """
    w = vortex_map(snaps)
    return w.sum(dim=(-1, -2))


# -------------------------------------------------------------------------
# 自检
# -------------------------------------------------------------------------
if __name__ == "__main__":
    torch.manual_seed(0)

    # --- DST 往返与正弦本征检验 ---
    N, L = 32, 10.0
    x = torch.randn(N, N, dtype=torch.complex64)
    err_rt = (idst2(dst2(x)) - x).abs().max().item()
    print(f"[dst] roundtrip max err: {err_rt:.2e}")

    h = L / (N + 1)
    xi = h * torch.arange(1, N + 1)
    X, Y = torch.meshgrid(xi, xi, indexing="ij")
    m_test, n_test = 5, 3
    sin_mode = (torch.sin(torch.pi * m_test * X / L)
                * torch.sin(torch.pi * n_test * Y / L)).to(torch.complex64)
    coef = dst2(sin_mode).abs()
    peak_idx = coef.argmax().item()
    print(f"[dst] sine mode ({m_test},{n_test}): peak at "
          f"{divmod(peak_idx, N)} (expect {m_test-1},{n_test-1}), "
          f"max/sum = {coef.max().item()/coef.sum().item():.4f}")

    # --- 涡旋绕数检验：中心涡旋 + 反涡旋对 ---
    def vortex_pair_field(N, L, pts, xi_core=0.5):
        """在 pts 处放置涡旋(带号)的合成场（内点网格）。"""
        h = L / (N + 1)
        xg = h * torch.arange(1, N + 1)
        Xg, Yg = torch.meshgrid(xg, xg, indexing="ij")
        psi = torch.ones((N, N), dtype=torch.complex64)
        for (cx, cy, charge) in pts:
            dx, dy = Xg - cx, Yg - cy
            r = torch.sqrt(dx ** 2 + dy ** 2)
            theta = charge * torch.atan2(dy, dx)
            psi = psi * torch.tanh(r / xi_core) * torch.exp(1j * theta)
        return psi

    field1 = vortex_pair_field(N, L, [(L / 2, L / 2, +1)])
    w1 = vortex_map(field1)
    print(f"[vortex] single vortex: net={w1.sum().item():+.3f} "
          f"(net 0: 边界 ψ≡1 拓扑要求), "
          f"max |w| cell = {w1.abs().max().item():.3f} (expect ~1)")

    field2 = vortex_pair_field(N, L, [(3.0, 3.0, +1), (7.0, 7.0, -1)])
    w2 = vortex_map(field2)
    n_cells = (w2.abs() > 0.5).sum().item()
    print(f"[vortex] vortex-antivortex pair: net={w2.sum().item():+.3f} "
          f"(expect 0), |w|>0.5 cells={n_cells} (expect 2)")

    # --- λ=0 纯热方程：扰动单调衰减，质量 → N² ---
    N, L, T, M = 32, 10.0, 5.0, 50
    snaps_lin = solve_tdgl(lam=0.0, L=L, N=N, T=T, M=M, eps=0.8, sigma=1.5)
    m_lin = total_mass(snaps_lin)
    mono = bool(torch.all(m_lin[1:] - m_lin[:-1] > -1e-3))
    print(f"[lam=0] mass: {m_lin[0].item():.1f} -> {m_lin[-1].item():.1f} "
          f"(tends to N^2={N*N}), monotone increase: {mono}")

    # --- 完整 TDGL λ=1 ---
    snaps_tdgl = solve_tdgl(lam=1.0, L=L, N=N, T=T, M=M, eps=0.8, sigma=1.5)
    m_tdgl = total_mass(snaps_tdgl)
    print(f"[lam=1] mass: {m_tdgl[0].item():.1f} -> {m_tdgl[-1].item():.1f}")
    print(f"[lam=1] net vortex number: "
          f"{vortex_count(snaps_tdgl[-1]).item():.3f}")

    # --- 时间收敛检验：dt 减半，误差应 ~4x 下降（ETDRK2 二阶） ---
    solver = ETD2RK(lam=1.0, L_box=L, N=N)
    psi0 = initial_condition(N, L, eps=0.8, sigma=1.5)
    fine = solver.integrate(psi0, dt=T / 4096, n_steps=4096,
                            snapshot_every=4096)
    errs = []
    for n_steps in (32, 64, 128):
        coarse = solver.integrate(psi0, dt=T / n_steps, n_steps=n_steps,
                                  snapshot_every=n_steps)
        errs.append((coarse[-1] - fine[-1]).abs().max().item())
    print(f"[conv] dt halving errors: {errs[0]:.2e} -> {errs[1]:.2e} -> "
          f"{errs[2]:.2e}, ratios: {errs[0]/errs[1]:.2f}, "
          f"{errs[1]/errs[2]:.2f} (expect ~4)")

    # --- 空间谱收敛检验：网格加密，高模态尾部能量应骤降 ---
    for N_s in (16, 32, 64):
        psi0_s = initial_condition(N_s, L, eps=0.8, sigma=1.5)
        sol_s = ETD2RK(lam=1.0, L_box=L, N=N_s)
        sn = sol_s.integrate(psi0_s, dt=T / 2000, n_steps=2000,
                             snapshot_every=2000)
        # 谱收敛通过截断系数能量检验：
        coef_e = dst2(sn[-1] - 1.0).abs()
        tail = coef_e[-4:, :].sum().item() + coef_e[:, -4:].sum().item()
        total = coef_e.sum().item()
        print(f"[spec] N={N_s}: high-mode tail energy fraction = "
              f"{tail/max(total,1e-12):.2e}")
    print("[ok] reference solver self-test passed.")
