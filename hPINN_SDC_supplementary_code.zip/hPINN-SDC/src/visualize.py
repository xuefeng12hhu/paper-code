"""
visualize.py
============
可视化工具：
1. 对比神经网络解 vs 参考解在不同 λ 下的 |ψ| 场
2. 画同伦路径上的自由能 / 序参量总质量演化
3. 涡旋位置（相位彩色图 + 密度等高线）
"""

from __future__ import annotations
from typing import Optional, List, Dict

import numpy as np
import matplotlib
matplotlib.use("Agg")                                # 无显示
import matplotlib.pyplot as plt
from matplotlib.colors import hsv_to_rgb


# -------------------------------------------------------------------------
# 1. 字段对比
# -------------------------------------------------------------------------
def plot_field_comparison(nn_snaps: np.ndarray, ref_snaps: np.ndarray,
                           lam: float, L: float, T: float = 1.0,
                           out_path: str = "out.png", title_prefix: str = "",
                           n_show: int = 5):
    """画 |ψ| 场对比：神经网络 vs 参考解。

    Parameters
    ----------
    nn_snaps, ref_snaps : (T, N, N) complex arrays
    lam : 同伦参数
    L, T : 物理空间长度与时间窗口
    n_show : 显示几个时刻
    """
    n_t = min(n_show, nn_snaps.shape[0], ref_snaps.shape[0])
    fig, axes = plt.subplots(2, n_t, figsize=(3.0 * n_t, 6.5))
    if n_t == 1:
        axes = axes.reshape(2, 1)

    extent = [0, L, 0, L]
    indices = np.linspace(0, n_t - 1, n_t, dtype=int)
    for j, k in enumerate(indices):
        ti = min(k, nn_snaps.shape[0] - 1)
        ti_r = min(k, ref_snaps.shape[0] - 1)
        t_label = k / max(n_t - 1, 1) * T

        ax = axes[0, j]
        im = ax.imshow(np.abs(nn_snaps[ti]), extent=extent, origin="lower",
                        cmap="viridis", vmin=0, vmax=1.05)
        ax.set_title(f"NN  t≈{t_label:.2f}")
        ax.set_xticks([]); ax.set_yticks([])
        plt.colorbar(im, ax=ax, fraction=0.046)

        ax = axes[1, j]
        im = ax.imshow(np.abs(ref_snaps[ti_r]), extent=extent, origin="lower",
                        cmap="viridis", vmin=0, vmax=1.05)
        ax.set_title(f"REF t≈{t_label:.2f}")
        ax.set_xticks([]); ax.set_yticks([])
        plt.colorbar(im, ax=ax, fraction=0.046)

    fig.suptitle(f"{title_prefix} λ={lam:.2f}  | NN vs ETD2RK reference",
                 fontsize=14)
    fig.tight_layout()
    fig.savefig(out_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


# -------------------------------------------------------------------------
# 2. 同伦路径上的诊断量
# -------------------------------------------------------------------------
def plot_homotopy_path_diagnostics(history: List[Dict],
                                    out_path: str):
    """同伦退火训练过程中每阶段的诊断量。"""
    lams = [h["lam"] for h in history]
    res = [h["residual"] for h in history]
    lpde = [h["L_pde"] for h in history]
    lic = [h["L_ic"] for h in history]
    lbc = [h["L_bc"] for h in history]

    fig, axes = plt.subplots(1, 3, figsize=(13, 4))

    axes[0].semilogy(lams, res, "o-", color="C0")
    axes[0].set_xlabel("λ"); axes[0].set_ylabel("PDE residual RMS")
    axes[0].set_title("Residual per stage"); axes[0].grid(True, alpha=0.3)

    axes[1].semilogy(lams, lpde, "o-", color="C1", label="L_PDE")
    axes[1].semilogy(lams, lic, "s-", color="C2", label="L_IC")
    axes[1].semilogy(lams, lbc, "^-", color="C3", label="L_BC")
    axes[1].set_xlabel("λ"); axes[1].set_ylabel("loss")
    axes[1].set_title("Loss decomposition"); axes[1].grid(True, alpha=0.3)
    axes[1].legend()

    axes[2].plot(range(len(lams)), lams, "o-", color="C0")
    axes[2].set_xlabel("stage k"); axes[2].set_ylabel("λ")
    axes[2].set_title("Homotopy schedule"); axes[2].grid(True, alpha=0.3)

    fig.suptitle("Homotopy Annealing Diagnostics", fontsize=14)
    fig.tight_layout()
    fig.savefig(out_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


# -------------------------------------------------------------------------
# 3. 时间演化诊断：mass / vortex number
# -------------------------------------------------------------------------
def plot_time_diagnostics(nn_mass: np.ndarray, ref_mass: np.ndarray,
                           t_nn: np.ndarray, t_ref: np.ndarray, lam: float,
                           out_path: str):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(t_nn, nn_mass, "o-", label="NN", color="C0")
    axes[0].plot(t_ref, ref_mass, "x--", label="ETD ref", color="C3")
    axes[0].set_xlabel("t"); axes[0].set_ylabel(r"$\int |\psi|^2 \,dxdy$")
    axes[0].set_title(f"Order parameter mass  (λ={lam:.2f})")
    axes[0].grid(True, alpha=0.3); axes[0].legend()

    # 误差：在共同的时间轴上插值
    t_common = np.linspace(0, max(t_nn[-1], t_ref[-1]),
                            max(len(nn_mass), len(ref_mass)))
    nn_interp = np.interp(t_common, t_nn, nn_mass)
    ref_interp = np.interp(t_common, t_ref, ref_mass)
    axes[1].plot(t_common, np.abs(nn_interp - ref_interp), "o-", color="C1")
    axes[1].set_xlabel("t"); axes[1].set_ylabel(r"|Δmass|")
    axes[1].set_title("Absolute error (interpolated)")
    axes[1].grid(True, alpha=0.3)

    fig.tight_layout()
    fig.savefig(out_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


# -------------------------------------------------------------------------
# 4. 相位 + 密度：涡旋可视化
# -------------------------------------------------------------------------
def phase_to_rgb(psi: np.ndarray) -> np.ndarray:
    """复场 → RGB：hue=phase, value=|psi|。"""
    phase = np.angle(psi) / (2 * np.pi) + 0.5
    val = np.clip(np.abs(psi), 0, 1)
    hsv = np.stack([phase, np.ones_like(phase), val], axis=-1)
    return hsv_to_rgb(hsv)


def plot_phase_density(psi_snap: np.ndarray, t_val: float, L: float,
                        out_path: str):
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))

    rgb = phase_to_rgb(psi_snap)
    axes[0].imshow(rgb, extent=[0, L, 0, L], origin="lower")
    axes[0].set_title(f"Phase (hue) + |ψ| (value)  t={t_val:.2f}")
    axes[0].set_xticks([]); axes[0].set_yticks([])

    axes[1].imshow(np.abs(psi_snap) ** 2, extent=[0, L, 0, L], origin="lower",
                    cmap="magma", vmin=0, vmax=1.0)
    axes[1].set_title(r"|ψ|²")
    axes[1].set_xticks([]); axes[1].set_yticks([])

    fig.tight_layout()
    fig.savefig(out_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


# -------------------------------------------------------------------------
# 5. 多 λ 快照拼图
# -------------------------------------------------------------------------
def plot_lambda_panel(snaps_by_lam: Dict[float, np.ndarray],
                       L: float, out_path: str):
    """画不同 λ 下的最终时刻 |ψ| 场并排对比。"""
    lams_sorted = sorted(snaps_by_lam.keys())
    n = len(lams_sorted)
    fig, axes = plt.subplots(1, n, figsize=(3.0 * n, 3.5))
    if n == 1:
        axes = [axes]
    for ax, lam in zip(axes, lams_sorted):
        ax.imshow(np.abs(snaps_by_lam[lam]), extent=[0, L, 0, L],
                   origin="lower", cmap="viridis", vmin=0, vmax=1.05)
        ax.set_title(f"λ={lam:.2f}")
        ax.set_xticks([]); ax.set_yticks([])
    fig.suptitle("|ψ| at final time across homotopy path", fontsize=14)
    fig.tight_layout()
    fig.savefig(out_path, dpi=120, bbox_inches="tight")
    plt.close(fig)