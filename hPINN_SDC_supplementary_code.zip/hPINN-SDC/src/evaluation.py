"""
evaluation.py
=============
定量评估框架（阶段 1）：
1. 误差指标：网络解 vs ETDRK2 参考解的相对 L2 / L∞ 误差（随 t、随 λ）；
2. 物理诊断：GL 自由能 F_λ(t) 及能量耗散律 dF/dt = -2∫|∂tψ|² ≤ 0；
3. 涡旋诊断：净涡旋数随时间演化、涡旋位置轨迹。

自由能定义（与同伦 PDE 配套，见 docs/formulas.md 第 7 节）：

    F_λ[ψ] = ∫_Ω [ ½|∇ψ|² + (λ/4)(1−|ψ|²)² ] dx dy

同伦 PDE ∂tψ = ∇²ψ + λ(1−|ψ|²)ψ 是 F_λ 的 L² 梯度流：

    dF/dt = −2 ∫ |∂tψ|² dx dy ≤ 0

（用 Wirtinger 导数验证：δF/δψ̄ = −½∇²ψ − (λ/2)(1−|ψ|²)ψ，
故 ∂tψ = −2 δF/δψ̄。）

网格约定与 reference_solver 一致：快照为 Dirichlet 内点值 (N, N)，
边界一圈 ψ ≡ 1（padding 后参与差分）。
"""

import torch
import numpy as np


# -------------------------------------------------------------------------
# 误差指标
# -------------------------------------------------------------------------
def rel_l2_error(pred: torch.Tensor, ref: torch.Tensor,
                 dim=(-1, -2)) -> torch.Tensor:
    """相对 L2 误差 ‖pred−ref‖₂ / ‖ref‖₂，逐帧（或按 dim 聚合）。

    Parameters
    ----------
    pred, ref : (..., N, N) complex tensor，同一网格同一时刻的场
    """
    num = (pred - ref).abs() ** 2
    den = ref.abs() ** 2
    return torch.sqrt(num.sum(dim=dim) / den.sum(dim=dim).clamp_min(1e-30))


def linf_error(pred: torch.Tensor, ref: torch.Tensor) -> torch.Tensor:
    """逐帧 L∞ 误差 max|pred−ref|。"""
    return (pred - ref).abs().amax(dim=(-1, -2))


def error_table(pred: torch.Tensor, ref: torch.Tensor,
                t: torch.Tensor) -> list:
    """生成逐帧误差表 [{t, rel_l2, linf}, ...]。"""
    e2 = rel_l2_error(pred, ref)
    ei = linf_error(pred, ref)
    return [dict(t=float(tv), rel_l2=float(a), linf=float(b))
            for tv, a, b in zip(t, e2, ei)]


# -------------------------------------------------------------------------
# GL 自由能与耗散律
# -------------------------------------------------------------------------
def free_energy(snaps: torch.Tensor, L: float, lam: float = 1.0,
                B_field: float = 0.0, gauge: str = "symmetric") -> torch.Tensor:
    """逐帧 GL 自由能。

    B = 0：
        F_λ[ψ] = ∫[½|∇ψ|² + (λ/4)(1−|ψ|²)²] dxdy
    B ≠ 0（含矢量势的完整 GL）：
        F_λ[ψ] = ∫[ |(∇ − iA)ψ|² + (λ/4)(1−|ψ|²)² ] dxdy
    展开为 |∇ψ|² + |A|²|ψ|² − 2A·Re(iψ∇ψ̄)。

    边界 ψ≡1（padding 一圈后中心差分），梯度、A 项和势能项都在
    (N+2)×(N+2) padded 网格上求和，权重 h²。
    快照含 t=0 初值帧（与 reference_solver 约定一致）。

    符号约定与 ``ETD2RK._nonlinear`` 一致（P1 修复后两者均为
    物理约定 (∇−iA)²），因此 F 是该离散动力学的 Lyapunov 函数。

    Parameters
    ----------
    B_field : 磁场强度（0 时退化为 P0 阶段的无场公式，逐位相同）
    gauge   : "symmetric" 或 "landau_y"，与 ETD2RK 一致

    Returns
    -------
    F : (M,) tensor，各帧自由能
    """
    from src.reference_solver import A_symmetric, A_landau_y

    single = (snaps.dim() == 2)
    x = snaps.unsqueeze(0) if single else snaps
    M, N, _ = x.shape
    h = L / (N + 1)

    psi = torch.ones((M, N + 2, N + 2), dtype=x.dtype, device=x.device)
    psi[:, 1:N + 1, 1:N + 1] = x

    # 中心差分梯度（padded 网格上）
    dpsidx = (psi[:, 1:-1, 2:] - psi[:, 1:-1, :-2]) / (2 * h)
    dpsidy = (psi[:, 2:, 1:-1] - psi[:, :-2, 1:-1]) / (2 * h)
    grad2 = dpsidx.abs() ** 2 + dpsidy.abs() ** 2

    if B_field != 0.0:
        # A 取在内点网格上（grad2 / psi_in 均为内点量）
        xi = h * torch.arange(1, N + 1, dtype=torch.float64)
        Xi, Yi = torch.meshgrid(xi, xi, indexing="ij")
        A_fn = A_symmetric if gauge == "symmetric" else A_landau_y
        Ax, Ay = A_fn(Xi, Yi, B_field)
        Ax = Ax.to(x.device).to(dtype=x.real.dtype)
        Ay = Ay.to(x.device).to(dtype=x.real.dtype)
        A2 = (Ax ** 2 + Ay ** 2).unsqueeze(0)                 # (1,N,N)
        psi_in = psi[:, 1:-1, 1:-1]
        # −2 A·Re(i ψ ∇ψ̄) 的逐点形式
        cross = 2.0 * (Ax.unsqueeze(0) * (1j * psi_in * dpsidx.conj()).real
                       + Ay.unsqueeze(0) * (1j * psi_in * dpsidy.conj()).real)
        grad2 = grad2 + A2 * psi_in.abs() ** 2 - cross

    # 势能项在完整 padded 网格（边界 ψ=1 贡献为 0，但计入以求和一致）
    pot = (1.0 - psi.abs() ** 2) ** 2

    F = (0.5 * grad2.sum(dim=(-1, -2)) * h ** 2
         + (lam / 4.0) * pot.sum(dim=(-1, -2)) * h ** 2)
    return F[0] if single else F


def dissipation_residual(snaps: torch.Tensor, L: float, lam: float = 1.0):
    """耗散律自洽残差：r_m = (F_{m+1}−F_m) + dt·2∫|ψ_t|² 应 ≈ 0 且
    F 单调不增。dt 从快照数无法推断，返回逐帧 F 供调用方分析，并
    检验单调性。

    Returns
    -------
    F : (M,) tensor
    monotone : bool，F(t) 是否单调不增（容差 1e-6·|F|max）
    """
    F = free_energy(snaps, L, lam)
    tol = 1e-6 * F.abs().max().item()
    monotone = bool(torch.all(F[1:] - F[:-1] <= tol))
    return F, monotone


# -------------------------------------------------------------------------
# 涡旋诊断
# -------------------------------------------------------------------------
def vortex_trajectory(snaps: torch.Tensor, thresh: float = 0.5):
    """逐帧提取涡旋位置（|w|>thresh 的格点及其符号）。

    Returns
    -------
    frames : list of (n_v, 3) ndarray，每行 [x_idx, y_idx, winding]
    """
    from src.reference_solver import vortex_map
    w = vortex_map(snaps)                    # (M, N+1, N+1)
    if w.dim() == 2:
        w = w.unsqueeze(0)
    frames = []
    for m in range(w.shape[0]):
        idx = (w[m].abs() > thresh).nonzero(as_tuple=False)
        if idx.numel():
            wr = w[m][idx[:, 0], idx[:, 1]].real.unsqueeze(1)
            frames.append(torch.cat([idx.float(), wr], dim=1).cpu().numpy())
        else:
            frames.append(np.zeros((0, 3)))
    return frames


def net_vortex_time_series(snaps: torch.Tensor) -> torch.Tensor:
    """净涡旋数 N(t) = Σ w_cell（拓扑荷守恒时应为常数）。"""
    from src.reference_solver import vortex_count
    return vortex_count(snaps)


# -------------------------------------------------------------------------
# 自检
# -------------------------------------------------------------------------
if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from src.reference_solver import solve_tdgl, initial_condition, ETD2RK

    torch.manual_seed(0)
    L, N, T, M = 10.0, 48, 5.0, 100

    # 误差指标自洽性：pred=ref → 0；扰动 → 已知值
    ref = solve_tdgl(1.0, L, N, T, M, eps=0.8, sigma=1.5)
    e0 = rel_l2_error(ref, ref)
    print(f"[err] self vs self: {e0.max().item():.2e} (expect 0)")
    pred = ref + 0.01
    e1 = rel_l2_error(pred[0], ref[0])
    manual = 0.01 * (N * N) ** 0.5 / ref[0].abs().pow(2).sum().sqrt()
    print(f"[err] uniform shift: {e1.item():.4e} vs manual {manual.item():.4e}")

    # 自由能：均匀态 ψ≡1 → F=0（边界一致，梯度为 0）
    ones = torch.ones(1, N, N, dtype=torch.complex64)
    F0 = free_energy(ones, L, lam=1.0)
    print(f"[energy] uniform state F = {F0.item():.2e} (expect ~0)")

    # 耗散律：λ=1 完整 TDGL，F(t) 应单调不增
    for lam in (0.0, 0.5, 1.0):
        snaps = solve_tdgl(lam, L, N, T, M, eps=0.8, sigma=1.5)
        F, mono = dissipation_residual(snaps, L, lam)
        print(f"[energy] lam={lam}: F(0)={F[0].item():.3f} -> "
              f"F(T)={F[-1].item():.3f}, monotone decay: {mono}")

    # 涡旋时间序列：应恒为 0（无成核参数）
    nv = net_vortex_time_series(ref)
    print(f"[vortex] net winding range: [{nv.min().item():+.3f}, "
          f"{nv.max().item():+.3f}] (expect 0)")
    print("[ok] evaluation self-test passed.")
