# 阶段 2 消融汇总（多种子，从全部 JSON 重建）

| 算例 | 变体 | rel-L2 均值 | 种子间 std | rel-L2 末帧 | 种子数 |
|---|---|---|---|---|---|
| heal | full | 0.200 | 0.010 | 0.263 | 5 |
| heal | no_homotopy | 0.492 | 0.025 | 0.477 | 5 |
| heal | no_correct | 0.328 | 0.025 | 0.410 | 5 |
| heal | no_ff | 0.179 | 0.026 | 0.208 | 5 |
| heal | vanilla | 0.686 | 0.145 | 0.860 | 5 |
| pair | full | 0.408 | 0.187 | 0.433 | 2 |
| pair | no_homotopy | 0.567 | 0.072 | 0.548 | 2 |
| pair | no_correct | 0.361 | 0.039 | 0.387 | 2 |
| pair | no_ff | 0.253 | 0.016 | 0.252 | 2 |
| pair | vanilla | 1.472 | 0.213 | 2.209 | 2 |
| quench | full | 0.478 | 0.026 | 0.306 | 2 |
| quench | no_homotopy | 0.938 | 0.035 | 0.662 | 2 |
| quench | no_correct | 0.694 | 0.055 | 0.500 | 2 |
| quench | no_ff | 0.392 | 0.024 | 0.240 | 2 |
| quench | vanilla | 1.250 | 0.060 | 1.469 | 2 |
