"""
benchmarks_multiseed.py
=======================
统一预算 + 多种子的三算例基准（修复"表 1 与表 2 数值不自洽"）。

背景（见 docs/paper_gap_analysis.md 阶段 9）
-------------------------------------------
论文表 1（3 变体 × 3 算例，单种子）与表 2（5 变体 × 3 算例，2--5 种子）
来自 **两个不同的训练预算**（H1 冻结配方 vs 消融 lite 配方）与不同种子数，
因此同名变体的数值互相矛盾（例如 pair/full：表 1 为 0.195，
表 2 为 0.408±0.187；heal/no_correct：0.352 vs 0.328）。

本脚本用**单一预算 + 统一种子集**重跑全部变体，产出一张自洽的表：

变体（总 epoch 预算严格对齐 full）
---------------------------------
  full         完整方法（同伦延拓 + IC 预训练 + 调度式数据校正）
  no_homotopy  K=1，直接在 λ=1 训练；阶段预算 = Σ full 各段，校正预算合并
  no_correct   同伦延拓 + IC 预训练，去掉数据校正
  no_ff        同 full，但 num_freqs=0（去掉 Fourier 特征）
  vanilla      K=1 直接 λ=1 + 无数据校正 + 无 Fourier 特征
  causal       外部基线：标准 PINN（λ=1，无同伦延拓、无数据监督）
  trigger      同 full，但校正激活改用 a-posteriori 残差阈值判据
               （段末残差 RMS > tol=0.5），即论文 Algorithm 1 的模式
               + 因果时间加权（Wang et al. 2024）。架构（含 Fourier 特征）
               与 epoch 预算同 no_correct 的 K=1 版本，唯一差别是以
               "因果加权"替代"同伦延拓"作为长时误差累积的对策。

用法
----
    python benchmarks_multiseed.py --seeds 5                  # 全量
    python benchmarks_multiseed.py --cases heal --variants full --seeds 1
    python benchmarks_multiseed.py --recipe lite --seeds 3    # 快速自检

输出（可断点续跑：已有 JSON 直接读入）
    results/benchmarks_ms/<case>_<variant>_s<seed>.json
    results/benchmarks_ms/summary.md
    results/benchmarks_ms/summary.json
"""
import sys, os, json, time, argparse
sys.path.insert(0, '.')
import torch
import numpy as np

from src.homotopy_nn import TrainConfig, train_homotopy_nn, evaluate_grid
from src.reference_solver import ETD2RK, make_initial_condition, vortex_map
from src.evaluation import (rel_l2_error, linf_error, free_energy,
                            dissipation_residual)

OUT = os.path.join("results", "benchmarks_ms")
L = 10.0
N_REF = 48      # 参考解与评估网格
M_REF = 60      # 评估帧数（含 t=0）

CASES = {
    "heal":   dict(kind="gaussian", params=dict(eps=0.8, sigma=1.5), T=5.0),
    "pair":   dict(kind="pair",     params=dict(sep=5.0, xi=0.5),   T=6.0),
    "quench": dict(kind="quench",   params=dict(ell=1.5, rms=0.4, seed=2), T=4.0),
}

# ---------------------------------------------------------------------------
# 预算配方（两种；同一 recipe 下所有变体严格对齐）
# ---------------------------------------------------------------------------
RECIPES = {
    # 冻结的 H1 配方（论文主表旧口径）。注意：本机实测单次运行约
    # 40--60 min（数据项 20000 点/epoch 主导），论文所报 90 s/算例
    # 在发布代码上不可复现，故不作为统一定稿口径。
    "h1": dict(ic_pretrain_epochs=300, K=4, stage_epochs=300,
               correct_epochs=300, final_correct_epochs=900,
               N_data_max=20000, N_grid=32, N_ic=400),
    # 统一定稿配方（本脚本默认）：与旧 lite 同量级，但数据项降为
    # 4000 点/epoch，使单次运行降到分钟级。所有变体共用该预算，
    # 因此表 1 与表 2 出自同一批运行，数值自洽。
    "lite": dict(ic_pretrain_epochs=200, K=4, stage_epochs=100,
                 correct_epochs=100, final_correct_epochs=200,
                 N_data_max=4000, N_grid=32, N_ic=400),
}


def variant_configs(recipe, seed, case):
    """返回 {variant: TrainConfig}，同一 recipe 内预算严格对齐。"""
    R = RECIPES[recipe]
    total_stage = R["K"] * R["stage_epochs"]
    total_corr = R["correct_epochs"] * (R["K"] - 1) + R["final_correct_epochs"]

    base = dict(L=L, T=case["T"], ic_kind=case["kind"],
                ic_params=case["params"], seed=seed,
                ic_pretrain_epochs=R["ic_pretrain_epochs"],
                ic_pretrain_tol=0.0, ic_pretrain_max=4000,
                N_data_max=R["N_data_max"], batch_data=0,
                N_grid=R["N_grid"], N_ic=R["N_ic"])

    full = TrainConfig(**base, K=R["K"], E_k=[R["stage_epochs"]] * R["K"],
                       correct_schedule="always",
                       correct_epochs=R["correct_epochs"],
                       final_correct_epochs=R["final_correct_epochs"],
                       final_extra_data=True)

    # 直接在 λ=1 训练：单段，epoch 预算 = full 各段之和，校正预算合并到末段
    no_homotopy = TrainConfig(**base, K=1, E_k=[total_stage],
                              correct_schedule="always",
                              correct_epochs=0,
                              final_correct_epochs=total_corr,
                              final_extra_data=True)

    # 纯 PINN：保留同伦 + IC 预训练，无数据校正
    no_correct = TrainConfig(**base, K=R["K"], E_k=[R["stage_epochs"]] * R["K"],
                             correct_schedule="always",
                             correct_epochs=0, final_correct_epochs=0,
                             final_extra_data=False)

    no_ff = TrainConfig(**base, K=R["K"], E_k=[R["stage_epochs"]] * R["K"],
                        correct_schedule="always",
                        correct_epochs=R["correct_epochs"],
                        final_correct_epochs=R["final_correct_epochs"],
                        final_extra_data=True, num_freqs=0)

    vanilla = TrainConfig(**base, K=1, E_k=[total_stage],
                          correct_schedule="always",
                          correct_epochs=0, final_correct_epochs=0,
                          final_extra_data=False, num_freqs=0)

    # 外部基线：标准 PINN（λ=1，无同伦、无数据监督）+ 因果时间加权。
    # 与 no_correct 的唯一差别是"因果加权 vs 同伦延拓"，与 no_homotopy 的
    # 唯一差别是"因果加权 vs 数据校正"，因此可与二者直接对照。
    causal = TrainConfig(**base, K=1, E_k=[total_stage],
                         correct_schedule="always",
                         correct_epochs=0, final_correct_epochs=0,
                         final_extra_data=False, causal=True)

    # 论文 Algorithm 1 的 a-posteriori 模式：段末 PDE 残差 RMS 超过 tol 才
    # 激活数据校正（与 full 的唯一差别是激活判据）。
    # 注意：残差判据受 Fourier 特征导数噪声地板（~0.5）影响，见论文讨论。
    trigger = TrainConfig(**base, K=R["K"], E_k=[R["stage_epochs"]] * R["K"],
                          correct_schedule="residual", tol=0.5,
                          correct_epochs=R["correct_epochs"],
                          final_correct_epochs=R["final_correct_epochs"],
                          final_extra_data=True)

    return dict(full=full, no_homotopy=no_homotopy, no_correct=no_correct,
                no_ff=no_ff, vanilla=vanilla, causal=causal, trigger=trigger)


VARIANTS = ("full", "no_homotopy", "no_correct", "no_ff", "vanilla", "causal",
            "trigger")

# 每变体种子数：三个主变体支撑表 1 / 表 2 的核心论断，用 5 种子；
# no_ff / vanilla / causal 为次要对照，用 3 种子（表内逐行标注 n）。
SEED_COUNT = dict(full=5, no_homotopy=5, no_correct=5, no_ff=3, vanilla=3,
                  causal=3, trigger=3)


def run_one(cname, vname, seed, recipe, ref, case):
    fjson = os.path.join(OUT, f"{cname}_{vname}_s{seed}.json")
    if os.path.exists(fjson):
        try:
            with open(fjson, encoding="utf-8") as f:
                rec = json.load(f)
            if rec.get("recipe") == recipe:
                print(f"  [{cname}/{vname}/s{seed}] cached "
                      f"e2={rec['e2_mean']:.3f}", flush=True)
                return rec
        except Exception:
            pass

    cfg = variant_configs(recipe, seed, case)[vname]
    t0 = time.time()
    net, hist = train_homotopy_nn(cfg, verbose=False)
    t_train = time.time() - t0

    out = evaluate_grid(net, cfg, lam=1.0, M=M_REF, N=N_REF)
    snaps = torch.tensor(out["snaps"])
    e2 = rel_l2_error(snaps, ref).numpy()
    ei = linf_error(snaps, ref).numpy()

    vcount_nn = (vortex_map(snaps).abs() > 0.5).sum(dim=(-1, -2)).numpy()
    res = [h["residual"] for h in hist]

    rec = dict(
        case=cname, variant=vname, seed=seed, recipe=recipe,
        e2_mean=float(e2.mean()), e2_final=float(e2[-1]), e2_ic=float(e2[0]),
        linf_final=float(ei[-1]), e2_max=float(e2.max()),
        nn_peak_vortex=int(vcount_nn.max()),
        n_corrected=sum(1 for h in hist if h.get("corrected")),
        lam_path=[h["lam"] for h in hist],
        residual_first=float(res[0]), residual_last=float(res[-1]),
        t_train=float(t_train), n_epochs=int(sum(cfg.E_k) + cfg.ic_pretrain_epochs
                                            + cfg.correct_epochs * (cfg.K - 1)
                                            + cfg.final_correct_epochs),
    )
    with open(fjson, "w", encoding="utf-8") as f:
        json.dump(rec, f, indent=1)
    print(f"  [{cname}/{vname}/s{seed}] e2_mean={rec['e2_mean']:.3f} "
          f"e2[T]={rec['e2_final']:.3f} peakV={rec['nn_peak_vortex']} "
          f"({t_train:.0f}s, {rec['n_epochs']} ep)", flush=True)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--cases", default="heal,pair,quench")
    ap.add_argument("--variants", default=",".join(VARIANTS))
    ap.add_argument("--recipe", default="h1", choices=list(RECIPES.keys()))
    ap.add_argument("--resume-only", action="store_true",
                    help="只从已有 JSON 重建汇总，不训练")
    ap.add_argument("--threads", type=int, default=0,
                    help="torch CPU 线程数（0=用默认值；多进程并行时建议 6--8）")
    ap.add_argument("--shard", default="0/1", help="工作分片，形如 2/4")
    ap.add_argument("--seeds-mode", default="auto", choices=["auto", "uniform"],
                    help="auto=按 SEED_COUNT；uniform=所有变体用 --seeds")
    args = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)

    if args.threads > 0:
        torch.set_num_threads(args.threads)
    shard_i, shard_n = (int(v) for v in args.shard.split("/"))

    sel_cases = [c.strip() for c in args.cases.split(",") if c.strip()]
    sel_vars = [v.strip() for v in args.variants.split(",") if v.strip()]

    # 需要跑的任务清单（用于分片；分片在算例级之前生成，保证负载均衡）
    work = []
    for cname in sel_cases:
        for vname in sel_vars:
            nseed = (args.seeds if args.seeds_mode == "uniform"
                     else SEED_COUNT.get(vname, args.seeds))
            for s in range(nseed):
                work.append((cname, vname, s))
    work = [w for i, w in enumerate(work) if i % shard_n == shard_i]
    print(f"[shard {shard_i}/{shard_n}] {len(work)} runs, "
          f"threads={torch.get_num_threads()}, recipe={args.recipe}", flush=True)

    for cname in sel_cases:
        case = CASES[cname]
        psi0 = make_initial_condition(case["kind"], N_REF, L, **case["params"])
        ref = ETD2RK(lam=1.0, L_box=L, N=N_REF).integrate(
            psi0, dt=case["T"] / (M_REF - 1), n_steps=M_REF - 1)
        # 参考诊断（每个算例只算一次）
        F_ref, mono = dissipation_residual(ref, L, lam=1.0)
        vc_ref = (vortex_map(ref).abs() > 0.5).sum(dim=(-1, -2)).numpy()
        ref_rec = dict(case=cname, T=case["T"], F_mono=bool(mono),
                       ref_peak_vortex=int(vc_ref.max()),
                       ref_vortex_at_T=int(vc_ref[-1]),
                       F0=float(F_ref[0]), FT=float(F_ref[-1]))
        with open(os.path.join(OUT, f"{cname}_ref.json"), "w",
                  encoding="utf-8") as f:
            json.dump(ref_rec, f, indent=1)
        print(f"== {cname}: ref peak vortices={ref_rec['ref_peak_vortex']} "
              f"@T={ref_rec['ref_vortex_at_T']}, F monotone={mono}, "
              f"F {ref_rec['F0']:.3f}->{ref_rec['FT']:.3f}", flush=True)

        if args.resume_only:
            continue
        for (wc, vname, s) in work:
            if wc != cname:
                continue
            try:
                run_one(cname, vname, s, args.recipe, ref, case)
            except Exception as ex:
                print(f"  [{cname}/{vname}/s{s}] FAILED: {ex}", flush=True)

    # 分片并行时只让 0 号分片写汇总，避免并发覆盖；最终统一用 --resume-only 重建
    if shard_i == 0:
        rebuild_summary()


def rebuild_summary():
    """从全部 JSON 重建汇总表（可跨多次运行合并）。"""
    recs = []
    for fn in sorted(os.listdir(OUT)):
        if fn.endswith(".json") and "_s" in fn:
            try:
                with open(os.path.join(OUT, fn), encoding="utf-8") as f:
                    recs.append(json.load(f))
            except Exception:
                pass

    table = {}
    for cname in CASES:
        for vname in VARIANTS:
            ms = [r["e2_mean"] for r in recs
                  if r["case"] == cname and r["variant"] == vname]
            fs = [r["e2_final"] for r in recs
                  if r["case"] == cname and r["variant"] == vname]
            pv = [r["nn_peak_vortex"] for r in recs
                  if r["case"] == cname and r["variant"] == vname]
            if not ms:
                continue
            table.setdefault(cname, {})[vname] = dict(
                n=len(ms), mean=float(np.mean(ms)),
                std=float(np.std(ms, ddof=1)) if len(ms) > 1 else 0.0,
                final_mean=float(np.mean(fs)),
                peak_vortex=float(np.mean(pv)))

    refs = {}
    for cname in CASES:
        fp = os.path.join(OUT, f"{cname}_ref.json")
        if os.path.exists(fp):
            with open(fp, encoding="utf-8") as f:
                refs[cname] = json.load(f)

    with open(os.path.join(OUT, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(dict(table=table, refs=refs), f, indent=1)

    lines = ["# 统一预算多种子基准汇总", "",
             "所有变体使用同一 recipe 与同一组种子；预算（总 epoch）标注在表尾。", "",
             "| 算例 | 变体 | rel-L2 mean ± std | rel-L2 末帧 | 峰值涡旋(NN) | 种子数 |",
             "|---|---|---|---|---|---|"]
    for cname in CASES:
        for vname in VARIANTS:
            if vname not in table.get(cname, {}):
                continue
            r = table[cname][vname]
            lines.append(f"| {cname} | {vname} | {r['mean']:.3f} ± {r['std']:.3f} "
                         f"| {r['final_mean']:.3f} | {r['peak_vortex']:.1f} "
                         f"| {r['n']} |")
    lines += ["", "## 参考解诊断", "",
              "| 算例 | 峰值涡旋 | t=T 涡旋数 | F(0) | F(T) | F 单调 |",
              "|---|---|---|---|---|---|"]
    for cname, r in refs.items():
        lines.append(f"| {cname} | {r['ref_peak_vortex']} | {r['ref_vortex_at_T']} "
                     f"| {r['F0']:.3f} | {r['FT']:.3f} "
                     f"| {'yes' if r['F_mono'] else 'no'} |")
    with open(os.path.join(OUT, "summary.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"[summary] {len(recs)} runs -> {OUT}/summary.md")


if __name__ == "__main__":
    main()
